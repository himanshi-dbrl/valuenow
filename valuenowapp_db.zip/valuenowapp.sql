-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 12, 2021 at 10:00 PM
-- Server version: 5.6.49-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `valuenowapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks`
--

CREATE TABLE `bookmarks` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookmarks`
--

INSERT INTO `bookmarks` (`id`, `post_id`, `user_id`, `type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(69, 59, 22, NULL, '2020-03-19 21:46:07', '2020-03-19 21:46:07', NULL),
(71, 24, 9, NULL, '2020-03-19 21:47:19', '2020-03-19 21:47:19', NULL),
(72, 59, 9, NULL, '2020-03-19 21:47:20', '2020-03-19 21:47:20', NULL),
(76, 17, 9, NULL, '2020-03-19 21:47:27', '2020-03-19 21:47:27', NULL),
(77, 16, 9, NULL, '2020-03-19 21:47:29', '2020-03-19 21:47:29', NULL),
(79, 14, 9, NULL, '2020-03-19 21:47:33', '2020-03-19 21:47:33', NULL),
(80, 13, 9, NULL, '2020-03-19 21:47:34', '2020-03-19 21:47:34', NULL),
(81, 12, 9, NULL, '2020-03-19 21:47:36', '2020-03-19 21:47:36', NULL),
(85, 64, 4, NULL, '2020-03-19 22:01:07', '2020-03-19 22:01:07', NULL),
(86, 24, 1, NULL, '2020-03-20 14:32:02', '2020-03-20 14:32:02', NULL),
(87, 60, 1, NULL, '2020-03-20 14:32:08', '2020-03-20 14:32:08', NULL),
(88, 64, 6, NULL, '2020-03-21 17:55:03', '2020-03-21 17:55:03', NULL),
(89, 60, 6, NULL, '2020-03-21 17:55:57', '2020-03-21 17:55:57', NULL),
(91, 64, 9, NULL, '2020-03-23 12:00:36', '2020-03-23 12:00:36', NULL),
(93, 74, 1, NULL, '2020-03-23 23:36:58', '2020-03-23 23:36:58', NULL),
(94, 65, 14, NULL, '2020-03-24 18:46:17', '2020-03-24 18:46:17', NULL),
(95, 93, 9, NULL, '2020-04-01 14:21:18', '2020-04-01 14:21:18', NULL),
(96, 91, 46, NULL, '2020-04-01 17:52:13', '2020-04-01 17:52:13', NULL),
(97, 97, 46, NULL, '2020-04-01 17:52:46', '2020-04-01 17:52:46', NULL),
(98, 84, 46, NULL, '2020-04-01 17:52:50', '2020-04-01 17:52:50', NULL),
(101, 94, 1, NULL, '2020-04-16 12:28:23', '2020-04-16 12:28:23', NULL),
(102, 83, 9, NULL, '2020-04-16 16:10:54', '2020-04-16 16:10:54', NULL),
(105, 102, 84, NULL, '2021-07-11 16:24:35', '2021-07-11 16:24:35', NULL),
(106, 103, 84, NULL, '2021-07-11 19:58:00', '2021-07-11 19:58:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `business`
--

CREATE TABLE `business` (
  `id` int(11) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `business_user_id` int(11) NOT NULL,
  `business_user_type` int(11) NOT NULL,
  `business_field` int(11) NOT NULL,
  `business_subfield` varchar(11) DEFAULT NULL,
  `business_type` int(11) NOT NULL,
  `country` int(11) NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country_code` varchar(255) DEFAULT NULL,
  `mobile` bigint(11) NOT NULL,
  `estb_year` varchar(255) DEFAULT NULL,
  `employees` varchar(255) NOT NULL,
  `est_business_value` varchar(255) DEFAULT NULL,
  `business_info` text,
  `business_doc` varchar(255) DEFAULT NULL,
  `business_picture` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0-Valuate, 1-pending, 2-Valuated',
  `no_of_update` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `business`
--

INSERT INTO `business` (`id`, `business_name`, `business_user_id`, `business_user_type`, `business_field`, `business_subfield`, `business_type`, `country`, `state`, `city`, `address`, `country_code`, `mobile`, `estb_year`, `employees`, `est_business_value`, `business_info`, `business_doc`, `business_picture`, `status`, `no_of_update`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'jai', 7, 1, 1, '1', 5, 6, NULL, 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', '6', 9654785478, '2019', '4', '100', 'Business Information', NULL, NULL, 0, 0, '2020-02-11 16:34:21', '2020-02-11 16:34:21', NULL),
(2, 'shift app', 7, 1, 6, '2', 6, 41, NULL, 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', '41', 99999999998, '2018', '4', '100', 'Business Information', NULL, NULL, 0, 0, '2020-02-11 17:06:51', '2020-02-11 17:06:51', NULL),
(3, 'Arena', 6, 1, 27, NULL, 3, 49, NULL, 'Amman', 'Jabal al husein', '49', 362149652, '2019', '2', NULL, 'Private business', NULL, NULL, 1, 0, '2020-02-11 17:12:32', '2020-04-14 18:39:07', NULL),
(5, 'LLANO Pvt. ltd.', 1, 1, 27, NULL, 4, 8, NULL, 'Noida', 'H 221', '8', 9958140918, '2015', '6', '70000', 'Thank you', 'public/images/business_doc/1581522468.The-Basics.pptx', 'public/images/business_picture/1581522470.IMG_20200210_214728_640.jpg', 0, 0, '2020-02-12 22:47:50', '2020-02-12 22:47:50', NULL),
(10, 'autmobile business', 9, 1, 6, '32', 5, 5, NULL, 'Noida', 'Sec16, noida', NULL, 9867454545, '2018', '4', NULL, 'this is my testing business', NULL, NULL, 1, 0, '2020-02-14 17:25:07', '2020-04-14 13:24:17', NULL),
(11, 'valuenow', 9, 1, 4, '19', 3, 6, 'New Delhi', 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', NULL, 9654785478, 'null', '4', 'null', 'The Mathematics Placement Exam (MPE) is a 90-minute, 60-item multiple choice exam that tests skills and understandings from precalculus mathematics. It is designed to measure readiness for college courses in calculus and precalculus. Online, you may view an individual report that includes placement level and a list of topics that should be reviewed before the class begins.', NULL, NULL, 2, 3, '2020-02-14 19:06:45', '2020-04-13 15:02:01', NULL),
(15, 'TACO GAMERS', 14, 1, 24, NULL, 2, 49, 'Greater Amman', 'Amman', 'An Nujum', NULL, 775659999, NULL, '2', '100000', 'we provide Gaming chairs and PS4 accounts', NULL, NULL, 0, 0, '2020-02-15 19:17:41', '2020-02-15 19:17:41', NULL),
(16, 'Arena', 15, 1, 1, '1', 1, 49, 'Amman', 'Amman', 'Khalda', NULL, 796472056, '2018', '2', '200000', 'It\'s a private business realted to food', NULL, NULL, 0, 0, '2020-02-15 20:16:31', '2020-02-15 21:13:26', NULL),
(17, 'shift care', 9, 1, 6, '32', 4, 6, 'null', 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', NULL, 9654785478, 'null', '3', 'null', 'Business Information', NULL, NULL, 1, 0, '2020-02-18 16:43:15', '2020-04-14 13:28:37', NULL),
(18, 'UI Design', 18, 1, 23, NULL, 3, 41, 'UP', 'Nodia', 'Nodia', NULL, 9873240696, '2018', '3', '1000', 'Demo as a testing', NULL, NULL, 0, 0, '2020-02-19 17:11:12', '2020-02-19 17:11:12', NULL),
(19, 'Churan ki Factory', 19, 1, 1, '5', 3, 88, 'test', 'test', 'A-90 Sector 4', NULL, 8987989349, '2018', '3', '693856', 'qweastrewerwta5rtgesr', NULL, NULL, 0, 0, '2020-02-20 17:51:42', '2020-02-20 17:51:42', NULL),
(20, 'AK REAL ESTATE DEVELOPMENT', 14, 1, 122, NULL, 3, 128, 'WR', 'JEDDAH', 'Madina Road', NULL, 544433032, '2015', '3', '1000', 'we develop apparent for residential', NULL, NULL, 0, 0, '2020-02-22 03:39:19', '2020-02-22 03:39:19', NULL),
(21, 'ارينا', 6, 1, 118, NULL, 3, 49, 'Amman', 'Amman', 'Abdoun', NULL, 798484019, '2020', '2', '20000', 'It\'s a private business', NULL, NULL, 0, 0, '2020-02-29 18:22:46', '2020-02-29 18:22:46', NULL),
(22, 'jai', 9, 1, 2, '15', 4, 6, 'uttar pradesh', 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', NULL, 9654785478, '2018', '3', '100', 'Business Information', NULL, NULL, 0, 0, '2020-03-30 20:53:05', '2020-03-30 20:53:05', NULL),
(23, 'Mobilecoderz', 1, 1, 14, '77', 3, 6, 'dasda', 'asda', 'H 221', NULL, 9958140915, '2018', '3', '78000', 'hello', NULL, NULL, 0, 0, '2020-03-30 20:57:34', '2020-03-30 20:57:34', NULL),
(24, 'Al nidal company', 26, 1, 1, '7', 5, 49, 'Amman', 'Amman', 'Abdoun', NULL, 9632587413, '2013', '2', '200000', 'Government Accounting', NULL, NULL, 0, 0, '2020-03-31 16:40:59', '2020-03-31 16:40:59', NULL),
(25, 'Zain', 24, 1, 3, '18', 3, 49, 'Amman', 'Amman', 'Alhusien', NULL, 963258741, '2013', '3', '600000', 'Alternative Dispute resolution', NULL, NULL, 0, 0, '2020-03-31 16:42:45', '2020-03-31 16:42:45', NULL),
(26, 'Al Hatamleh Markets', 28, 1, 17, '109', 2, 49, 'Azarqaa', 'Azarqaa', 'azarqaa', NULL, 9874562159, '2003', '2', '200000', 'Stocks markets', NULL, NULL, 0, 0, '2020-03-31 16:48:18', '2020-03-31 16:48:18', NULL),
(27, 'Al-Ali Fashions', 27, 1, 6, '35', 3, 49, 'Amman', 'Amman', 'Alhussien', NULL, 9685743215, '2003', '3', '3000000', 'Fashion industry', NULL, NULL, 0, 0, '2020-03-31 16:51:38', '2020-03-31 16:51:38', NULL),
(28, 'TH for crafting', 29, 1, 9, '49', 3, 7, 'Cairo', 'Cairo', 'Cairo36', NULL, 9687453216, '2003', '2', '200000', 'Functional crafts', NULL, NULL, 0, 0, '2020-03-31 17:00:12', '2020-03-31 17:00:12', NULL),
(29, 'JOE Fashions', 30, 1, 6, '34', 3, 59, 'Bairout', 'Bairout', 'B.32', NULL, 95874321696, '2016', '2', '20000', 'Fashion Design Business', NULL, NULL, 0, 0, '2020-03-31 17:03:42', '2020-03-31 17:03:42', NULL),
(30, 'Jana Marketing', 32, 1, 2, '15', 3, 7, 'Cairo', 'Cairo', 'C296', NULL, 9685741236, '2011', '2', '21000', 'Airlines Marketing', NULL, NULL, 0, 0, '2020-03-31 17:06:51', '2020-03-31 17:06:51', NULL),
(31, 'Rizq Groups', 31, 1, 1, '5', 4, 59, 'Bairout', 'Bairout', 'B656', NULL, 9632587758, '2010', '2', '1000000', 'Financial Accounting Companies', NULL, NULL, 0, 0, '2020-03-31 17:11:09', '2020-03-31 17:11:09', NULL),
(32, 'BQ', 33, 1, 10, '55', 3, 128, 'Riyadh', 'Riyadh', 'Riyadh123', NULL, 986541237, '2013', '2', '20000', 'Automotive engineering', NULL, NULL, 0, 0, '2020-03-31 17:43:08', '2020-03-31 17:43:08', NULL),
(33, 'Soud', 34, 1, 25, '161', 4, 128, 'Jeddah', 'Jeddah', 'Jeddah', NULL, 9658732569, '2012', '2', '200000', 'Computer Hardware (Output devices)', NULL, NULL, 0, 0, '2020-03-31 18:24:00', '2020-03-31 18:24:00', NULL),
(34, 'rakesh sharma test', 50, 1, 3, '18', 3, 6, NULL, 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', NULL, 9654785478, '2018', '2', '100', 'Business Information', NULL, NULL, 0, 0, '2020-03-31 18:59:13', '2020-03-31 18:59:13', NULL),
(35, 'MObile Coderz', 4, 1, 2, '14', 3, 5, 'vxdv', 'sdfsd', 'sdfd', NULL, 9958140914, '2017', '2', '30000', 'dfzczxczxczx', NULL, NULL, 1, 0, '2020-04-29 19:38:02', '2020-04-29 19:38:31', NULL),
(36, 'NEW', 84, 1, 1, '5', 3, 49, 'Amman', 'Amman', 'Amman', NULL, 798484019, '2015', '2', '20000000', 'test', NULL, NULL, 1, 0, '2021-07-11 16:27:20', '2021-07-11 19:16:00', NULL),
(37, 'NEW', 84, 1, 1, '5', 2, 49, 'Amman', 'Amman', 'Amman', NULL, 799999999, '2015', '3', '20200', 'test', NULL, NULL, 1, 0, '2021-07-12 13:39:52', '2021-07-12 13:43:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `business_evaluation_packages`
--

CREATE TABLE `business_evaluation_packages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `number_of_update` int(10) NOT NULL,
  `arabic_version` int(10) NOT NULL DEFAULT '0',
  `full_valuation_report_eng` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-no,1-yes',
  `result_guaranted_day` tinyint(1) NOT NULL DEFAULT '1',
  `duration` int(10) NOT NULL DEFAULT '0' COMMENT '0-Open',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_evaluation_packages`
--

INSERT INTO `business_evaluation_packages` (`id`, `name`, `amount`, `number_of_update`, `arabic_version`, `full_valuation_report_eng`, `result_guaranted_day`, `duration`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Basic', '999', 0, 150, 1, 1, 1, 1, '2020-04-07 08:11:44', '2020-04-09 17:05:45'),
(2, 'Advanced', '1499', 3, 150, 1, 1, 3, 1, '2020-04-07 08:12:56', '2020-04-09 17:05:45'),
(3, 'Premium', '1999', 6, 150, 1, 1, 2, 1, '2020-04-07 08:13:33', '2020-04-10 13:41:35');

-- --------------------------------------------------------

--
-- Table structure for table `business_types`
--

CREATE TABLE `business_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `business_types`
--

INSERT INTO `business_types` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'Angel Investor', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(3, 'Private Business', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(4, 'Limited Liability', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(5, 'Shareholding Company', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(6, 'Venture Capital', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(7, 'Government Funds', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(8, 'Simi Government', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(9, 'Government', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL),
(10, 'Non Profit Organization', '2020-02-03 12:45:00', '2020-02-03 12:45:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_stamp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_code`, `country_name`, `time_stamp`, `created_at`, `updated_at`) VALUES
(4, '+670', 'East Timor', NULL, NULL, NULL),
(5, '+56', 'Easter Island', NULL, NULL, NULL),
(6, '+593', 'Ecuador', NULL, NULL, NULL),
(7, '+20', 'Egypt', NULL, NULL, NULL),
(8, '+503', 'El Salvador', NULL, NULL, NULL),
(9, '+240', 'Equatorial Guinea', NULL, NULL, NULL),
(10, '+291', 'Eritrea', NULL, NULL, NULL),
(11, '+372', 'Estonia', NULL, NULL, NULL),
(12, '+251', 'Ethiopia', NULL, NULL, NULL),
(13, '+500', 'Falkland Islands (Malvinas)', NULL, NULL, NULL),
(14, '+298', 'Faroe Islands', NULL, NULL, NULL),
(15, '+679', 'Fiji Islands', NULL, NULL, NULL),
(16, '+358', 'Finland', NULL, NULL, NULL),
(17, '+33', 'France', NULL, NULL, NULL),
(18, '+596\n', 'French Antilles', NULL, NULL, NULL),
(19, '+594', 'French Guiana', NULL, NULL, NULL),
(20, '+689', 'French Polynesia', NULL, NULL, NULL),
(21, '+241', 'Gabonese Republic', NULL, NULL, NULL),
(22, '+220\n', 'Gambia', NULL, NULL, NULL),
(23, '+995\n', 'Georgia', NULL, NULL, NULL),
(24, '+49\n', 'Germany', NULL, NULL, NULL),
(25, '+233', 'Ghana', NULL, NULL, NULL),
(26, '+350', 'Gibraltar', NULL, NULL, NULL),
(27, '+30', 'Greece', NULL, NULL, NULL),
(28, '+299', 'Greenland', NULL, NULL, NULL),
(29, '+1-473', 'Grenada', NULL, NULL, NULL),
(30, '+590', 'Guadeloupe', NULL, NULL, NULL),
(31, '+1-671', 'Guam', NULL, NULL, NULL),
(32, '+5399', 'Guantanamo Bay', NULL, NULL, NULL),
(33, '+502', 'Guatemala', NULL, NULL, NULL),
(34, '+245', 'Guinea-Bissau', NULL, NULL, NULL),
(35, '+592', 'Guyana', NULL, NULL, NULL),
(36, '+509', 'Haiti', NULL, NULL, NULL),
(37, '+504', 'Honduras', NULL, NULL, NULL),
(38, '+852', 'Hong Kong', NULL, NULL, NULL),
(39, '+36', 'Hungary', NULL, NULL, NULL),
(40, '+354 ', 'Iceland', NULL, NULL, NULL),
(41, '+91', 'India', NULL, NULL, NULL),
(42, '+62', 'Indonesia', NULL, NULL, NULL),
(43, '+98', 'Iran', NULL, NULL, NULL),
(44, '+964', 'Iraq', NULL, NULL, NULL),
(45, '+353', 'Ireland', NULL, NULL, NULL),
(46, '+39', 'Italy', NULL, NULL, NULL),
(47, '+1-876', 'Jamaica', NULL, NULL, NULL),
(48, '+81', 'Japan', NULL, NULL, NULL),
(49, '+962', 'Jordan', NULL, NULL, NULL),
(50, '+7', 'Kazakhstan', NULL, NULL, NULL),
(51, '+254 ', 'Kenya', NULL, NULL, NULL),
(52, '+686', 'Kiribati', NULL, NULL, NULL),
(53, '+850', 'Korea (North)', NULL, NULL, NULL),
(54, '+82', 'Korea (South)', NULL, NULL, NULL),
(55, '+965', 'Kuwait', NULL, NULL, NULL),
(56, '+996', 'Kyrgyz Republic', NULL, NULL, NULL),
(57, '+856', 'Laos', NULL, NULL, NULL),
(58, '+371', 'Latvia', NULL, NULL, NULL),
(59, '+961', 'Lebanon\n', NULL, NULL, NULL),
(60, '+266', 'Lesotho', NULL, NULL, NULL),
(61, '+231', 'Liberia', NULL, NULL, NULL),
(62, '+218', 'Libya', NULL, NULL, NULL),
(63, '+423', 'Liechtenstein', NULL, NULL, NULL),
(64, '+370', 'Lithuania', NULL, NULL, NULL),
(65, '+352', 'Luxembourg', NULL, NULL, NULL),
(66, '+853', 'Macao', NULL, NULL, NULL),
(67, '+389', 'Macedonia', NULL, NULL, NULL),
(68, '+261 \n', 'Madagascar', NULL, NULL, NULL),
(69, '+265', 'Malawi', NULL, NULL, NULL),
(70, '+60', 'Malaysia', NULL, NULL, NULL),
(71, '+960', 'Mali Republic', NULL, NULL, NULL),
(72, '+356\n', 'Malta', NULL, NULL, NULL),
(73, '+692', 'Marshall Islands', NULL, NULL, NULL),
(74, '+596', 'Martinique', NULL, NULL, NULL),
(75, '+222', 'Mauritania', NULL, NULL, NULL),
(76, '+230', 'Mauritius', NULL, NULL, NULL),
(77, '+269', 'Mayotte Island', NULL, NULL, NULL),
(78, '+52', 'Mexico', NULL, NULL, NULL),
(79, '+691', 'Micronesia, (Federal States of)', NULL, NULL, NULL),
(80, '+1-808', 'Midway Island', NULL, NULL, NULL),
(81, '+373', 'Moldova', NULL, NULL, NULL),
(82, '+373', 'Moldova', NULL, NULL, NULL),
(83, '+377', 'Monaco', NULL, NULL, NULL),
(84, '+976', 'Mongolia', NULL, NULL, NULL),
(85, '+1-664', 'Montserrat', NULL, NULL, NULL),
(86, '+212', 'Morocco', NULL, NULL, NULL),
(87, '+258', 'Mozambique', NULL, NULL, NULL),
(88, '+95', 'Myanmar', NULL, NULL, NULL),
(89, '+264', 'Namibia', NULL, NULL, NULL),
(90, '+977', 'Nepal', NULL, NULL, NULL),
(91, '+31', 'Netherlands', NULL, NULL, NULL),
(92, '+599', 'Netherlands Antilles\n', NULL, NULL, NULL),
(93, '+674', 'Nauru', NULL, NULL, NULL),
(94, '+687\n', 'New Caledonia', NULL, NULL, NULL),
(95, '+64', 'New Zealand', NULL, NULL, NULL),
(96, '+505', 'Nicaragua', NULL, NULL, NULL),
(97, '+227', 'Niger', NULL, NULL, NULL),
(98, '+234 ', 'Nigeria', NULL, NULL, NULL),
(99, '+683', 'Niue', NULL, NULL, NULL),
(100, '+672', 'Norfolk Island', NULL, NULL, NULL),
(101, '+1-670', 'Northern Marianas Islands ', NULL, NULL, NULL),
(102, '+47', 'Norway', NULL, NULL, NULL),
(103, '+968', 'Oman', NULL, NULL, NULL),
(104, '+92', 'Pakistan', NULL, NULL, NULL),
(105, '+680', 'Palau', NULL, NULL, NULL),
(106, '+970', 'Palestine', NULL, NULL, NULL),
(107, '+507', 'Panama', NULL, NULL, NULL),
(108, '+675', 'Papua New Guinea', NULL, NULL, NULL),
(109, '+595', 'Paraguay', NULL, NULL, NULL),
(110, '+51', 'Peru', NULL, NULL, NULL),
(111, '+63', 'Philippines', NULL, NULL, NULL),
(112, '+48', 'Poland', NULL, NULL, NULL),
(113, '+351', 'Portugal', NULL, NULL, NULL),
(114, '+1-787 ', 'Puerto Rico', NULL, NULL, NULL),
(115, '+974 ', 'Qatar', NULL, NULL, NULL),
(116, '+262', 'Réunion Island', NULL, NULL, NULL),
(117, '+40', 'Romania', NULL, NULL, NULL),
(118, '+7', 'Russia', NULL, NULL, NULL),
(119, '+250', 'Rwandese Republic', NULL, NULL, NULL),
(120, '+290', 'St. Helena', NULL, NULL, NULL),
(121, '+1-869', 'St. Kitts/Nevis', NULL, NULL, NULL),
(122, '+1-758', 'St. Lucia', NULL, NULL, NULL),
(123, '+508', 'St. Pierre & Miquelon', NULL, NULL, NULL),
(124, '+1-784', 'St. Vincent & Grenadines', NULL, NULL, NULL),
(125, '+685', 'Samoa', NULL, NULL, NULL),
(126, '+378', 'San Marino', NULL, NULL, NULL),
(127, '+239', 'São Tomé and Principe', NULL, NULL, NULL),
(128, '+966', 'Saudi Arabia', NULL, NULL, NULL),
(129, '+221', 'Senegal', NULL, NULL, NULL),
(130, '+381', 'Serbia', NULL, NULL, NULL),
(131, '+248', 'Seychelles Republic', NULL, NULL, NULL),
(132, '+232', 'Sierra Leone', NULL, NULL, NULL),
(133, '+65', 'Singapore', NULL, NULL, NULL),
(134, '+421', 'Slovak Republic', NULL, NULL, NULL),
(135, '+386', 'Slovenia', NULL, NULL, NULL),
(136, '+677', 'Solomon Islands', NULL, NULL, NULL),
(137, '+252', 'Somali Democratic Republic', NULL, NULL, NULL),
(138, '+27', 'South Africa', NULL, NULL, NULL),
(139, '+34', 'Spain', NULL, NULL, NULL),
(140, '+351', 'Portugal', NULL, NULL, NULL),
(141, '+94', 'Sri Lanka', NULL, NULL, NULL),
(142, '+249', 'Sudan', NULL, NULL, NULL),
(143, '+597', 'Suriname', NULL, NULL, NULL),
(144, '+268', 'Swaziland', NULL, NULL, NULL),
(145, '+46', 'Sweden', NULL, NULL, NULL),
(146, '+41', 'Switzerland', NULL, NULL, NULL),
(147, '+963', 'Syria', NULL, NULL, NULL),
(148, '+886', 'Taiwan', NULL, NULL, NULL),
(149, '+992', 'Tajikistan', NULL, NULL, NULL),
(150, '+255', 'Tanzania', NULL, NULL, NULL),
(151, '+66', 'Thailand', NULL, NULL, NULL),
(152, '+228', 'Togolese Republic', NULL, NULL, NULL),
(153, '+690', 'Tokelau', NULL, NULL, NULL),
(154, '+676', 'Tonga Islands', NULL, NULL, NULL),
(155, '+1-868', 'Trinidad & Tobago', NULL, NULL, NULL),
(156, '+216', 'Tunisia', NULL, NULL, NULL),
(157, '+90', 'Turkey', NULL, NULL, NULL),
(158, '+993', 'Turkmenistan', NULL, NULL, NULL),
(159, '+688', 'Tuvalu', NULL, NULL, NULL),
(160, '+256', 'Uganda', NULL, NULL, NULL),
(161, '+380', 'Ukraine', NULL, NULL, NULL),
(162, '+971', 'United Arab Emirates', NULL, NULL, NULL),
(163, '+44', 'United Kingdom', NULL, NULL, NULL),
(164, '+1', 'United States of America', NULL, NULL, NULL),
(165, '+1-340', 'US Virgin Islands', NULL, NULL, NULL),
(166, '+598', 'Uruguay', NULL, NULL, NULL),
(167, '+998', 'Uzbekistan', NULL, NULL, NULL),
(168, '+678', 'Vanuatu', NULL, NULL, NULL),
(169, '+58', 'Venezuela', NULL, NULL, NULL),
(170, '+84', 'Vietnam', NULL, NULL, NULL),
(171, '+967', 'Yemen', NULL, NULL, NULL),
(172, '+260 ', 'Zambia', NULL, NULL, NULL),
(173, '+255', 'Zanzibar', NULL, NULL, NULL),
(174, '+263 ', 'Zimbabwe', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(32) NOT NULL,
  `employeeName` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `employeeName`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '0', '2020-02-03 11:38:20', '2020-02-04 03:31:39', '2020-02-03 11:38:20'),
(2, '1 _ 10', '2020-02-03 11:38:20', '2020-02-04 03:31:23', '2020-02-03 11:38:20'),
(3, '11 _ 30', '2020-02-03 11:38:20', '2020-02-04 03:31:03', '2020-02-03 11:38:20'),
(4, '31 _ 50', '2020-02-03 11:38:20', '2020-02-04 03:30:58', '2020-02-03 11:38:20'),
(5, '51 _ 100', '2020-02-03 11:38:20', '2020-02-04 03:30:53', '2020-02-03 11:38:20'),
(6, 'More than 100', '2020-02-04 10:30:43', '2020-02-04 03:30:43', '2020-02-04 10:30:43');

-- --------------------------------------------------------

--
-- Table structure for table `entrepreneur_packages`
--

CREATE TABLE `entrepreneur_packages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `post_opportunities_investment` varchar(50) NOT NULL,
  `search_opportunities` varchar(50) NOT NULL,
  `free_chat` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-no,1-yes',
  `banner_host_duration` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-no,1-yes',
  `appear_post_number` tinyint(1) NOT NULL DEFAULT '1',
  `promote_post` tinyint(1) NOT NULL DEFAULT '1',
  `duration` varchar(50) NOT NULL COMMENT '0-Open',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `entrepreneur_packages`
--

INSERT INTO `entrepreneur_packages` (`id`, `name`, `amount`, `post_opportunities_investment`, `search_opportunities`, `free_chat`, `banner_host_duration`, `appear_post_number`, `promote_post`, `duration`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Quick', '0', '1', '100000', 1, 0, 0, 0, 'Open', 1, '2020-04-07 08:15:20', '2020-05-01 20:02:25'),
(2, 'Basic', '33', '10', '100000', 1, 0, 0, 1, '1', 1, '2020-04-07 08:16:17', '2020-05-01 20:02:25'),
(3, 'Advanced', '77', '20', '100000', 1, 1, 1, 0, '3', 1, '2020-04-07 08:17:10', '2020-05-01 20:02:25'),
(4, 'Premium', '99', '100000', '100000', 1, 1, 1, 1, '12', 1, '2020-04-07 08:17:46', '2020-05-01 20:02:25');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `id` int(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `time_stamp` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `user_id`, `post_id`, `time_stamp`, `created_at`, `updated_at`) VALUES
(2, 5, 1, '1583495021340', '2020-03-06 06:13:41', '2020-03-06 06:13:41'),
(12, 6, 1, '1583497158124', '2020-03-06 06:49:18', '2020-03-06 06:49:18'),
(13, 19, 1, '1583497537339', '2020-03-06 06:55:37', '2020-03-06 06:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fields`
--

INSERT INTO `fields` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Accounting', '2020-01-22 12:46:11', '2020-01-22 12:46:11', NULL),
(2, 'Airlines/Aviation\r\n', '2020-01-22 12:46:11', '2020-01-22 12:46:11', NULL),
(3, 'Alternative Dispute Resolution', '2020-01-22 12:47:03', '2020-01-22 12:47:03', NULL),
(4, 'Alternative Medicine', '2020-01-22 12:47:03', '2020-01-22 12:47:03', NULL),
(5, 'Animation', '2020-01-22 12:47:34', '2020-01-22 12:47:34', NULL),
(6, 'Apparel&Fashion', '2020-01-22 12:47:34', '2020-01-22 12:47:34', NULL),
(7, 'Architecture&Planning', '2020-01-22 12:48:03', '2020-01-22 12:48:03', NULL),
(9, 'Arts&Crafts\r\n', '2020-01-22 12:48:35', '2020-01-22 12:48:35', NULL),
(10, 'Automotive\r\n', '2020-01-22 12:48:35', '2020-01-22 12:48:35', NULL),
(11, 'Aviation&Aerospace', '2020-01-22 12:49:10', '2020-01-22 12:49:10', NULL),
(12, 'Banking\r\n', '2020-01-22 12:49:10', '2020-01-22 12:49:10', NULL),
(13, 'Biotechnology\r\n', '2020-01-22 12:49:49', '2020-01-22 12:49:49', NULL),
(14, 'Broadcast Media \r\n', '2020-01-22 12:49:49', '2020-01-22 12:49:49', NULL),
(15, 'Building Materials\r\n', '2020-01-22 12:50:13', '2020-01-22 12:50:13', NULL),
(16, 'Business Supplies&Equipment\r\n\r\n', '2020-01-22 12:50:13', '2020-01-22 12:50:13', NULL),
(17, 'Capital Markets\r\n', '2020-01-22 12:50:37', '2020-01-22 12:50:37', NULL),
(18, 'Chmicals\r\n', '2020-01-22 12:50:37', '2020-01-22 12:50:37', NULL),
(19, 'Civic&Social Organization\r\n', '2020-01-22 12:51:01', '2020-01-22 12:51:01', NULL),
(20, 'Civil Engineering\r\n', '2020-01-22 12:51:01', '2020-01-22 12:51:01', NULL),
(21, 'Commercial Real Estate\r\n', '2020-01-22 12:51:22', '2020-01-22 12:51:22', NULL),
(23, 'Computer &Network Security\r\n', '2020-01-22 12:51:59', '2020-01-22 12:51:59', NULL),
(24, 'Computer Games\r\n', '2020-01-22 12:51:59', '2020-01-22 12:51:59', NULL),
(25, 'Computer Hardware', '2020-01-22 12:53:11', '2020-01-22 12:53:11', NULL),
(26, 'Computer Networking \r\n', '2020-01-22 12:53:11', '2020-01-22 12:53:11', NULL),
(27, 'Computer Software', '2020-01-22 13:17:18', '2020-01-22 13:17:18', NULL),
(28, 'Construction\r\n', '2020-01-22 13:17:18', '2020-01-22 13:17:18', NULL),
(29, 'Consumer Electronics\r\n', '2020-02-20 11:17:20', '2020-02-20 11:17:20', NULL),
(30, 'Consumer Goods\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(31, 'Consumer Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(32, 'Cosmetics\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(33, 'Dairy\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(34, 'Defense & Space\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(35, 'Design\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(36, 'E-learning\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(37, 'Education Management\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(38, 'Electrical & Electronic Manufacturing\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(39, 'Entertainment\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(40, 'Environmental Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(41, 'Events Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(42, 'Executive Office\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(43, 'Facilities Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(44, 'Farming\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(45, 'Financial Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(46, 'Fine Art\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(47, 'Fishery\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(48, 'Food & Beverages\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(49, 'Food Production\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(50, 'Fundraising\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(51, 'Furniture\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(52, 'Gambling & Casions\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(53, 'Glass,Ceramics & Concrete\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(54, 'Government Administration\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(55, 'Government Relations\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(56, 'Graphic Design\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(57, 'Health, Wellness &Fitness\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(58, 'Higher Education\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(59, 'Hospital & Health Care\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(60, 'Hospitality\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(61, 'Human Resources\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(62, 'Import & Export\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(63, 'Individual & Family Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(64, 'Industrial Automation\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(65, 'Information Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(66, 'Information Technology & Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(67, 'Insurance\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(68, 'International Affairs\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(69, 'International Trade & Development\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(70, 'Internet\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(71, 'Investment Banking\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(72, 'Investment Management\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(73, 'Judiciary\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(74, 'Law Enforcement\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(75, 'Law Practice\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(76, 'Legal Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(77, 'Legislative Office\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(78, 'Leisure,Travel & Tourism\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(79, 'Libraries\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(80, 'Logistics & Supply Chain\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(81, 'Luxury Goods & Jewelry\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(82, 'Machinery\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(83, 'Management Consulting\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(84, 'Maritime\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(85, 'Market Research\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(86, 'Marketing & Advertising\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(87, 'Mechanical Or Industrial Engineering\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(88, 'Media Production\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(89, 'Medical Device\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(90, 'Medical Practice\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(91, 'Mental Health Care\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(92, 'Military\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(93, 'Mining & Metals\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(94, 'Motion Pictures & Films\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(95, 'Museums & Institutions\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(96, 'Music\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(97, 'Nanotechnology\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(98, 'Newspapers\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(99, 'Non-profit Organization Management\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(100, 'Oil & Energy\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(101, 'Online Media\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(102, 'Outsourcing/offshoring\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(103, 'Package/Freight Delivery\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(104, 'Packaging & Containers\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(105, 'Paper & Forest Products\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(106, 'Performing Arts\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(107, 'Pharmaceuticals\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(108, 'Philanthropy\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(109, 'Photography\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(110, 'Plastics\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(111, 'Political Organization\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(112, 'Primary/Secondary Education\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(113, 'Printing\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(114, 'Professional Training & Coaching\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(115, 'Program Development\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(116, 'Public Policy\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(117, 'Public Relations & Communications\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(118, 'Public Safety\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(119, 'Publishng \r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(120, 'Railroad Manufacture\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(121, 'Ranching \r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(122, 'Real Estate\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(123, 'Recreational Facilities & Services\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(124, 'Religious Institutions\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(125, 'Renewables & Investigations\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(126, 'Semiconductors\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(127, 'Shipbuilding\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(128, 'Sporting Goods\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(129, 'Sports\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(130, 'Staffing & Recruiting\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(131, 'Supermarkets\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(132, 'Telecommunications\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(133, 'Textiles\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(134, 'Think Tanks\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(135, 'Tobacco\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(136, 'Translation & Localization\r\n', '2020-02-20 11:36:24', '2020-02-20 11:36:24', NULL),
(137, 'Transportation/Trucking/Railroad\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(138, 'Utilities\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(139, 'Venture Capital & Private Equity\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(140, 'Veterinary\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(141, 'Warehousing \r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(142, 'Wholesale\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(143, 'Wine & Spirits\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(144, 'Wireless\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(145, 'Writing & Editing\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL),
(146, 'Other\r\n', '2020-02-24 07:56:07', '2020-02-24 07:56:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `post_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(50) DEFAULT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `url`, `post_id`, `type`, `file_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(87, 'public/images/opportunity_picture/1583501150img2.jpg', 72, 'posts_type', 'pic', '2020-03-06 20:25:50', '2020-03-06 13:25:50', NULL),
(80, 'public/images/opportunity_picture/15834949519991843561564389331.png', 67, 'posts_type', 'pic', '2020-03-06 18:42:31', '2020-03-06 11:42:31', NULL),
(4, 'public/images/opportunity_picture/1581675450.6.png', 52, 'posts_type', 'pic', '2020-02-14 17:17:30', '2020-02-14 10:17:30', NULL),
(5, 'public/images/opportunity_picture/1581675450.7.png', 52, 'posts_type', 'pic', '2020-02-14 17:17:30', '2020-02-14 10:17:30', NULL),
(81, 'public/images/opportunity_doc/1576218132720.docx', 67, 'posts_type', 'doc', '2020-03-06 18:42:32', '2020-03-06 11:42:32', NULL),
(7, 'public/images/business_doc/1581675761.4.png', 8, 'business_type', 'doc', '2020-02-14 17:22:41', '2020-02-14 10:22:41', NULL),
(8, 'public/images/business_doc/1581675761.7.png', 8, 'business_type', 'doc', '2020-02-14 17:22:41', '2020-02-14 10:22:41', NULL),
(9, 'public/images/business_doc/1581675839.4.png', 9, 'business_type', 'doc', '2020-02-14 17:23:59', '2020-02-14 10:23:59', NULL),
(10, 'public/images/business_doc/1581675839.7.png', 9, 'business_type', 'doc', '2020-02-14 17:23:59', '2020-02-14 10:23:59', NULL),
(11, 'public/images/business_picture/1581675839.6.png', 9, 'business_type', 'pic', '2020-02-14 17:23:59', '2020-02-14 10:23:59', NULL),
(12, 'public/images/business_picture/1581675839.7.png', 9, 'business_type', 'pic', '2020-02-14 17:23:59', '2020-02-14 10:23:59', NULL),
(79, 'public/images/business_doc/15825383751576218132720 (1).docx', 10, 'business_type', 'doc', '2020-02-24 16:59:35', '2020-02-24 09:59:35', NULL),
(78, 'public/images/business_doc/15825383741576218132720.docx', 10, 'business_type', 'doc', '2020-02-24 16:59:35', '2020-02-24 09:59:35', NULL),
(15, 'public/images/business_picture/1581675907.6.png', 10, 'business_type', 'pic', '2020-02-14 17:25:07', '2020-02-14 10:25:07', NULL),
(84, 'public/images/opportunity_picture/1583501098img2.1.jpg', 71, 'posts_type', 'pic', '2020-03-06 20:24:58', '2020-03-06 13:24:58', NULL),
(82, 'public/images/opportunity_doc/1576218132720 (1).docx', 67, 'posts_type', 'doc', '2020-03-06 18:42:32', '2020-03-06 11:42:32', NULL),
(83, 'public/images/opportunity_picture/1583499807img5.jpg', 67, 'posts_type', 'pic', '2020-03-06 20:03:27', '2020-03-06 13:03:27', NULL),
(20, 'public/images/business_picture/1581675943.7.png', 10, 'business_type', 'pic', '2020-02-14 17:25:43', '2020-02-14 10:25:43', NULL),
(75, 'public/images/business_doc/1582268213file-sample_500kB (1).docx', 11, 'business_type', 'doc', '2020-02-21 13:56:53', '2020-02-21 06:56:53', NULL),
(77, 'public/images/opportunity_doc/15825375821576218132720.docx', 52, 'posts_type', 'doc', '2020-02-24 16:46:22', '2020-02-24 09:46:22', NULL),
(24, 'public/images/business_doc/1581682005.1576218132720.docx', 11, 'business_type', 'doc', '2020-02-14 19:06:45', '2020-02-14 12:06:45', NULL),
(76, 'public/images/business_picture/1582292363galary_1.png', 10, 'business_type', 'pic', '2020-02-21 20:39:23', '2020-02-21 13:39:23', NULL),
(97, 'public/images/business_picture/15855655229991843561564389331.png', 11, 'workplaces_type', 'pic', '2020-03-30 17:52:02', '2020-03-30 10:52:02', NULL),
(27, 'public/images/business_picture/1581682005.img-copy@2x.png', 11, 'business_type', 'pic', '2020-02-14 19:06:48', '2020-02-14 12:06:48', NULL),
(28, 'public/images/business_doc/1581682487.1576218132720.docx', 12, 'business_type', 'doc', '2020-02-14 19:14:47', '2020-02-14 12:14:47', NULL),
(29, 'public/images/business_doc/1581682487.1576218132720 (1).docx', 12, 'business_type', 'doc', '2020-02-14 19:14:47', '2020-02-14 12:14:47', NULL),
(30, 'public/images/business_picture/1581682487.img-copy.png', 12, 'business_type', 'pic', '2020-02-14 19:14:47', '2020-02-14 12:14:47', NULL),
(31, 'public/images/business_picture/1581682487.img-copy@2x.png', 12, 'business_type', 'pic', '2020-02-14 19:14:47', '2020-02-14 12:14:47', NULL),
(32, 'public/images/opportunity_picture/1581687602.img-copy.png', 56, 'posts_type', 'pic', '2020-02-14 20:40:02', '2020-02-14 13:40:02', NULL),
(33, 'public/images/opportunity_picture/1581687602.img-copy@2x.png', 56, 'posts_type', 'pic', '2020-02-14 20:40:06', '2020-02-14 13:40:06', NULL),
(34, 'public/images/opportunity_picture/1581687606.img-copy@3x.png', 56, 'posts_type', 'pic', '2020-02-14 20:40:10', '2020-02-14 13:40:10', NULL),
(35, 'public/images/opportunity_doc/1581687610.1576218132720.docx', 56, 'posts_type', 'doc', '2020-02-14 20:40:10', '2020-02-14 13:40:10', NULL),
(36, 'public/images/opportunity_doc/1581687610.1576218132720 (1).docx', 56, 'posts_type', 'doc', '2020-02-14 20:40:10', '2020-02-14 13:40:10', NULL),
(37, 'public/images/opportunity_doc/1581687610.file-sample_100kB.doc', 56, 'posts_type', 'doc', '2020-02-14 20:40:10', '2020-02-14 13:40:10', NULL),
(38, 'public/images/opportunity_picture/1581689983.img-copy@2x.png', 57, 'posts_type', 'pic', '2020-02-14 21:19:43', '2020-02-14 14:19:43', NULL),
(39, 'public/images/opportunity_picture/1581689983.img-copy@3x.png', 57, 'posts_type', 'pic', '2020-02-14 21:19:47', '2020-02-14 14:19:47', NULL),
(40, 'public/images/opportunity_doc/1581689987.1576218132720.docx', 57, 'posts_type', 'doc', '2020-02-14 21:19:47', '2020-02-14 14:19:47', NULL),
(41, 'public/images/opportunity_doc/1581689987.1576218132720 (1).docx', 57, 'posts_type', 'doc', '2020-02-14 21:19:47', '2020-02-14 14:19:47', NULL),
(105, 'public/images/workplace_doc/158556695415825375821576218132720 (1).docx', 14, 'workplaces_type', 'doc', '2020-03-30 18:15:54', '2020-03-30 11:15:54', NULL),
(43, 'public/images/business_doc/1581690351.1576218132720 (1).docx', 13, 'business_type', 'doc', '2020-02-14 21:25:51', '2020-02-14 14:25:51', NULL),
(112, 'public/images/workplace_picture/15856452402334782_d673_2.jpg', 16, 'workplaces_type', 'pic', '2020-03-31 16:00:40', '2020-03-31 09:00:40', NULL),
(113, 'public/images/business_picture/15856494692334782_d673_2.jpg', 31, 'business_type', 'pic', '2020-03-31 17:11:09', '2020-03-31 10:11:09', NULL),
(47, 'public/images/business_picture/1581690353.img-copy@2x.png', 13, 'business_type', 'pic', '2020-02-14 21:25:55', '2020-02-14 14:25:55', NULL),
(114, 'public/images/opportunity_picture/1585656856first part photos-01.jpg', 92, 'posts_type', 'pic', '2020-03-31 19:14:16', '2020-03-31 12:14:16', NULL),
(49, 'public/images/business_doc/1581690387.1576218132720.docx', 14, 'business_type', 'doc', '2020-02-14 21:26:27', '2020-02-14 14:26:27', NULL),
(50, 'public/images/business_picture/1581690387.img-copy@3x.png', 14, 'business_type', 'pic', '2020-02-14 21:26:33', '2020-02-14 14:26:33', NULL),
(51, 'public/images/opportunity_picture/1581690453.img-copy.png', 58, 'posts_type', 'pic', '2020-02-14 21:27:33', '2020-02-14 14:27:33', NULL),
(52, 'public/images/opportunity_doc/1581690453.1576218132720.docx', 58, 'posts_type', 'doc', '2020-02-14 21:27:33', '2020-02-14 14:27:33', NULL),
(53, 'public/images/business_doc/1581776006.Tripp Lite Corporate Profile.pdf', 16, 'business_type', 'doc', '2020-02-15 21:13:28', '2020-02-15 14:13:28', NULL),
(54, 'public/images/business_picture/1581776008.unnamed.jpg', 16, 'business_type', 'pic', '2020-02-15 21:13:28', '2020-02-15 14:13:28', NULL),
(55, 'public/images/business_doc/1582018995.1576218132720.docx', 17, 'business_type', 'doc', '2020-02-18 16:43:17', '2020-02-18 09:43:17', NULL),
(56, 'public/images/business_doc/1582018997.file-sample_500kB.docx', 17, 'business_type', 'doc', '2020-02-18 16:43:17', '2020-02-18 09:43:17', NULL),
(57, 'public/images/business_picture/1582018997.playlist-added@3x.png', 17, 'business_type', 'pic', '2020-02-18 16:43:17', '2020-02-18 09:43:17', NULL),
(58, 'public/images/business_picture/1582024965.img-copy.png', 10, 'business_type', 'pic', '2020-02-18 18:22:45', '2020-02-18 11:22:45', NULL),
(85, 'public/images/opportunity_picture/1583501098img2.jpg', 71, 'posts_type', 'pic', '2020-03-06 20:24:58', '2020-03-06 13:24:58', NULL),
(86, 'public/images/opportunity_picture/1583501150img2.1.jpg', 72, 'posts_type', 'pic', '2020-03-06 20:25:50', '2020-03-06 13:25:50', NULL),
(61, 'public/images/business_doc/1582107072.faq-shift-freight-english.docx', 18, 'business_type', 'doc', '2020-02-19 17:11:12', '2020-02-19 10:11:12', NULL),
(62, 'public/images/business_picture/1582107072.fingerprint.png', 18, 'business_type', 'pic', '2020-02-19 17:11:12', '2020-02-19 10:11:12', NULL),
(63, 'public/images/opportunity_picture/1582107168.fingerprint.png', 60, 'posts_type', 'pic', '2020-02-19 17:12:48', '2020-02-19 10:12:48', NULL),
(64, 'public/images/opportunity_doc/1582107168.faq-shift-freight-english.docx', 60, 'posts_type', 'doc', '2020-02-19 17:12:50', '2020-02-19 10:12:50', NULL),
(65, 'public/images/opportunity_picture/1582107431.person_s.jpeg', 60, 'posts_type', 'pic', '2020-02-19 17:17:11', '2020-02-19 10:17:11', NULL),
(66, 'public/images/opportunity_picture/1582107431.Slider-1.jpg', 60, 'posts_type', 'pic', '2020-02-19 17:17:11', '2020-02-19 10:17:11', NULL),
(74, 'public/images/opportunity_doc/1582268166file-sample_500kB.docx', 61, 'posts_type', 'doc', '2020-02-21 13:56:07', '2020-02-21 06:56:07', NULL),
(68, 'public/images/opportunity_picture/1582263977.img4.jpg', 61, 'posts_type', 'pic', '2020-02-21 12:46:17', '2020-02-21 05:46:17', NULL),
(73, 'public/images/opportunity_doc/15822681661576218132720.docx', 61, 'posts_type', 'doc', '2020-02-21 13:56:06', '2020-02-21 06:56:06', NULL),
(70, 'public/images/opportunity_picture/1582264007.img3.jpg', 61, 'posts_type', 'pic', '2020-02-21 12:46:47', '2020-02-21 05:46:47', NULL),
(72, 'public/images/opportunity_picture/1582264007.img5.jpg', 61, 'posts_type', 'pic', '2020-02-21 12:46:47', '2020-02-21 05:46:47', NULL),
(88, 'public/images/opportunity_doc/1576218132720.docx', 72, 'posts_type', 'doc', '2020-03-06 20:25:50', '2020-03-06 13:25:50', NULL),
(89, 'public/images/opportunity_picture/1583501577ajax-loader.gif', 73, 'posts_type', 'pic', '2020-03-06 20:32:57', '2020-03-06 13:32:57', NULL),
(90, 'public/images/opportunity_picture/1583501577ajax-loader (1).gif', 73, 'posts_type', 'pic', '2020-03-06 20:32:57', '2020-03-06 13:32:57', NULL),
(91, 'public/images/opportunity_doc/1576218132720 (1).docx', 73, 'posts_type', 'doc', '2020-03-06 20:32:58', '2020-03-06 13:32:58', NULL),
(92, 'public/images/opportunity_doc/15825375821576218132720.docx', 73, 'posts_type', 'doc', '2020-03-06 20:32:58', '2020-03-06 13:32:58', NULL),
(93, 'public/images/opportunity_picture/15843553926.png', 72, 'posts_type', 'pic', '2020-03-16 17:43:12', '2020-03-16 10:43:12', NULL),
(94, 'public/images/opportunity_picture/15843553927.png', 72, 'posts_type', 'pic', '2020-03-16 17:43:12', '2020-03-16 10:43:12', NULL),
(95, 'public/images/opportunity_doc/4.png', 72, 'posts_type', 'doc', '2020-03-16 17:43:12', '2020-03-16 10:43:12', NULL),
(96, 'public/images/opportunity_picture/1585050832shobak lobak logo for linkedin .png', 77, 'posts_type', 'pic', '2020-03-24 18:53:52', '2020-03-24 11:53:52', NULL),
(98, 'public/images/business_picture/15855655229991843561564389331.png', 11, 'workplaces_type', 'pic', '2020-03-30 17:52:02', '2020-03-30 10:52:02', NULL),
(99, 'public/images/workplace_picture/15855659109991843561564389331.png', 11, 'workplaces_type', 'pic', '2020-03-30 17:58:30', '2020-03-30 10:58:30', NULL),
(100, 'public/images/workplace_doc/158556604715825375821576218132720.docx', 7, 'workplaces_type', 'doc', '2020-03-30 18:00:47', '2020-03-30 11:00:47', NULL),
(101, 'public/images/workplace_picture/15855660479991843561564389331.png', 7, 'workplaces_type', 'pic', '2020-03-30 18:00:47', '2020-03-30 11:00:47', NULL),
(109, 'public/images/workplace_picture/15855688441584954462124.png', 14, 'workplaces_type', 'pic', '2020-03-30 18:47:24', '2020-03-30 11:47:24', NULL),
(110, 'public/images/business_doc/1585576654Our Services AK 29  03 2020 .docx', 23, 'business_type', 'doc', '2020-03-30 20:57:34', '2020-03-30 13:57:34', NULL),
(111, 'public/images/business_picture/15855766544K_res.png', 23, 'business_type', 'pic', '2020-03-30 20:57:34', '2020-03-30 13:57:34', NULL),
(115, 'public/images/opportunity_picture/1585656856first part photos-02.jpg', 92, 'posts_type', 'pic', '2020-03-31 19:14:16', '2020-03-31 12:14:16', NULL),
(116, 'public/images/opportunity_picture/1585656856first part photos-03.jpg', 92, 'posts_type', 'pic', '2020-03-31 19:14:16', '2020-03-31 12:14:16', NULL),
(117, 'public/images/opportunity_doc/Investor and entrepreneur pages by AK 10 01 2202 docx.docx', 92, 'posts_type', 'doc', '2020-03-31 19:14:16', '2020-03-31 12:14:16', NULL),
(118, 'public/images/opportunity_doc/ValeNow notes  07 01 2020 .docx', 92, 'posts_type', 'doc', '2020-03-31 19:14:16', '2020-03-31 12:14:16', NULL),
(119, 'public/images/opportunity_doc/ValueNow Home Page by AK 16 12 2019 .docx', 92, 'posts_type', 'doc', '2020-03-31 19:14:27', '2020-03-31 12:14:27', NULL),
(120, 'public/images/opportunity_doc/ValueNow Investor page.docx', 92, 'posts_type', 'doc', '2020-03-31 19:14:27', '2020-03-31 12:14:27', NULL),
(121, 'public/images/opportunity_doc/ValueNow Our services by AK 16 12 2019  (1).docx', 92, 'posts_type', 'doc', '2020-03-31 19:14:37', '2020-03-31 12:14:37', NULL),
(122, 'public/images/opportunity_picture/15857278289991843561564389331.png', 94, 'posts_type', 'pic', '2020-04-01 14:57:08', '2020-04-01 07:57:08', NULL),
(123, 'public/images/opportunity_picture/15857284749991843561564389331.png', 95, 'posts_type', 'pic', '2020-04-01 15:07:54', '2020-04-01 08:07:54', NULL),
(124, 'public/images/opportunity_picture/15857347009991843561564389331.png', 96, 'posts_type', 'pic', '2020-04-01 16:51:40', '2020-04-01 09:51:40', NULL),
(125, 'public/images/opportunity_doc/file-sample_500kB.docx', 96, 'posts_type', 'doc', '2020-04-01 16:51:40', '2020-04-01 09:51:40', NULL),
(126, 'public/images/business_doc/1588163882Jalabiyat_Extra_Efforts.pdf', 35, 'business_type', 'doc', '2020-04-29 19:38:02', '2020-04-29 12:38:02', NULL),
(127, 'public/images/business_picture/1588163882uTrack_two_thumbnail.PNG', 35, 'business_type', 'pic', '2020-04-29 19:38:02', '2020-04-29 12:38:02', NULL),
(128, 'public/images/business_doc/1625995640fahed1.pdf', 36, 'business_type', 'doc', '2021-07-11 16:27:20', '2021-07-11 09:27:20', NULL),
(129, 'public/images/business_picture/1625995640value now final logo-01.png', 36, 'business_type', 'pic', '2021-07-11 16:27:20', '2021-07-11 09:27:20', NULL),
(131, 'public/images/business_picture/16260719921.PNG', 37, 'business_type', 'pic', '2021-07-12 13:39:52', '2021-07-12 06:39:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `investing_as`
--

CREATE TABLE `investing_as` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `investing_as`
--

INSERT INTO `investing_as` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'Indivisual', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(3, 'Private business', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(4, 'Limited Liability', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(5, 'Shareholding company', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(6, 'Venture capital', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(7, 'Government funds', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(8, 'Simi Government', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(9, 'Government', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL),
(10, 'Non Profit Organization', '2020-03-04 18:30:00', '2020-03-05 18:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `investor_packages`
--

CREATE TABLE `investor_packages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `post_opportunities_investment` int(10) NOT NULL,
  `search_opportunities` int(10) NOT NULL,
  `unlook_full_entrepreneur_Conacts` int(10) NOT NULL DEFAULT '0' COMMENT '0=not,100000= Unlimited',
  `free_chat` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-no,1-yes',
  `banner_host_duration` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-no,1-yes',
  `appear_post_number` tinyint(1) NOT NULL DEFAULT '1',
  `promote_post` tinyint(1) NOT NULL DEFAULT '1',
  `duration` int(10) NOT NULL DEFAULT '0' COMMENT '0-Open',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `investor_packages`
--

INSERT INTO `investor_packages` (`id`, `name`, `amount`, `post_opportunities_investment`, `search_opportunities`, `unlook_full_entrepreneur_Conacts`, `free_chat`, `banner_host_duration`, `appear_post_number`, `promote_post`, `duration`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Quick', '0', 1, 100000, 0, 0, 0, 0, 0, 0, 1, '2020-04-07 08:19:23', '2020-04-07 08:19:23'),
(2, 'Basic', '33', 10, 100000, 10, 1, 0, 0, 1, 1, 1, '2020-04-07 08:20:09', '2020-04-07 08:20:09'),
(3, 'Advanced', '77', 20, 100000, 40, 1, 1, 1, 0, 3, 1, '2020-04-07 08:20:49', '2020-04-07 08:20:49'),
(4, 'Premium', '99', 100000, 100000, 100000, 1, 1, 1, 1, 12, 1, '2020-04-07 08:21:43', '2020-04-07 08:21:43');

-- --------------------------------------------------------

--
-- Table structure for table `invest_ranges`
--

CREATE TABLE `invest_ranges` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invest_ranges`
--

INSERT INTO `invest_ranges` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '50K\r\n', '2020-01-20 18:30:00', '2020-01-14 18:30:00', NULL),
(2, '100K', '2020-01-22 18:30:00', '2020-01-14 18:30:00', NULL),
(3, '200K', '2020-01-22 13:24:16', '2020-01-22 13:24:16', NULL),
(4, '400K', '2020-01-22 13:24:16', '2020-01-22 13:24:16', NULL),
(5, '600K', '2020-01-22 13:24:41', '2020-01-22 13:24:41', NULL),
(6, '800K', '2020-01-22 13:24:41', '2020-01-22 13:24:41', NULL),
(7, '1000K', '2020-01-22 13:25:04', '2020-01-22 13:25:04', NULL),
(8, '2000K', '2020-01-22 13:25:04', '2020-01-22 13:25:04', NULL),
(9, '4000K', '2020-01-22 13:25:25', '2020-01-22 13:25:25', NULL),
(11, 'More than 4000K\r\n', '2020-01-22 13:25:50', '2020-01-22 13:25:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2016_06_01_000001_create_oauth_auth_codes_table', 2),
(5, '2016_06_01_000002_create_oauth_access_tokens_table', 2),
(6, '2016_06_01_000003_create_oauth_refresh_tokens_table', 2),
(7, '2016_06_01_000004_create_oauth_clients_table', 2),
(8, '2016_06_01_000005_create_oauth_personal_access_clients_table', 2),
(9, '2014_10_12_000000_create_users_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `post_id` int(11) NOT NULL DEFAULT '0',
  `header` text,
  `body` longtext NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `post_id`, `header`, `body`, `type`, `created_at`, `updated_at`) VALUES
(1, 0, 0, 'testing Header', 'Testing purpose only.', 'Admin', '2020-04-08 19:16:36', '2020-04-08 19:16:36'),
(2, 0, 0, 'testing Header', 'Testing purpose only.', 'Admin', '2020-04-08 19:17:22', '2020-04-08 19:17:22'),
(3, 9, 0, NULL, 'Your password has been successfully changed', 'Profile', '2020-04-09 17:29:48', '2020-04-09 17:29:48'),
(4, 9, 97, NULL, 'Your opportunity has been posted.', 'Post', '2020-04-09 11:13:53', '2020-04-09 11:14:02'),
(5, 9, 100, NULL, 'Your opportunity has been posted.', 'Post', '2020-04-13 17:45:10', '2020-04-13 17:45:10'),
(6, 9, 101, NULL, 'Your opportunity has been posted.', 'Post', '2020-04-13 17:46:12', '2020-04-13 17:46:12'),
(7, 9, 102, NULL, 'Your opportunity has been posted.', 'Post', '2020-04-13 18:24:52', '2020-04-13 18:24:52'),
(8, 53, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2020-04-14 12:15:00', '2020-04-14 12:15:00'),
(9, 6, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2020-04-14 13:37:33', '2020-04-14 13:37:33'),
(10, 52, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2020-04-14 14:38:20', '2020-04-14 14:38:20'),
(11, 1, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2020-04-15 22:01:01', '2020-04-15 22:01:01'),
(12, 58, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2020-04-16 17:05:17', '2020-04-16 17:05:17'),
(13, 4, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2020-04-29 19:34:40', '2020-04-29 19:34:40'),
(14, 4, 103, NULL, 'Your opportunity has been posted.', 'Post', '2020-04-29 19:40:36', '2020-04-29 19:40:36'),
(15, 64, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-06-23 15:18:58', '2021-06-23 15:18:58'),
(16, 64, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-06-23 15:19:17', '2021-06-23 15:19:17'),
(17, 64, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-06-23 15:21:42', '2021-06-23 15:21:42'),
(18, 68, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-07-05 14:43:29', '2021-07-05 14:43:29'),
(19, 68, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-07-05 14:44:22', '2021-07-05 14:44:22'),
(20, 72, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-07-06 18:23:29', '2021-07-06 18:23:29'),
(21, 82, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-07-09 18:15:48', '2021-07-09 18:15:48'),
(22, 82, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-07-09 18:15:54', '2021-07-09 18:15:54'),
(23, 84, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-07-11 16:22:12', '2021-07-11 16:22:12'),
(24, 83, 0, NULL, 'Your profile has been successfully updated', 'Profile', '2021-07-11 16:25:19', '2021-07-11 16:25:19'),
(25, 84, 104, NULL, 'Your opportunity has been posted.', 'Post', '2021-07-12 13:40:36', '2021-07-12 13:40:36');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('00e00bb22244b7413848edc7e8ff5768ad838b59e7c904ad50a7e0abfe40fd4b5e9654c939000a7e', 71, 1, 'MyApp', '[]', 0, '2021-07-06 17:57:41', '2021-07-06 17:57:41', '2022-07-06 10:57:41'),
('014542810c76d1adeaee16aea15533a3f88e65a52ca5a9d473922c0b835cba20c3b7d8775291d2d5', 78, 1, 'MyApp', '[]', 0, '2021-07-09 02:17:55', '2021-07-09 02:17:55', '2022-07-08 19:17:55'),
('0218a2b49918bf0dc2a272287190ed0dc95c40760b6bc894fe24b72608336708b03e2ccff30b9bb9', 18, 1, 'MyApp', '[]', 0, '2020-02-25 14:32:56', '2020-02-25 14:32:56', '2021-02-25 07:32:56'),
('028328023721c095ff508699cfe704c4f3198c2c9adaa8a04e192b0ef9a210c5bb18807344090343', 51, 1, 'MyApp', '[]', 0, '2020-04-08 20:24:10', '2020-04-08 20:24:10', '2021-04-08 13:24:10'),
('034a09fd3a8b5f766b37363d55f6dfded24fd5b9e5eaeb7ccb022c21fe04d9f6c558cba50548a50f', 6, 1, 'MyApp', '[]', 0, '2020-04-06 17:55:06', '2020-04-06 17:55:06', '2021-04-06 10:55:06'),
('04dc60b6904ee20160f08948c135246913fe32adf04bda05d2fb9056340751a7357a251c7e42a3b8', 57, 1, 'MyApp', '[]', 0, '2020-04-16 17:01:22', '2020-04-16 17:01:22', '2021-04-16 10:01:22'),
('058b28850d4be8eca7faec77757521c6fd965db965572eac70038b162a2587bbe66de81ce2804e2c', 6, 1, 'MyApp', '[]', 0, '2020-02-19 20:07:10', '2020-02-19 20:07:10', '2021-02-19 13:07:10'),
('08027cb4622dc6ec75333afe2e87821aebb89ae695066bf35473d5b1e5c9bf802749d622f57f8d78', 9, 1, 'MyApp', '[]', 0, '2020-04-09 19:04:23', '2020-04-09 19:04:23', '2021-04-09 12:04:23'),
('087cb15b1f9815212454f603f02980870d9545a763247272d571c2987da5e0dd97785565f2a8dcf3', 1, 1, 'MyApp', '[]', 0, '2020-02-12 22:45:18', '2020-02-12 22:45:18', '2021-02-12 15:45:18'),
('08bff7521085bd9b58ef1af11487d4917e8b29e7e8086ea0b3593da76f4dd555170ff7f411e24073', 78, 1, 'MyApp', '[]', 0, '2021-07-09 01:12:43', '2021-07-09 01:12:43', '2022-07-08 18:12:43'),
('0a687d2f67d059b50a5760184a8e20f4fb8db7167cd8c2167e4a958009b2f5ebf060140898e2860a', 9, 1, 'MyApp', '[]', 0, '2020-03-18 19:01:09', '2020-03-18 19:01:09', '2021-03-18 12:01:09'),
('0b55e67572f3c166e593ecc443a17fbd8bbe1f546d453e596e5f3554bdbd3f9d5cb69f8534646b4c', 30, 1, 'MyApp', '[]', 0, '2020-03-31 16:57:54', '2020-03-31 16:57:54', '2021-03-31 09:57:54'),
('0b5c2d4384d186426313684f9c70918c95927dd6b56fdb2e6681dde44386c8d7a2605e74459aa081', 78, 1, 'MyApp', '[]', 0, '2021-07-09 13:02:15', '2021-07-09 13:02:15', '2022-07-09 06:02:15'),
('0b9988e094bb79cb198d7e9d822d755524a13de508e6cefb7ee0ed83d6d4dbc8dd5d43d8ff00df7b', 9, 1, 'MyApp', '[]', 0, '2020-02-21 18:07:39', '2020-02-21 18:07:39', '2021-02-21 11:07:39'),
('0c0a455554ee82ece54ea299c6e39750d3b1a4aaefb9aa077f80cef56dd9e11539feace84215acda', 1, 1, 'MyApp', '[]', 0, '2020-03-17 12:04:50', '2020-03-17 12:04:50', '2021-03-17 05:04:50'),
('0c191885715442920a3a80aec52a47110325b030aa0a6e560fee86ad242bb6221d1c31bab6467122', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:03:36', '2021-07-06 18:03:36', '2022-07-06 11:03:36'),
('0c5b5f2347389115575645a4e6fa1f2685b93c90bdf0a7bb0791a9da8980868e86ce62d286a56012', 9, 1, 'MyApp', '[]', 0, '2020-03-16 12:25:20', '2020-03-16 12:25:20', '2021-03-16 05:25:20'),
('0d27b6d126a460aef8888990baa3a8ca5939f5c453a346380b88c37b102a30ee5ca553eafd99e2ef', 28, 1, 'MyApp', '[]', 0, '2020-03-31 18:46:20', '2020-03-31 18:46:20', '2021-03-31 11:46:20'),
('0dcd321f0dd91bc08d37a5b5d72f265ac5152264bc615325884835ce6e86d19d34ae08137028992e', 9, 1, 'MyApp', '[]', 0, '2020-03-30 19:16:14', '2020-03-30 19:16:14', '2021-03-30 12:16:14'),
('0e15aae2b60df3b1426d326edbd4cc2d0db270b68799142dce795720c5b07476642ce9fe21d53f87', 9, 1, 'MyApp', '[]', 0, '2020-02-12 19:35:11', '2020-02-12 19:35:11', '2021-02-12 12:35:11'),
('0e3bca6ba41fc154ac4bb9fbd799a8b2676926b2bb4f0f6e6b64485ee3b5d4e0aedb52eb70a6bf46', 1, 1, 'MyApp', '[]', 0, '2020-04-04 20:36:53', '2020-04-04 20:36:53', '2021-04-04 13:36:53'),
('0eb73318b9659b9318ce3019126d24431a40663773dd3aab6cf7c343de19b1845a66ca884b307bf4', 6, 1, 'MyApp', '[]', 0, '2020-04-02 14:14:15', '2020-04-02 14:14:15', '2021-04-02 07:14:15'),
('1119fdf415fd2a0bbd2f398225644549266fd327750f962c3ac5f58a8d6be3e25a50a56497c0275c', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:01:40', '2021-07-06 18:01:40', '2022-07-06 11:01:40'),
('1183cab4f366af3b0edf778fc9a64802709d629d34d92647b83a9c0fb7ea1eb7a04fa2dba0be1a93', 9, 1, 'MyApp', '[]', 0, '2020-02-18 12:28:25', '2020-02-18 12:28:25', '2021-02-18 05:28:25'),
('11917699fdb1b0be8fea4cfde09cfd7cd66033c719f94035d88119b4e23eaaa0ec1ab76e882dcb9b', 10, 1, 'MyApp', '[]', 0, '2020-04-07 12:05:48', '2020-04-07 12:05:48', '2021-04-07 05:05:48'),
('121f2e7fe851beff411eb0237fc353400c4081d2e79a29bebc43879aef907596559967bd2ec4c054', 51, 1, 'MyApp', '[]', 0, '2020-04-09 18:46:36', '2020-04-09 18:46:36', '2021-04-09 11:46:36'),
('139d9f370cfa7f09f4fee5cd1a91571e1005be86879df61b11b32f4af6b9535a4f6224488ae4516f', 79, 1, 'MyApp', '[]', 0, '2021-07-08 18:15:22', '2021-07-08 18:15:22', '2022-07-08 11:15:22'),
('13c5cf3fcad2d12476527a45c3b4ac8443fb5f8cd585d6bcacb268e31c0caa782ef17d3e239a1304', 4, 1, 'MyApp', '[]', 0, '2020-02-14 20:32:21', '2020-02-14 20:32:21', '2021-02-14 13:32:21'),
('14059e6f24e871acf193605a8c668fc2f4ea2744361d63a11986c9f2221131dcd7f2a9c819956e49', 35, 1, 'MyApp', '[]', 0, '2020-03-31 19:01:50', '2020-03-31 19:01:50', '2021-03-31 12:01:50'),
('142f524a6784a0e4188fffac7c9608dd115a0cd0b5a4f70151bb3db7a069debc8674060c79ae660f', 35, 1, 'MyApp', '[]', 0, '2020-03-31 15:59:01', '2020-03-31 15:59:01', '2021-03-31 08:59:01'),
('14656f2b9f4b8c017fb4b2f9ec73786b567eb1599c71c51b86b668d9b3ab7189f4367d2d664bf75a', 9, 1, 'MyApp', '[]', 0, '2020-04-10 14:04:16', '2020-04-10 14:04:16', '2021-04-10 07:04:16'),
('1601183013041356018f06f112794e859bf30dfb11574e507799901dcbdf44e422e6743464d34f60', 11, 1, 'MyApp', '[]', 0, '2020-02-13 17:37:52', '2020-02-13 17:37:52', '2021-02-13 10:37:52'),
('17e2474b891563d9e92ed8cd2977e0a3de29221828767fa2ebb8b0a35f146fcb8ca8eba22517ce9a', 9, 1, 'MyApp', '[]', 0, '2020-03-06 21:26:43', '2020-03-06 21:26:43', '2021-03-06 14:26:43'),
('18642327d34356833faf76b7b8a424fea5e8d5a95e13d295a496842bcdc962007f33b95ff27e4d1d', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:14:17', '2020-04-06 21:14:17', '2021-04-06 14:14:17'),
('188e39015fe247274b646e96c30a3c0a69bc6d0a4254ad2a467d0be950dd17a15a7006a389e9b3d4', 24, 1, 'MyApp', '[]', 0, '2020-03-30 15:30:18', '2020-03-30 15:30:18', '2021-03-30 08:30:18'),
('19db03aaf9c580a51a428dd71f11e477aa778b7f578591a55460ca7eb8f1881c601d1c6055ee638c', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:01:40', '2021-07-06 18:01:40', '2022-07-06 11:01:40'),
('19dce748ecdc600de3f1cc299b3f8bef87297d0ad8a79266a9c4896f99f8b928da3403995d7d20a1', 4, 1, 'MyApp', '[]', 0, '2020-02-14 14:00:35', '2020-02-14 14:00:35', '2021-02-14 07:00:35'),
('1add89c83f19c443268bd0f15eff75c4d52ddffe89f2c0938601044c1244adcc9a7b6d902e770c2a', 38, 1, 'MyApp', '[]', 0, '2020-03-31 16:06:27', '2020-03-31 16:06:27', '2021-03-31 09:06:27'),
('1b092cb9cdfea156bd6831b1f80f35e7be8ec2230ba4a3a9ad7ade2b075f9801e2a0e00fdd8bc006', 66, 1, 'MyApp', '[]', 0, '2021-06-29 15:41:08', '2021-06-29 15:41:08', '2022-06-29 08:41:08'),
('1b8dd6507e11009c9f4f76916b4fb7289dd9a5902194c3bb3ca1eeb562c8aeb342ac23080fca67af', 1, 1, 'MyApp', '[]', 0, '2020-04-05 20:07:26', '2020-04-05 20:07:26', '2021-04-05 13:07:26'),
('1b9a5d4ba59c797342fe1457431e4ef271df5123ea3466ecdf5b3543a44d739c1667889122df296a', 4, 1, 'MyApp', '[]', 0, '2020-02-11 15:45:48', '2020-02-11 15:45:48', '2021-02-11 08:45:48'),
('1bf40c9cd9a49bfdba7edd8c72d75c978d1f3b38e8e7858aa74c3f269d11be51e543a448bc60cb14', 51, 1, 'MyApp', '[]', 0, '2020-04-06 19:26:59', '2020-04-06 19:26:59', '2021-04-06 12:26:59'),
('1c9ce9888cb8c54a739bc89a56d1d425436e6b016cf28c42c578882988001fa430cd23bc82c8e626', 73, 1, 'MyApp', '[]', 0, '2021-07-06 18:35:00', '2021-07-06 18:35:00', '2022-07-06 11:35:00'),
('1cd5d5a04841c857c328b500e8f7a733c737bc518e97463468cad9eb26a4d3f103d8ff5d94ea1b39', 1, 1, 'MyApp', '[]', 0, '2020-02-13 17:55:44', '2020-02-13 17:55:44', '2021-02-13 10:55:44'),
('1cdc9045e44433d2c85c4633eb9a15897bb6f2b8daa4189410ec187d4c8bd5574c614c9ea5d2f135', 65, 1, 'MyApp', '[]', 0, '2021-06-27 20:04:26', '2021-06-27 20:04:26', '2022-06-27 13:04:26'),
('1cf838469964bd3a3adbdb24d3480967f68c41a19081322a06b8607c77cae154395b8f60ac6cb74c', 51, 1, 'MyApp', '[]', 0, '2021-07-05 20:17:00', '2021-07-05 20:17:00', '2022-07-05 13:17:00'),
('1d1f4a7bb18fc3e9ae3b5cb25d9938c0f5f7cbd3cb24ee1f62b9e96d12b5fa26f79d8c4f63aab95a', 6, 1, 'MyApp', '[]', 0, '2020-04-14 18:40:09', '2020-04-14 18:40:09', '2021-04-14 11:40:09'),
('1d2d57af94ce594ae7a6b19cd5fbfb0e96898af79022ad36b86383acdffd90cac888d1cf0feaa3cf', 2, 1, 'MyApp', '[]', 0, '2020-03-17 12:05:56', '2020-03-17 12:05:56', '2021-03-17 05:05:56'),
('1d2e38c00b73a6e5a92bb9d0d91e2960a8a2e2b36af94458e2cef1e49226a143d5ddd6a04f9a7efa', 9, 1, 'MyApp', '[]', 0, '2020-02-18 16:41:02', '2020-02-18 16:41:02', '2021-02-18 09:41:02'),
('1d6652cccf91b1b9acf86325d322c9d58d09003ab0c06ddceb7c996e2490eeb9b68303c5653e803d', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:12:40', '2020-04-06 21:12:40', '2021-04-06 14:12:40'),
('1d9f6b3a9c339327627f997376e88d728816f8a4fdb8cc20a32b771d98032fb14d884aa56915270b', 9, 1, 'MyApp', '[]', 0, '2020-04-03 11:35:05', '2020-04-03 11:35:05', '2021-04-03 04:35:05'),
('1ea2eeb8e60e964897ddce19c15c4abeb4ab872754c6c533b080f54c94f7125f972711a97557967f', 4, 1, 'MyApp', '[]', 0, '2020-03-06 21:16:58', '2020-03-06 21:16:58', '2021-03-06 14:16:58'),
('1f5789448dacc27b85422cdb0a9f5ebc011a09137a5fa813a119aee2d46dd6997577134c88a01e17', 53, 1, 'MyApp', '[]', 0, '2020-04-13 11:46:10', '2020-04-13 11:46:10', '2021-04-13 04:46:10'),
('20f69efb36b62d0c179db7e059b4b4206ed5a6d899e1546bd252a1257d684e820879f42db9e5e3e7', 38, 1, 'MyApp', '[]', 0, '2020-03-31 16:04:31', '2020-03-31 16:04:31', '2021-03-31 09:04:31'),
('214859b6d9307472164bf9a243f90f9c61f23cf7bd794496f19eb625af6747933c4cb320e30287eb', 32, 1, 'MyApp', '[]', 0, '2020-03-31 18:53:24', '2020-03-31 18:53:24', '2021-03-31 11:53:24'),
('21f6d1b2d0f3c1d348e467f6a360fbba856349916c15e9e911489cd956dcadd7186b244ba8078c5e', 6, 1, 'MyApp', '[]', 0, '2021-07-08 13:43:06', '2021-07-08 13:43:06', '2022-07-08 06:43:06'),
('26469ac7b4e10c5c1c47a930064c33f0114ce65a5d174d30261118647547aa1fac0d8c2eed0ff11b', 9, 1, 'MyApp', '[]', 0, '2020-03-19 20:13:13', '2020-03-19 20:13:13', '2021-03-19 13:13:13'),
('27451b870e3d1e67f921e8acaa8ce7bf53b25152d35d90c8d478f44b782c1599f11938d0c06e2db9', 1, 1, 'MyApp', '[]', 0, '2020-02-13 17:39:02', '2020-02-13 17:39:02', '2021-02-13 10:39:02'),
('2807a539510c78a86a09dc806847318662c3a154d121f63a6e9c9c068baa0f6ea65c9afdacb6c163', 9, 1, 'MyApp', '[]', 0, '2020-02-14 14:00:22', '2020-02-14 14:00:22', '2021-02-14 07:00:22'),
('28e8cc93e54dff43a8ecdfb350628637c7bbbe95336bf3d46c95a172b0d032686952252f8ea1df29', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:02:43', '2021-07-06 18:02:43', '2022-07-06 11:02:43'),
('2b41ac5082004d0ff3f66c65d020dc2d9dff0081e96dc1132ae0d0ab4326ed88450a91178377073b', 29, 1, 'MyApp', '[]', 0, '2020-03-31 18:50:42', '2020-03-31 18:50:42', '2021-03-31 11:50:42'),
('2b63f07655ced535a9eb6007daee70e185e01fb4a9cf1ce72044d3ad903f263966cf9a030d5df0eb', 6, 1, 'MyApp', '[]', 0, '2020-03-30 15:23:52', '2020-03-30 15:23:52', '2021-03-30 08:23:52'),
('2b894b6db004673e70b0cf012dc42b68a2c620d23c07ac2b43871d8c4395224c4bb9cf97133d3450', 67, 1, 'MyApp', '[]', 0, '2021-07-05 14:39:18', '2021-07-05 14:39:18', '2022-07-05 07:39:18'),
('2bbb44a445cc21f1836c822bd06c96bd367c7d7caba320c9aeaaf008f53750093841a4488e8f5509', 40, 1, 'MyApp', '[]', 0, '2020-03-31 19:20:37', '2020-03-31 19:20:37', '2021-03-31 12:20:37'),
('2bd9c9698ab4677558a08a00ebd0db14647fd708ec4625c94b340028ce4f2b44aafa9db31f2c901a', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:21:54', '2020-04-06 21:21:54', '2021-04-06 14:21:54'),
('2c7ea7e25eed9503a5484c34f13bab3524e3a47e2bf525db1cdc55ee6a82c638e9dafb348066a1bc', 24, 1, 'MyApp', '[]', 0, '2020-03-31 18:40:03', '2020-03-31 18:40:03', '2021-03-31 11:40:03'),
('2d74dc74e9a8abaf37f23fb9b8c6b9e39b1503343717040ce91207a895d3ca47f0190fc230fc0ca1', 45, 1, 'MyApp', '[]', 0, '2020-03-30 17:02:55', '2020-03-30 17:02:55', '2021-03-30 10:02:55'),
('2de1330a6699740e2526187bd7d34a135213608b091006d1ac73f6c556cee1c59e574a26a7298dd5', 6, 1, 'MyApp', '[]', 0, '2020-04-02 19:18:26', '2020-04-02 19:18:26', '2021-04-02 12:18:26'),
('2ea5813628839ddc8df96e367593f4885ffef6f8becdd044ada428c26bea96ce8ff4beff356a3fa3', 21, 1, 'MyApp', '[]', 0, '2020-03-16 21:04:54', '2020-03-16 21:04:54', '2021-03-16 14:04:54'),
('2edaf0cf6b089e0c14a89c5cbee69f4c208c05f3780accec9d2313fe693c57c5a2330f98dce9d5db', 2, 1, 'MyApp', '[]', 0, '2020-04-05 20:26:22', '2020-04-05 20:26:22', '2021-04-05 13:26:22'),
('2f592c5b3a935a9e95a588a909a5c04781c7e98cb70186b4bf371335a2a1faa2146dcfc3b3747c42', 31, 1, 'MyApp', '[]', 0, '2020-03-31 18:52:20', '2020-03-31 18:52:20', '2021-03-31 11:52:20'),
('30051d6f90199a036969a3ecb86102ba1e140c20c294f2fc9562e69a48d4237827a902c355a7b639', 64, 1, 'MyApp', '[]', 0, '2021-06-23 15:08:51', '2021-06-23 15:08:51', '2022-06-23 08:08:51'),
('3013393f3c0e05bb79d2fb3f26e068cc2cbd8b6e42c6e05c6a1f4f8cda626700be70826beb7a2a29', 6, 1, 'MyApp', '[]', 0, '2020-02-19 14:29:44', '2020-02-19 14:29:44', '2021-02-19 07:29:44'),
('3204884e218a3c59250fe3332d71e56a9a64f6f4883f22b08ba8d4db77d5c784333aba1fc146a454', 4, 1, 'MyApp', '[]', 0, '2020-02-11 15:45:24', '2020-02-11 15:45:24', '2021-02-11 08:45:24'),
('323fa273486e932292941c19ef03fb2ab153697ccc194fbe565ca28432c09dc7051ec343f8b9348c', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:14:39', '2020-04-06 21:14:39', '2021-04-06 14:14:39'),
('324d7a829e30630fd2cdcc28b6c826fd8456042f6580f1e14b4f099bfc31d88094e54e6fe1360257', 51, 1, 'MyApp', '[]', 0, '2020-04-07 12:35:59', '2020-04-07 12:35:59', '2021-04-07 05:35:59'),
('333dcf9db0aeb99052b3728c7d818db3b0f8b056877588ad1795727b2148e5061dd268c2374cc8de', 52, 1, 'MyApp', '[]', 0, '2020-04-14 14:34:30', '2020-04-14 14:34:30', '2021-04-14 07:34:30'),
('335162f7e9f225bbf1ba6757a9b37dc37797efe55c20b636eb7d14feb1f1f22a67a5f52f4d3e34d3', 9, 1, 'MyApp', '[]', 0, '2020-03-19 21:44:37', '2020-03-19 21:44:37', '2021-03-19 14:44:37'),
('33741d493b5411ffea3228b9cd22cd594071e22a871618575d8c69d23a20ea807bb84187f2685a68', 6, 1, 'MyApp', '[]', 0, '2020-03-31 18:24:50', '2020-03-31 18:24:50', '2021-03-31 11:24:50'),
('3387bdd369b81ccbbee780070b1650169943b87714e39ccf336c75ba27c280470e9aff9e6832baf2', 4, 1, 'MyApp', '[]', 0, '2020-04-14 13:57:35', '2020-04-14 13:57:35', '2021-04-14 06:57:35'),
('33c691e7cc012b5e9c656939f8e0ea769894c4540333dbbb36a7ddbed170494cfadb3201086d320b', 9, 1, 'MyApp', '[]', 0, '2020-04-16 13:40:40', '2020-04-16 13:40:40', '2021-04-16 06:40:40'),
('350573ea0f215f81e55774846216f8fb379d06e3ee0ce4aa7286de4258827657f9ac5103e0ec6866', 9, 1, 'MyApp', '[]', 0, '2020-04-13 11:56:05', '2020-04-13 11:56:05', '2021-04-13 04:56:05'),
('3568ee1c389f81757414c812097b9ae714c650d77a83b4a8d59bb51fb066d18547f8e8043885768a', 9, 1, 'MyApp', '[]', 0, '2020-05-08 14:28:44', '2020-05-08 14:28:44', '2021-05-08 07:28:44'),
('35e8016c5a472c1940fd0cf95fc4f75edb9c4797b3c1ab90ececfcffcf4a01e54e9e877f2fb4e1b1', 9, 1, 'MyApp', '[]', 0, '2020-03-19 17:16:20', '2020-03-19 17:16:20', '2021-03-19 10:16:20'),
('35f24ca7ec88c587b0619cf1a12b19ad195121b4e8dc61818bca10f6b6089543462b005562fdf7d9', 9, 1, 'MyApp', '[]', 0, '2020-03-19 16:13:46', '2020-03-19 16:13:46', '2021-03-19 09:13:46'),
('362fcb85b24f3f24a3ce85bc6de14e359f7343193bb3456bda4ae4ecdf59318f55fb9d9f3da95f5e', 71, 1, 'MyApp', '[]', 0, '2021-07-06 17:58:15', '2021-07-06 17:58:15', '2022-07-06 10:58:15'),
('3700f2381a3d247102967baad1cb2f37970e56359ead5fe1efabfacd64c170486eb28807d04d470a', 51, 1, 'MyApp', '[]', 0, '2020-04-08 10:40:51', '2020-04-08 10:40:51', '2021-04-08 03:40:51'),
('37d194199cd0011960475a594e441d9fec6d8c511429e49217249417429b541bf91a28414a2fbb6f', 9, 1, 'MyApp', '[]', 0, '2020-03-19 20:28:17', '2020-03-19 20:28:17', '2021-03-19 13:28:17'),
('39a6fe22cac716eaf37fa31333cd60fc32730bd6746a05622798c5d430c3c5e79e740ff0014d2ad7', 6, 1, 'MyApp', '[]', 0, '2020-02-15 18:18:26', '2020-02-15 18:18:26', '2021-02-15 11:18:26'),
('39c749e493b4207bc861ec5cf66e68af7d09cca959f581c6a8999a0683753d907edb18e4c786f8fb', 33, 1, 'MyApp', '[]', 0, '2020-03-31 17:11:49', '2020-03-31 17:11:49', '2021-03-31 10:11:49'),
('3b90544e9fd00550f6ddff6c2cffba5d1ff5de32efc3a19d16830e7b98e2e803fbba10d99fa0eb28', 56, 1, 'MyApp', '[]', 0, '2020-04-16 16:48:15', '2020-04-16 16:48:15', '2021-04-16 09:48:15'),
('3ba36c3f6671fd59cd671031a663b8236bdbbf9e82b4dd4bd6992c9fefea70e2394394729489a906', 65, 1, 'MyApp', '[]', 0, '2021-06-27 19:48:47', '2021-06-27 19:48:47', '2022-06-27 12:48:47'),
('3be1a8705c45cb1592a1b78161fecb4eb5da3db6f996d886ca5a0acc6514562f7610e28a261c0975', 9, 1, 'MyApp', '[]', 0, '2020-02-12 19:43:21', '2020-02-12 19:43:21', '2021-02-12 12:43:21'),
('3c5f747996b9ce44601256b25f9fe50f21ecc792652ca4c8589a2957f8d8bc52e601ade9236e74c8', 1, 1, 'MyApp', '[]', 0, '2020-02-11 18:00:05', '2020-02-11 18:00:05', '2021-02-11 11:00:05'),
('3cb350d8c3c93743c408ae9a17332f255a073d4454a188ce8f481a82596ce33981090b3e1db7d2b8', 9, 1, 'MyApp', '[]', 0, '2020-02-14 14:24:32', '2020-02-14 14:24:32', '2021-02-14 07:24:32'),
('3edb64a73b8060b2112b92a5feae58754e752e4dadfd1ff8ee4ffc4a2fd15eafaa746ee867ad5cd0', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:19:59', '2020-04-06 21:19:59', '2021-04-06 14:19:59'),
('400aef2c29245e0a61f3565c97e1e6bf55b92f42b9b267599935fc2b3d48e397a1091827ebe346f6', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:25:32', '2020-04-06 21:25:32', '2021-04-06 14:25:32'),
('40a947d223518037225a948a92d39f738ff630596a009235d022c28d7d29b3b8c7e2f97266a0c279', 51, 1, 'MyApp', '[]', 0, '2020-04-06 16:10:49', '2020-04-06 16:10:49', '2021-04-06 09:10:49'),
('40d6e771f2b3a7a5e657ce0c6b75acdb937dc3b745c178a684f9c29f6cd4e5eac3aa595d1d94703b', 58, 1, 'MyApp', '[]', 0, '2020-04-16 20:17:04', '2020-04-16 20:17:04', '2021-04-16 13:17:04'),
('410dcd978ea27d0b72d64b5b0b9d005118abe4c3149d0f70ce8e8288c9c7714a18ebb966e284abd3', 32, 1, 'MyApp', '[]', 0, '2020-03-30 16:11:35', '2020-03-30 16:11:35', '2021-03-30 09:11:35'),
('41d81f9144015d9496277cbc1bb4795bd8a96ad5c504827a5cf8c65ee2aa4f1ed875d6bdc3677b71', 9, 1, 'MyApp', '[]', 0, '2020-03-16 16:45:48', '2020-03-16 16:45:48', '2021-03-16 09:45:48'),
('41e5c20e494c4364d996f3e54bf8a23fb9887b8a9f11614e7f2037c3201b1ad4ef3eec35c18dbb4f', 9, 1, 'MyApp', '[]', 0, '2020-02-21 20:52:34', '2020-02-21 20:52:34', '2021-02-21 13:52:34'),
('43dd0f35da96fa4fa903460c15f9adba7ff89500362673efef6cff96e415c48c23050de5b0d2f579', 6, 1, 'MyApp', '[]', 0, '2021-07-06 18:31:45', '2021-07-06 18:31:45', '2022-07-06 11:31:45'),
('45a39f3f63f825a3cda8fde11a9b5b5121c672f39da4597d8913c134dee2fbfc17a6503474e06ed1', 68, 1, 'MyApp', '[]', 0, '2021-07-05 14:42:21', '2021-07-05 14:42:21', '2022-07-05 07:42:21'),
('45aabf1d4d8a421f93325c41278e68775473a55453a364392464b7f4731d86fea5eb54b07bad1fc7', 24, 1, 'MyApp', '[]', 0, '2020-04-02 19:55:15', '2020-04-02 19:55:15', '2021-04-02 12:55:15'),
('46b2cd5a1b82bf8fa79b3e088135885ea9d3d7a2b17a352eec30cc8981d7b71d6ed3377baa9a8db2', 14, 1, 'MyApp', '[]', 0, '2020-03-20 20:23:06', '2020-03-20 20:23:06', '2021-03-20 13:23:06'),
('474e1e1706ade13fdc93a0be16c52b2eb047b7137df27c12088bfb3014bfd7052bdd541610364037', 82, 1, 'MyApp', '[]', 0, '2021-07-09 18:11:29', '2021-07-09 18:11:29', '2022-07-09 11:11:29'),
('48a7311e68f22cf9bdd7e415a50dcffdb493149b65c20c13af893152d59621ab9b7c5e4cf8475e1d', 4, 1, 'MyApp', '[]', 0, '2021-07-07 21:01:01', '2021-07-07 21:01:01', '2022-07-07 14:01:01'),
('4ad99f2b1d54b45c7fd041ece9c8b8762b4a234313cd542d42926585773500f3e70fcb54eb41d3ff', 7, 1, 'MyApp', '[]', 0, '2020-02-11 15:48:17', '2020-02-11 15:48:17', '2021-02-11 08:48:17'),
('4af56cf19cab3875de295ceb927e5948b42e359fbba817746931adff38f55f1d334d4ad5ed4dc375', 9, 1, 'MyApp', '[]', 0, '2020-03-18 19:47:20', '2020-03-18 19:47:20', '2021-03-18 12:47:20'),
('4b5d376a8d8567ddca83b607fad6fa2eb816e67ed06ec629167630eac2c5154245586e2f5b9d1af4', 9, 1, 'MyApp', '[]', 0, '2020-02-24 19:57:18', '2020-02-24 19:57:18', '2021-02-24 12:57:18'),
('4b72bc0b1355ceb10290be88d22b045a68ec7a55b0354bf2040e7aa1602023e568101bf405fd6343', 41, 1, 'MyApp', '[]', 0, '2020-03-30 16:45:58', '2020-03-30 16:45:58', '2021-03-30 09:45:58'),
('4b876767cd375bd2e55358b8985fcbd1acd8730e4a712e59ec2a178c4ac7e5eca1bd33b2b277be07', 4, 1, 'MyApp', '[]', 0, '2020-04-15 20:45:43', '2020-04-15 20:45:43', '2021-04-15 13:45:43'),
('4d22471571896f33ebc3fe9f3b4888915a83f07d440565ff6265daee62ca07478eb1e7446db2bb6d', 51, 1, 'MyApp', '[]', 0, '2020-04-06 14:05:48', '2020-04-06 14:05:48', '2021-04-06 07:05:48'),
('4e2a4488f438eeba3088854e465ef9c6d9b6ea4185728b1e3cd88495eca66cde97c9b91dab5f1812', 9, 1, 'MyApp', '[]', 0, '2020-03-19 12:39:32', '2020-03-19 12:39:32', '2021-03-19 05:39:32'),
('4f8595b9c0822f5565ed98833d0f238cb110d8c826bf848a3ced02049cb72c3f1325e50d3cb11033', 78, 1, 'MyApp', '[]', 0, '2021-07-09 01:12:43', '2021-07-09 01:12:43', '2022-07-08 18:12:43'),
('518cd61075e7f6dd87d7d6a1e81a25d7f44061b9d64128482d407ed22b021cb63917bc1df16f51a0', 62, 1, 'MyApp', '[]', 0, '2021-06-23 14:29:51', '2021-06-23 14:29:51', '2022-06-23 07:29:51'),
('529d761ae323c2ec86b006f289230d801cbd0acb4a8ecd2beff0502039d50407e05c3172f4c8f74d', 51, 1, 'MyApp', '[]', 0, '2020-04-08 17:12:44', '2020-04-08 17:12:44', '2021-04-08 10:12:44'),
('540fce76c08505fe86512df366e6ed477e3bdc2d8d9d6f5e8222f32da2166073ec7ff0d6275ba0af', 6, 1, 'MyApp', '[]', 0, '2020-03-30 15:03:05', '2020-03-30 15:03:05', '2021-03-30 08:03:05'),
('544d2bd6af786171e9c17fe9e86a1b09d49bb8a1733a3365f19c5a916e7a926ec07af0d2f5c4b4d5', 75, 1, 'MyApp', '[]', 0, '2021-07-06 20:47:16', '2021-07-06 20:47:16', '2022-07-06 13:47:16'),
('5483b527b9d2406f76ac47cd3c2f2e657d297c521fe8a36e85ac89dfa6667aafce2f602bc927e5c3', 78, 1, 'MyApp', '[]', 0, '2021-07-08 17:36:21', '2021-07-08 17:36:21', '2022-07-08 10:36:21'),
('54ebcb62e98a9db7f7e594dca3b657d31fbd5bdcabe5c5bc318a45e7290e7d088d1e564dbf018e3b', 81, 1, 'MyApp', '[]', 0, '2021-07-09 11:44:24', '2021-07-09 11:44:24', '2022-07-09 04:44:24'),
('550925b1db3650586b140e0da820872fc13cce04a487b1673e43cf380a314aed6a16aba32a90741c', 3, 1, 'MyApp', '[]', 0, '2020-02-10 21:28:09', '2020-02-10 21:28:09', '2021-02-10 14:28:09'),
('558bcfa07d9ff2add67457454a73abad75589386c150b7859aa94cc98022b1e55b9d72120589dc5c', 46, 1, 'MyApp', '[]', 0, '2020-03-31 12:38:58', '2020-03-31 12:38:58', '2021-03-31 05:38:58'),
('55e22c72b9fd10cd268c17f223a86e0afc401451a3dda816e69f0ccb40c696955bac54d24856c445', 31, 1, 'MyApp', '[]', 0, '2020-03-31 17:04:24', '2020-03-31 17:04:24', '2021-03-31 10:04:24'),
('55ff096e77c84f730d31d2d94330c60a0496f069c1f58e0fe75c06f6aec077773e1ef4200c4230fa', 6, 1, 'MyApp', '[]', 0, '2020-04-05 14:46:18', '2020-04-05 14:46:18', '2021-04-05 07:46:18'),
('565e7a4a3a9b8b7e8130d922700f1aa2f335b796fc44ab50907ba59b5d7709bc8403a7d51af13705', 14, 1, 'MyApp', '[]', 0, '2020-02-15 19:10:51', '2020-02-15 19:10:51', '2021-02-15 12:10:51'),
('57ffc183d598d3c797bad18e6f63b0b8097da11e8f6ee7c3814227b4c3d0b0ecb31d44e720482b96', 16, 1, 'MyApp', '[]', 0, '2020-02-24 20:32:35', '2020-02-24 20:32:35', '2021-02-24 13:32:35'),
('585866044198e6b86ff42862d9ecc8fa4f70d565ef85d940d7aa38a14805010743d3536929af7c8d', 63, 1, 'MyApp', '[]', 0, '2021-06-23 14:44:58', '2021-06-23 14:44:58', '2022-06-23 07:44:58'),
('5982c9e511bc3401752710884d6ea8ebaf9143347f337d4d6244f2ec07d0604c6ebebf29bbcef80f', 9, 1, 'MyApp', '[]', 0, '2020-03-18 11:37:29', '2020-03-18 11:37:29', '2021-03-18 04:37:29'),
('59d4ca18a90c6874c8cfb69a951b904650682d3e384dc6ef0ce387c2b887f85a60dd37a721d9c31b', 27, 1, 'MyApp', '[]', 0, '2020-03-30 15:49:27', '2020-03-30 15:49:27', '2021-03-30 08:49:27'),
('5a10751585f22b30bb2b7d2a700e230885dacb4ceed7ef64c720460e642e83d6c8daa1e6b449f068', 36, 1, 'MyApp', '[]', 0, '2020-03-31 16:01:03', '2020-03-31 16:01:03', '2021-03-31 09:01:03'),
('5c50c7dd30ed46b86df20d436cbb4bc9fe2c050178ff176f1798d1cf9d42410c1bc224c684c5bb52', 16, 1, 'MyApp', '[]', 0, '2020-02-18 16:53:47', '2020-02-18 16:53:47', '2021-02-18 09:53:47'),
('5d782955282397ad755a501705db1ae13da1e7eece57f0245d4d6da784f62f2061ad7638a2fa9d7d', 1, 1, 'MyApp', '[]', 0, '2020-02-15 19:19:52', '2020-02-15 19:19:52', '2021-02-15 12:19:52'),
('5df9aeebe52200135126adcef2b707075e21827849296f2871d34b14c21f57599f06b8da125f43e9', 76, 1, 'MyApp', '[]', 0, '2021-07-06 21:01:57', '2021-07-06 21:01:57', '2022-07-06 14:01:57'),
('5e0c6ce8f277a9000eaed8444469c6ebcd6af6bab3a934fac3626e02df71c51601b1d95efcfe9446', 9, 1, 'MyApp', '[]', 0, '2020-02-14 15:59:36', '2020-02-14 15:59:36', '2021-02-14 08:59:36'),
('5e79088c8823938a8761e54b87df24f4203b123b8196a28a0522ed54f30b4098d966a9675f3162e5', 6, 1, 'MyApp', '[]', 0, '2020-03-31 15:36:08', '2020-03-31 15:36:08', '2021-03-31 08:36:08'),
('5f115ca7339c8defeb38046f5b3f8cdea33f00046376286e2180dbd9402b23755c9955595349cf00', 1, 1, 'MyApp', '[]', 0, '2020-02-15 18:58:08', '2020-02-15 18:58:08', '2021-02-15 11:58:08'),
('5f1b6572e9ef2d5773d56afaf78e50503526f9f08b9d14f8ca25e6b9defb8b650c600bc5b13c43b5', 9, 1, 'MyApp', '[]', 0, '2020-04-16 20:05:00', '2020-04-16 20:05:00', '2021-04-16 13:05:00'),
('5ff1044d7e4271ef9185df7173b5f30f9f17ad8e75fd53d8298a4516a7a058a41047f9915c7af7b7', 4, 1, 'MyApp', '[]', 0, '2020-02-14 13:56:55', '2020-02-14 13:56:55', '2021-02-14 06:56:55'),
('6096ef29dc32b7b7e8459d9346174d83ff174c8c270582a9f6a30f28cab4cfa042a5a76902aad911', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:03:08', '2021-07-06 18:03:08', '2022-07-06 11:03:08'),
('60d1dcdad7cee4b4f6648e7ffe4cc444482e0ac5830c8b1e223ff986de6429142e2c7485db4ca894', 31, 1, 'MyApp', '[]', 0, '2020-03-30 16:08:51', '2020-03-30 16:08:51', '2021-03-30 09:08:51'),
('6153d4a2c9c383189b150419bc8e2add7e8f3994e74cb2f25c690e957e276f17f2c601328a8ddc58', 6, 1, 'MyApp', '[]', 0, '2020-02-11 18:51:17', '2020-02-11 18:51:17', '2021-02-11 11:51:17'),
('615fb4e3f627ca5431481a3dd2b60aaa36ce1f3fc56182e50182378925f99b70d06e61e2355b83d1', 16, 1, 'MyApp', '[]', 0, '2020-02-24 20:34:15', '2020-02-24 20:34:15', '2021-02-24 13:34:15'),
('61b19e7f72d88db677d619e4a856b7c23cb95efdca46cd627b336fae08ba136d52c8924893282d9d', 51, 1, 'MyApp', '[]', 0, '2020-04-07 12:36:17', '2020-04-07 12:36:17', '2021-04-07 05:36:17'),
('626b4fe99a08540e36967fa2d45c742b9c9577978babb722b7ce51ed20bb94eed3c7e24894cb2040', 78, 1, 'MyApp', '[]', 0, '2021-07-08 20:42:23', '2021-07-08 20:42:23', '2022-07-08 13:42:23'),
('628ad06003eaed4909707b4dfbbda755a16bc69ad43ab2006d69632d4d20f2da3a92e32ad82ae141', 9, 1, 'MyApp', '[]', 0, '2020-03-20 16:15:37', '2020-03-20 16:15:37', '2021-03-20 09:15:37'),
('63188b2d3a594ad6df7726693a6a87e2d895930f46672adf34369cda647dcda9d738d50ecf3c0646', 78, 1, 'MyApp', '[]', 0, '2021-07-09 01:47:48', '2021-07-09 01:47:48', '2022-07-08 18:47:48'),
('63cc321e01747911291661ad89ee249518a732bc7288b1cabba116e3c0d5d45d9670edf88c08b31a', 51, 1, 'MyApp', '[]', 0, '2020-04-06 14:24:43', '2020-04-06 14:24:43', '2021-04-06 07:24:43'),
('6464c9d26e02689adc5963d2b7c4d8fa470f856ecd83ed849c5e086f2067f6a004324dd6335b93e1', 53, 1, 'MyApp', '[]', 0, '2020-04-10 13:21:30', '2020-04-10 13:21:30', '2021-04-10 06:21:30'),
('656ccdca5a5c7881cd9e4eea38959b3dc38cff6f3b889c217651d034945fd431c47092ed8bcd6ee4', 83, 1, 'MyApp', '[]', 0, '2021-07-11 16:19:03', '2021-07-11 16:19:03', '2022-07-11 09:19:03'),
('66bf2b5cf0f62da844dbaabeaf743f6f4ca2cf1a0f2294187920b461a3efabc02464e205b49de0a7', 20, 1, 'MyApp', '[]', 0, '2020-02-24 21:00:25', '2020-02-24 21:00:25', '2021-02-24 14:00:25'),
('6755b19acae4b18bcd8939f463ddf8bf707d232b0efc3deafa0e2e057349543adbf4171e0b4fb172', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:30:10', '2020-04-06 21:30:10', '2021-04-06 14:30:10'),
('6840e7b194e6c9855b86a2b61daae2fec81eadb78a386e7110c362b990080fde094c5c9294fde585', 51, 1, 'MyApp', '[]', 0, '2020-04-06 14:02:47', '2020-04-06 14:02:47', '2021-04-06 07:02:47'),
('68c9942aecd63f2996aa23c39f23cd861d2e8ed3cea758741ce81bdacf3eaebe1ab3f8f059e4141f', 6, 1, 'MyApp', '[]', 0, '2020-02-11 14:50:11', '2020-02-11 14:50:11', '2021-02-11 07:50:11'),
('68fd1e532efb1a69a946f985daadd168ea4f9fd663f5488d9db136126b398cbd2ae9b9eb4d533d2e', 51, 1, 'MyApp', '[]', 0, '2020-04-08 20:33:55', '2020-04-08 20:33:55', '2021-04-08 13:33:55'),
('694f1b9f705a767e243a8802cc1435e00a52d063fec3081c3451ee4c6b2651d9f7841a0108225f7d', 53, 1, 'MyApp', '[]', 0, '2020-04-13 19:56:09', '2020-04-13 19:56:09', '2021-04-13 12:56:09'),
('6a02f17794d0c3d8b2de7a45a6b63bfba5b6f8a9deccfd8ea3b94597526e6423f748bb6b5cfae16a', 40, 1, 'MyApp', '[]', 0, '2020-03-31 16:11:34', '2020-03-31 16:11:34', '2021-03-31 09:11:34'),
('6b3ab42f7c7477fa9bd2580aae80f9c0f5d24fb0534ecb349d9039844d39115a71b449b3a8f22f9f', 26, 1, 'MyApp', '[]', 0, '2020-03-31 16:35:33', '2020-03-31 16:35:33', '2021-03-31 09:35:33'),
('6c34beb70fb46051f3fe5ade86926de1ed4b052a924d6b408cd9e2199c0827f6469011b8553a9f02', 37, 1, 'MyApp', '[]', 0, '2020-03-30 16:37:39', '2020-03-30 16:37:39', '2021-03-30 09:37:39'),
('6c7dbedf01593b71bba5aa4ee0ff9b3773e7f8ad39fb3804f1f0ada55841af03a090c88583adcd53', 51, 1, 'MyApp', '[]', 0, '2020-04-06 14:05:49', '2020-04-06 14:05:49', '2021-04-06 07:05:49'),
('6e1cc4c53ffc3a3e92c03e1c50a2b5c7d91c8544ea002acf8be9b1b42ba13c4df31662b5e3eb0c52', 4, 1, 'MyApp', '[]', 0, '2021-07-06 19:27:40', '2021-07-06 19:27:40', '2022-07-06 12:27:40'),
('6e40135d17792978a48c1df0f07719f91040d7420a010f3a0733bbf845625513eba43963d8e6f800', 9, 1, 'MyApp', '[]', 0, '2020-02-12 19:35:47', '2020-02-12 19:35:47', '2021-02-12 12:35:47'),
('6ee6f60fbe3265f43791035f77a2265102192d9a3c54d3377dfda56c458266a888b22c110e12c7ee', 39, 1, 'MyApp', '[]', 0, '2020-03-31 19:13:10', '2020-03-31 19:13:10', '2021-03-31 12:13:10'),
('6f315f1c19c317ae1d97f22b76e12860105da18f39f299c81ccad6ea829ba21ce4c198e57aecf0ca', 59, 1, 'MyApp', '[]', 0, '2021-06-22 19:33:15', '2021-06-22 19:33:15', '2022-06-22 12:33:15'),
('6fdb5fd6dbc6ade4ebc5a4d09882f2caa653f7d28b812c21f3adbb18c4275c6e85c91c218be59caa', 26, 1, 'MyApp', '[]', 0, '2020-03-31 18:41:11', '2020-03-31 18:41:11', '2021-03-31 11:41:11'),
('6ffad9cf50ac8ed9ba2ab80984c2fd9762b454c683004aeb3800fb286f190c8c7895de4b83372e88', 4, 1, 'MyApp', '[]', 0, '2020-03-19 19:33:09', '2020-03-19 19:33:09', '2021-03-19 12:33:09'),
('70afa93a794fffbb531add94c0020b56ca2d2c425af20ecbd47e66094a0f315c9ff27fcf4a5a28df', 9, 1, 'MyApp', '[]', 0, '2020-03-24 16:57:06', '2020-03-24 16:57:06', '2021-03-24 09:57:06'),
('722b530eaeb51de18d0263086ddbd2b843a001657b05d6161d54e1a8ae878da669593d2f5468ac31', 1, 1, 'MyApp', '[]', 0, '2020-02-20 17:36:56', '2020-02-20 17:36:56', '2021-02-20 10:36:56'),
('72f322530ef0c113a371863855257c90d15b7e29f7dea3b7c9e9807f4653c597ddeaa78b650cf65e', 9, 1, 'MyApp', '[]', 0, '2020-05-08 15:05:57', '2020-05-08 15:05:57', '2021-05-08 08:05:57'),
('7320675dbd5d189660a12577531e8b737e36f27c59d3be0af0072c476e990a1f136247b1cc1727ec', 51, 1, 'MyApp', '[]', 0, '2020-05-01 20:01:47', '2020-05-01 20:01:47', '2021-05-01 13:01:47'),
('7378f340e19c41e1a149f13174f225fc03c4ca56de77b07c4f72b77e92cdc2da14ebeddcf6fc4450', 4, 1, 'MyApp', '[]', 0, '2020-03-05 17:07:41', '2020-03-05 17:07:41', '2021-03-05 10:07:41'),
('73a4bea299d743a1ae7ba8e10f20fb8f3753ebc126c1eb9f259114675500597e7471e5949ce5e3c3', 1, 1, 'MyApp', '[]', 0, '2020-04-15 22:00:38', '2020-04-15 22:00:38', '2021-04-15 15:00:38'),
('74422c808735b3a576e1656184991517a49fcc82f875e05301a84e6e57ef96707d60792ee128be6f', 33, 1, 'MyApp', '[]', 0, '2020-03-30 16:14:49', '2020-03-30 16:14:49', '2021-03-30 09:14:49'),
('74e9c927b6c319fe5ca98c3472a3b09b2ffcd9cd2d33aa0a6bf0316bdcb142c9a9cbceb639716edb', 23, 1, 'MyApp', '[]', 0, '2020-03-20 13:59:49', '2020-03-20 13:59:49', '2021-03-20 06:59:49'),
('75ce2bf4bf248e1e6a915843da0b88c59acdf536687c666e5a0346d6c761be5ac2b66fead6141ad2', 9, 1, 'MyApp', '[]', 0, '2020-03-30 11:18:28', '2020-03-30 11:18:28', '2021-03-30 04:18:28'),
('75f7b209b8f693a178c76d9dfee1949dccd55e604a02be4c39492c9834843508d229819bfce10cec', 58, 1, 'MyApp', '[]', 0, '2020-04-16 17:04:30', '2020-04-16 17:04:30', '2021-04-16 10:04:30'),
('76b2129c2ef9e3c8ba2f55056126f0231f667b8d4656c2fb3cd852d8e0b7d7ff15980b82eaed0c82', 36, 1, 'MyApp', '[]', 0, '2020-03-31 19:06:13', '2020-03-31 19:06:13', '2021-03-31 12:06:13'),
('778a7ce9d7207ea6e030d8fdf69e2f2baf14d8edc93e66c3825acfb9b5bbdc4c9847d49b182d2088', 51, 1, 'MyApp', '[]', 0, '2020-04-07 12:33:06', '2020-04-07 12:33:06', '2021-04-07 05:33:06'),
('77c0871237f3eca2d7c208fc32fbeffb5617346e694baebd405b509d34dfb79b21cd43cb98c7db4c', 9, 1, 'MyApp', '[]', 0, '2020-02-13 19:39:01', '2020-02-13 19:39:01', '2021-02-13 12:39:01'),
('77ef08fbbf2cd767ed0dd4ceab07dde68f420cd5f57bfdee3306fe00547f12ae55560fdf51eafe14', 51, 1, 'MyApp', '[]', 0, '2020-04-07 12:26:27', '2020-04-07 12:26:27', '2021-04-07 05:26:27'),
('78072f58573b4603eff9a05a215c82a90f9e31f6a7145d274c116a1b746d6e3b0e0cf0735b98c824', 9, 1, 'MyApp', '[]', 0, '2020-03-18 19:46:41', '2020-03-18 19:46:41', '2021-03-18 12:46:41'),
('7871c575d96acb815d70d83d94a9b41606818b338100ae0a2f20b2d78d72c6bbf428c4df3afbb04e', 9, 1, 'MyApp', '[]', 0, '2020-04-05 19:03:34', '2020-04-05 19:03:34', '2021-04-05 12:03:34'),
('78b4bd4359cbbde5891c358da66b13f3f0c967e26b99a9994e80b3ea526e114e8bde380682f0b7ff', 1, 1, 'MyApp', '[]', 0, '2020-02-11 18:12:13', '2020-02-11 18:12:13', '2021-02-11 11:12:13'),
('796a6cb8cc6aea799fb5a6973ecd622a3a3c298c115b726bb944301d8615cc4ce90f844b0eb2c6b0', 9, 1, 'MyApp', '[]', 0, '2020-02-14 20:32:55', '2020-02-14 20:32:55', '2021-02-14 13:32:55'),
('7a83c228c0b0a4cdf3a5e84fb21cc34dba544a04f5a9cb6b3d10ad479c2c039ffed69542a66b84eb', 51, 1, 'MyApp', '[]', 0, '2020-04-06 19:28:02', '2020-04-06 19:28:02', '2021-04-06 12:28:02'),
('7ac67d41a9ac7382d16e379d77f78c96777b8321999503e97ffcec710a3918caa13cdea5a4658e23', 2, 1, 'MyApp', '[]', 0, '2020-03-17 18:29:17', '2020-03-17 18:29:17', '2021-03-17 11:29:17'),
('7ad668f0b95d4f3994315e17588f4edfceb50f55c8d349e4e99735fb4fbdb8be294ef657e1f75df5', 51, 1, 'MyApp', '[]', 0, '2020-04-07 13:41:27', '2020-04-07 13:41:27', '2021-04-07 06:41:27'),
('7c106a62d0694c78d811a9d50c487f8a52788b1ce76e0a7bd4110bb53912ce36544f13cd6ac01c42', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:58:16', '2020-04-06 21:58:16', '2021-04-06 14:58:16'),
('7c2d136d3786e26d012d412c2d6a17781519412c9f0855f9fe865a98972b4574cba7c49ff053a08e', 6, 1, 'MyApp', '[]', 0, '2020-03-31 18:56:01', '2020-03-31 18:56:01', '2021-03-31 11:56:01'),
('7fb3c380ec3cd8eda48b46c01815911f1bda61bf102b360c099788120831d457187c98b3061bbd04', 9, 1, 'MyApp', '[]', 0, '2020-04-15 13:10:11', '2020-04-15 13:10:11', '2021-04-15 06:10:11'),
('8013cbcf622ee7ce6eb03f44802a49f56bb6ddc0698c8214fa5b757552462ad015973431cdb3449d', 47, 1, 'MyApp', '[]', 0, '2020-03-31 12:55:52', '2020-03-31 12:55:52', '2021-03-31 05:55:52'),
('810c8c6c609e0d8282834eb7f73a30a48d30b1012448d38ce5bb1230000ad899d33bb0f3b19f8b03', 9, 1, 'MyApp', '[]', 0, '2020-04-08 20:34:21', '2020-04-08 20:34:21', '2021-04-08 13:34:21'),
('81e81727128dc8340cd9c88b3720ec3d74791e9d725529040bfe74e0b381535fd8ace4d2dbac5180', 9, 1, 'MyApp', '[]', 0, '2020-03-20 17:38:08', '2020-03-20 17:38:08', '2021-03-20 10:38:08'),
('82a116fd8ba72ede6fd9f5474127681006cf4333732b779d3963ff7df5e86463275b2e6d899612e1', 51, 1, 'MyApp', '[]', 0, '2020-04-06 15:51:42', '2020-04-06 15:51:42', '2021-04-06 08:51:42'),
('82d386310953eee487a4d49234cb079d8ffc9495d3722d9d3d51c628f7244b73498efcc3663e5704', 38, 1, 'MyApp', '[]', 0, '2020-03-31 19:10:12', '2020-03-31 19:10:12', '2021-03-31 12:10:12'),
('82fcf5697c8e588ba52512aa37ba00ef7f3d4f40f5008a5be47d4c9f7d3545d02027081608a0b54d', 1, 1, 'MyApp', '[]', 0, '2020-02-24 21:17:55', '2020-02-24 21:17:55', '2021-02-24 14:17:55'),
('8343af3e67452ebe6a66e0403ec23a63010d3c70a9acc357fa8410ffe856ed64bc6e7769e53a01f9', 4, 1, 'MyApp', '[]', 0, '2020-04-29 19:33:34', '2020-04-29 19:33:34', '2021-04-29 12:33:34'),
('83534bf4fbadd5cb2d8c50b6ce4e0f65b97eb2fbd0e73b7fb5f1999c8689a7c85b4b16f66c5485a0', 8, 1, 'MyApp', '[]', 0, '2020-02-12 19:16:40', '2020-02-12 19:16:40', '2021-02-12 12:16:40'),
('83ef4bc9397c35074c1b94cd7865281e829860a62c58e027a7f0eb49fc9f1041bc1e45b43bb46c30', 27, 1, 'MyApp', '[]', 0, '2020-03-31 16:45:03', '2020-03-31 16:45:03', '2021-03-31 09:45:03'),
('865c4d566f0a48458426f2b5a3d011039e04decb23a4bbc9ec36ec8b1e2079003052d27b4b63e5f6', 9, 1, 'MyApp', '[]', 0, '2020-05-08 14:50:38', '2020-05-08 14:50:38', '2021-05-08 07:50:38'),
('866e8f49b49dcc0aa9ad24f0a77d3416e69e67f9a661cfded26032f86c19317d46ff6b9f477b2fa6', 51, 1, 'MyApp', '[]', 0, '2020-04-08 11:22:38', '2020-04-08 11:22:38', '2021-04-08 04:22:38'),
('87427f3bb2a6a39e03330cb1dacd86d9cbf3ea3d4c572be4f2077022f229bfbc0e2b4eb0b95b85d1', 9, 1, 'MyApp', '[]', 0, '2020-03-18 17:04:40', '2020-03-18 17:04:40', '2021-03-18 10:04:40'),
('879f0694aa260c139160ab0e1ee372f275fbe3d76b09db5c6dcba31cb99708fbc16c9f8a9c968370', 80, 1, 'MyApp', '[]', 0, '2021-07-09 02:22:31', '2021-07-09 02:22:31', '2022-07-08 19:22:31'),
('89cbdd948ac5946a3b6eb7bb6890ecc7650e59516b83e222f7c5ed6292beb013157634d8abe584d2', 45, 1, 'MyApp', '[]', 0, '2020-03-31 16:30:06', '2020-03-31 16:30:06', '2021-03-31 09:30:06'),
('8a35c46ae72e3f92e60f270154851dbe1bc44792281edbb991989629587f712b679088967a3c13b8', 4, 1, 'MyApp', '[]', 0, '2020-02-13 19:38:20', '2020-02-13 19:38:20', '2021-02-13 12:38:20'),
('8adaf331d8ca50a4dcfc7b39ac4724440114bf6e9d66f6e2a0c654c2d62a7edab99cd6c8f728d817', 84, 1, 'MyApp', '[]', 0, '2021-07-12 13:31:13', '2021-07-12 13:31:13', '2022-07-12 06:31:13'),
('8b87bcc6dbecee86259edbfe9b3285e8443c67c7f0598136f0557c293e1d61e74d31302872219d61', 9, 1, 'MyApp', '[]', 0, '2020-04-10 13:11:13', '2020-04-10 13:11:13', '2021-04-10 06:11:13'),
('8bc0f27a4a42858dc6884088e0654f1d7810abad4bd04cdfed5e8b99199fde246083eb7c508b4695', 6, 1, 'MyApp', '[]', 0, '2020-02-13 14:29:57', '2020-02-13 14:29:57', '2021-02-13 07:29:57'),
('8bdbc1f380a27db13f406ee91bbb3dea7e3cb3e61bf20ff51f7ad5afb16dfc802b3d5858c9642791', 79, 1, 'MyApp', '[]', 0, '2021-07-08 17:41:29', '2021-07-08 17:41:29', '2022-07-08 10:41:29'),
('8d5f96484cf41ffcbcf85c1c26ad8c1c56cc23688133228e3581d6946dd8ae50f948a28eeda0f871', 9, 1, 'MyApp', '[]', 0, '2020-04-01 14:16:51', '2020-04-01 14:16:51', '2021-04-01 07:16:51'),
('8e11be2c0ffc4f1113177c9eda94dab9284189694a2ca412ca3be9d8aeb92865147834eecf87723b', 1, 1, 'MyApp', '[]', 0, '2020-02-19 01:40:30', '2020-02-19 01:40:30', '2021-02-18 18:40:30'),
('905b61a782102c879e98febebfdc708cb18632702c09aef35c313755eec089d0dad1fa3e7c1a440e', 4, 1, 'MyApp', '[]', 0, '2020-03-05 17:07:41', '2020-03-05 17:07:41', '2021-03-05 10:07:41'),
('908e788e36f8075e7cc3adbd2d861451d8d8071798b4f52ca7d206698b40913a22b015fc934d263e', 3, 1, 'MyApp', '[]', 0, '2020-02-10 21:28:09', '2020-02-10 21:28:09', '2021-02-10 14:28:09'),
('90a9148681017de1ca01228a9deda82c99d18e6b2f412e4dccd20d553a7979b2a36695041c241782', 3, 1, 'MyApp', '[]', 0, '2020-02-10 21:28:09', '2020-02-10 21:28:09', '2021-02-10 14:28:09'),
('90c80267fbc857707829d4419555ad4d306348166a6736a7ac54e0006f552630fc345f3afc06ce71', 19, 1, 'MyApp', '[]', 0, '2020-02-20 17:36:45', '2020-02-20 17:36:45', '2021-02-20 10:36:45'),
('9131a9540b284e13ab1b07071df93e8d985d29f7a28a04d0d7e80e4247fba485fceb32af18552587', 34, 1, 'MyApp', '[]', 0, '2020-03-31 17:12:05', '2020-03-31 17:12:05', '2021-03-31 10:12:05'),
('9167fdcb80c8f84822e629249c577dcd98767f95d70e0bbb017a1bfb95f8298182b28abb54a35724', 1, 1, 'MyApp', '[]', 0, '2020-02-17 20:13:59', '2020-02-17 20:13:59', '2021-02-17 13:13:59'),
('9245dfe763fc85040b70b69c78ac1f5da7fafc2a9be547d354d0944e0ea640bb955f5a6a71fd69a9', 9, 1, 'MyApp', '[]', 0, '2020-02-13 21:33:47', '2020-02-13 21:33:47', '2021-02-13 14:33:47'),
('9248621e4c66edf467a6e5e400d8355c5342dba38b7d78132a23b699dea8b4a177625ae32add5c37', 81, 1, 'MyApp', '[]', 0, '2021-07-09 11:47:07', '2021-07-09 11:47:07', '2022-07-09 04:47:07'),
('930524b1f481869f8e112dc8a73ad65a55b1c85a9d6206758abe8200f6a447e02f97e595a54e2682', 39, 1, 'MyApp', '[]', 0, '2020-03-30 16:41:21', '2020-03-30 16:41:21', '2021-03-30 09:41:21'),
('933fcde287946f114c3ffbab05c47ed95b1f81aab6e502fa5b6d601143e0b14d135860494cd51f24', 39, 1, 'MyApp', '[]', 0, '2020-03-31 16:10:54', '2020-03-31 16:10:54', '2021-03-31 09:10:54'),
('9361116d902d7d82de82dc1a59573e8acc90ca88009c7dfdc85178ba714f7e878a0affa451750a91', 6, 1, 'MyApp', '[]', 0, '2020-02-19 15:26:17', '2020-02-19 15:26:17', '2021-02-19 08:26:17'),
('946e5dc48958af05c4c02f4ad3603cfd3513b41d7b858f24b7d75654002460ee2cb46599eac0c21e', 44, 1, 'MyApp', '[]', 0, '2020-03-30 17:01:10', '2020-03-30 17:01:10', '2021-03-30 10:01:10'),
('952a568255f1baf7f769a66afc74c3e252fea0ddac885c10ef7afda22691685dba37781e75ae6f2b', 9, 1, 'MyApp', '[]', 0, '2020-02-24 17:12:37', '2020-02-24 17:12:37', '2021-02-24 10:12:37'),
('96daa0edc7a28201039455aa597f58715ad8b6dde023ad0a1988536db195007f0264653b4bceee92', 51, 1, 'MyApp', '[]', 0, '2020-04-06 14:09:38', '2020-04-06 14:09:38', '2021-04-06 07:09:38'),
('972914b036e76168cdb031d2843a51fce8b79098cc19b02fa006b6a66b57d13b8b8915a0a95d223c', 9, 1, 'MyApp', '[]', 0, '2020-02-14 14:51:11', '2020-02-14 14:51:11', '2021-02-14 07:51:11'),
('97c404e81708c9453b2ad5562f4230859ef26471e1b63ce07a2f55852cbb1a5246f84d8fe850944a', 37, 1, 'MyApp', '[]', 0, '2020-03-31 16:05:27', '2020-03-31 16:05:27', '2021-03-31 09:05:27'),
('98d51fec2fa39e76feef8698d3036de3fbbcf345c3f7a90660a26419d1d76e24cba6a7205579d39a', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:02:43', '2021-07-06 18:02:43', '2022-07-06 11:02:43'),
('99a9d5b5839bb85ec9c2c28bb95449842ce976443e46226121f6286541910fa698e878f7daff9c55', 15, 1, 'MyApp', '[]', 0, '2020-02-15 20:06:33', '2020-02-15 20:06:33', '2021-02-15 13:06:33'),
('99b74a32ddc3a447a4d2fdfaf83fca82446ad82c6ae5af03f95978c2dd32fcb8864aeb6a17ce162a', 34, 1, 'MyApp', '[]', 0, '2020-03-31 18:55:25', '2020-03-31 18:55:25', '2021-03-31 11:55:25'),
('99e46f365fa600abeb0d78f2b643c027a90b3f0e3e82223c1e74865c717ad48b818b5d42fa761226', 9, 1, 'MyApp', '[]', 0, '2020-03-17 20:22:59', '2020-03-17 20:22:59', '2021-03-17 13:22:59'),
('9bd9179a849605965237daf34da5b803ecca8bdba2e082b0948cde5829c5e41c102c11d9fec944e3', 74, 1, 'MyApp', '[]', 0, '2021-07-06 20:33:49', '2021-07-06 20:33:49', '2022-07-06 13:33:49'),
('9cca063ae7c03c02fc4a6aadb1eca9615d77ec37592d03177b2f8d7faa4f6eaeeba46c4449eb1b6e', 9, 1, 'MyApp', '[]', 0, '2020-03-19 21:21:01', '2020-03-19 21:21:01', '2021-03-19 14:21:01'),
('9e044d0b03dd5352368fb26a59705e87508fad0fb8dfafa16df39426505b708ae5205526b162956e', 76, 1, 'MyApp', '[]', 0, '2021-07-08 13:42:20', '2021-07-08 13:42:20', '2022-07-08 06:42:20'),
('9e3c40625c2f801d67013276a29202da1eca55a8d0e918da2f57e712a0832d3df0d202f12aace023', 9, 1, 'MyApp', '[]', 0, '2020-05-04 15:07:30', '2020-05-04 15:07:30', '2021-05-04 08:07:30'),
('9ed6a0a17640009069de85c7f1164eb14cdd001538b8c6ec05760e9080b6098c2b0e944028f20a8d', 4, 1, 'MyApp', '[]', 0, '2021-07-06 15:42:06', '2021-07-06 15:42:06', '2022-07-06 08:42:06'),
('9f6ea94098a9b6e00688fee617975c0707798934c074f8828d42342382c11ebfe11aa726ddd17efb', 1, 1, 'MyApp', '[]', 0, '2020-02-24 15:05:51', '2020-02-24 15:05:51', '2021-02-24 08:05:51'),
('9ff556bc87c7786d41ba7c090d2c2c95c66ebc6ac4bec58b72b9575f435caca3a70f20138e53b12d', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:12:43', '2020-04-06 21:12:43', '2021-04-06 14:12:43'),
('a0ed0ba05b530ec438d0825d553f039b5d54fc9abd022412755078a17e26e91008e72685a2b74280', 4, 1, 'MyApp', '[]', 0, '2020-02-11 15:45:48', '2020-02-11 15:45:48', '2021-02-11 08:45:48'),
('a11ba3284f9f8d19bf22d3624ac1ec43b981b26476b2c97efb7a9bd8471c82112d4b66134bc373ff', 9, 1, 'MyApp', '[]', 0, '2020-04-27 18:46:24', '2020-04-27 18:46:24', '2021-04-27 11:46:24'),
('a16a1b968a627ad52902881610f50428d8633670ee851b6a57a8cb20ac4397e5a5a299bb19962013', 24, 1, 'MyApp', '[]', 0, '2020-04-02 19:57:48', '2020-04-02 19:57:48', '2021-04-02 12:57:48'),
('a190bd28f12a9ef6de4ed2b5e79ad6c0e24aa40d26241c0cffa749aa1ae56ca53e5b668a3c216f4b', 9, 1, 'MyApp', '[]', 0, '2020-03-16 21:05:34', '2020-03-16 21:05:34', '2021-03-16 14:05:34'),
('a39d92233bdb11c5eb99f485e1769cc847718ed36a335d3baceefb3f004cb0288374c86ffab55b28', 38, 1, 'MyApp', '[]', 0, '2020-03-30 16:39:57', '2020-03-30 16:39:57', '2021-03-30 09:39:57'),
('a3a7f402393d638ee69a8719136630f040f2326c96054c060a6288f8b14aae7302ff1291f0e59252', 41, 1, 'MyApp', '[]', 0, '2020-03-31 16:21:53', '2020-03-31 16:21:53', '2021-03-31 09:21:53'),
('a4c04997d74643aff5048465f3d487ab12abeb454e73b954474c0979d4559d7ae09213798782f134', 27, 1, 'MyApp', '[]', 0, '2020-03-31 18:45:24', '2020-03-31 18:45:24', '2021-03-31 11:45:24'),
('a72b4149c6d3378f652c3e084cec809b6f2e35087cb8c652d2a6253d06fbb4126306f98ec2fd0dca', 51, 1, 'MyApp', '[]', 0, '2020-04-06 19:58:46', '2020-04-06 19:58:46', '2021-04-06 12:58:46'),
('a88b9041955a72d9e3a0c6b13da1be2b6b1dbaf5bfee678e6d266ccc942c36c2481bb992797e2e62', 9, 1, 'MyApp', '[]', 0, '2020-02-21 12:43:28', '2020-02-21 12:43:28', '2021-02-21 05:43:28'),
('a9fd67b8100adbed5aa0335c1ec7e99650884ca5a08c6ae91b5eb5fb7ec731063efc39f759482b77', 51, 1, 'MyApp', '[]', 0, '2021-07-06 19:15:11', '2021-07-06 19:15:11', '2022-07-06 12:15:11'),
('aadc68e198fd36d04dd25089529ebb8ef5fd14fbe644a173798ffdac4cd81fcd249436d4c97ac2b3', 6, 1, 'MyApp', '[]', 0, '2021-07-06 18:37:05', '2021-07-06 18:37:05', '2022-07-06 11:37:05'),
('ac049114535f9ba31b8c950fd195496cb26569439015e0cad2d062b21f069a86a60ec8eb7b59ca45', 81, 1, 'MyApp', '[]', 0, '2021-07-09 11:45:08', '2021-07-09 11:45:08', '2022-07-09 04:45:08'),
('ace592797d523631221591f3d2451784e301b49a5b808550d2c8f185b0795fe07bca6ea5da2afb95', 84, 1, 'MyApp', '[]', 0, '2021-07-11 16:19:07', '2021-07-11 16:19:07', '2022-07-11 09:19:07'),
('ad5e1ce28dd7da0df8ffe073096e20b699cf47b0fa024f7e5ccbd2e046f19f10f926ce15274488c1', 43, 1, 'MyApp', '[]', 0, '2020-03-31 16:22:08', '2020-03-31 16:22:08', '2021-03-31 09:22:08'),
('af272e88d11db2035079ec5bb8ab58e41bd920bb602ed84288e9fb2ab69dcac63468150820e439c4', 69, 1, 'MyApp', '[]', 0, '2021-07-06 13:39:15', '2021-07-06 13:39:15', '2022-07-06 06:39:15'),
('af48f300be21dffdfb4b71109c64216a373362c9c5e3633ad0e2b91fbd51d4b4cefd0131208b2154', 40, 1, 'MyApp', '[]', 0, '2020-03-30 16:43:53', '2020-03-30 16:43:53', '2021-03-30 09:43:53'),
('afd1c1121094672d2fefb4b559f22e6fb70c818c718b47b13873bc2976436f94877c7fe3f7933223', 5, 1, 'MyApp', '[]', 0, '2020-02-11 08:52:05', '2020-02-11 08:52:05', '2021-02-11 01:52:05'),
('b0caadba6c8e16c19b88578b50c72e78a08ce7c54045fc89da7c4f5fcafb37d15627c810864720b6', 51, 1, 'MyApp', '[]', 0, '2020-04-08 17:44:07', '2020-04-08 17:44:07', '2021-04-08 10:44:07'),
('b12232d291d632aa5e6c303d1f250fff8ae223297d2a0bd756896f76f6d751a9e79ebc40e770406c', 4, 1, 'MyApp', '[]', 0, '2020-02-14 14:21:23', '2020-02-14 14:21:23', '2021-02-14 07:21:23'),
('b148c5413e2f403e1167fb971b22a86044110b0b7b3b4cbe84e841f956bba96dcf28471c4849dd13', 9, 1, 'MyApp', '[]', 0, '2020-04-14 13:28:15', '2020-04-14 13:28:15', '2021-04-14 06:28:15'),
('b1a151654988d30953539dc818bdc4cd390bcd7b9ee493a204299d1a630b83e3005f619641f154cb', 9, 1, 'MyApp', '[]', 0, '2020-05-01 19:58:27', '2020-05-01 19:58:27', '2021-05-01 12:58:27'),
('b1a2f4fad465033788e883662a56ed7bb04b4bb4284e42693a505739237423c456e744aef223e504', 69, 1, 'MyApp', '[]', 0, '2021-07-06 13:33:42', '2021-07-06 13:33:42', '2022-07-06 06:33:42'),
('b26ca32ca276208b3fc70a701deb0ebbf6d09cb7f9f9b10826878d4452d2ebb7a32016cc3852e8d5', 51, 1, 'MyApp', '[]', 0, '2021-07-06 12:00:21', '2021-07-06 12:00:21', '2022-07-06 05:00:21'),
('b286311c0afcd988689eada93c1a5eba4bccd716981f52a592e159ce84379fa509caa0588bfb0e3a', 9, 1, 'MyApp', '[]', 0, '2020-03-20 16:31:18', '2020-03-20 16:31:18', '2021-03-20 09:31:18'),
('b2d5263c564ec14fc5a9394f9d194f556d72c6498715d5494e91df0ef9ab4a96e33436ebcad7dd97', 1, 1, 'MyApp', '[]', 0, '2020-03-16 14:14:45', '2020-03-16 14:14:45', '2021-03-16 07:14:45'),
('b30ac7e23158bec8ee92bcd9a5e1aee803e858adb128f98542fb7916f684ad4e28e2acac5c841b19', 1, 1, 'MyApp', '[]', 0, '2020-04-02 22:21:39', '2020-04-02 22:21:39', '2021-04-02 15:21:39'),
('b3514898f415cbe90e44b8b373f828604e3c0293e74f4e19be5653751a86e9480a487dc3ca145203', 22, 1, 'MyApp', '[]', 0, '2020-03-19 18:37:34', '2020-03-19 18:37:34', '2021-03-19 11:37:34'),
('b3c76c9ce95b33962ce9295d7ab220fd95bef98ba44937f7c02ce055df6dfa886036db2761584ee7', 4, 1, 'MyApp', '[]', 0, '2020-02-13 20:24:19', '2020-02-13 20:24:19', '2021-02-13 13:24:19'),
('b4c1277981170a754fd9e0c70165fe0e9cadf6645fa3feeca21cdb3c963ef0c3aa1240706f6cea0c', 1, 1, 'MyApp', '[]', 0, '2020-02-14 11:52:08', '2020-02-14 11:52:08', '2021-02-14 04:52:08'),
('b53f5bc20d29dc6421673c0e6479ae21322f324e09e03322fbf4e003e9da2fd6a9c48bcbfff13ce9', 24, 1, 'MyApp', '[]', 0, '2020-03-31 16:35:15', '2020-03-31 16:35:15', '2021-03-31 09:35:15'),
('b6a70ea112bc518afd04c0cbce0779071f61e2bae47ebf181e3c23bdb358895166ff87e345a9d8f8', 77, 1, 'MyApp', '[]', 0, '2021-07-08 14:07:40', '2021-07-08 14:07:40', '2022-07-08 07:07:40'),
('b7f7756551de34fbac64d7e8cd2752dcc567ed6ad90f8def454a8fd473248e28b8bb0604548aeba7', 69, 1, 'MyApp', '[]', 0, '2021-07-06 12:55:41', '2021-07-06 12:55:41', '2022-07-06 05:55:41'),
('b81d50ea40f4edcd87a50adc19ab429d84ddbf87a6183c3f9462ab6f100ba5e80a45b16a0f89e863', 81, 1, 'MyApp', '[]', 0, '2021-07-09 11:46:07', '2021-07-09 11:46:07', '2022-07-09 04:46:07'),
('b8354f71348b32c2cda73de0ca9f90067449582e287bdae5f8944614f125de64d48aa80e1c8889f5', 69, 1, 'MyApp', '[]', 0, '2021-07-06 12:57:59', '2021-07-06 12:57:59', '2022-07-06 05:57:59'),
('b847b583a16c0d97a49c902ec3475bf727330450d943ebe46c74b56df123f92879b1f96470d7fa0e', 16, 1, 'MyApp', '[]', 0, '2020-02-24 21:06:20', '2020-02-24 21:06:20', '2021-02-24 14:06:20'),
('b8c50d4650bba9b3b938b2bd23e6d1868c7c6389756246d3b4fce3e7c8b60d9f8220512a751d218e', 9, 1, 'MyApp', '[]', 0, '2020-04-29 17:05:32', '2020-04-29 17:05:32', '2021-04-29 10:05:32'),
('b8ed49856ea093c478c08c5b6f32eb0ce4e2c3d52d289175ac19bd8bfae190d614b4ce419438a065', 9, 1, 'MyApp', '[]', 0, '2020-03-06 13:24:33', '2020-03-06 13:24:33', '2021-03-06 06:24:33'),
('b8ef0200e983370ece78308fca80727e2322bd00cd377bc165fe3e089d2b8f75b63acbb8b431a2ee', 9, 1, 'MyApp', '[]', 0, '2020-03-06 21:49:23', '2020-03-06 21:49:23', '2021-03-06 14:49:23'),
('b9a6d80176fd3e26f9a25eb1a1fc324f6d59549bc133bd213e8e22e7558427795acea57dad59fa22', 17, 1, 'MyApp', '[]', 0, '2020-02-19 15:23:53', '2020-02-19 15:23:53', '2021-02-19 08:23:53'),
('ba136f3dc2d0970c5086b3a8adcfce4b5d8f471cb4d6ff34c4ca602e585238492eba99b54deea709', 1, 1, 'MyApp', '[]', 0, '2020-02-15 19:18:37', '2020-02-15 19:18:37', '2021-02-15 12:18:37'),
('baebb3280542ce25ce88a93399a8ebae56c6f912b3caee27b2be41ebbe7833d13a3e622a5946a112', 3, 1, 'MyApp', '[]', 0, '2020-02-10 21:28:01', '2020-02-10 21:28:01', '2021-02-10 14:28:01');
INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('bb6882604668ac9ed7bbf6b2f45de760a4a938dfd7beb03fa831837a4f495973e3f501e1e05283c5', 9, 1, 'MyApp', '[]', 0, '2020-03-20 20:29:32', '2020-03-20 20:29:32', '2021-03-20 13:29:32'),
('bb86ee428d284ac39422e2810755a5942bf4b07e118a852a8d65771bbeb553980833c3f140cfeab5', 69, 1, 'MyApp', '[]', 0, '2021-07-06 12:56:26', '2021-07-06 12:56:26', '2022-07-06 05:56:26'),
('bc52887e6a8969ac664d5444c09f551f34c54445f4f72991008b102d3f626d79f31db4f77a58621c', 77, 1, 'MyApp', '[]', 0, '2021-07-08 14:26:31', '2021-07-08 14:26:31', '2022-07-08 07:26:31'),
('bc7be3e107f07f2063f7bf25673613a735e01dbf7bb5bc9b7c20a54925838a6dd01e12fbe23797ec', 69, 1, 'MyApp', '[]', 0, '2021-07-06 12:56:26', '2021-07-06 12:56:26', '2022-07-06 05:56:26'),
('bce2c780c4fcc2dfc239b0917dbfd685cd3bfc98a085107ed0083eb78ddf3fc659a509691d13ae07', 61, 1, 'MyApp', '[]', 0, '2021-06-23 13:44:42', '2021-06-23 13:44:42', '2022-06-23 06:44:42'),
('bd36ef7b75390fa8864a3a8722da1b1ebd248144f1ddbc0e8782163046dd4942bdfa5164ab8b0b7b', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:02:43', '2021-07-06 18:02:43', '2022-07-06 11:02:43'),
('bd82525deb99bebab55da30774132746a650b6e54450212243a89b4189379abdcdfbb83a410ca74d', 51, 1, 'MyApp', '[]', 0, '2020-04-08 18:32:50', '2020-04-08 18:32:50', '2021-04-08 11:32:50'),
('be358502ffd8670f4da0c4cb763d0644885ded4ec3b18e1b576894079beaadfd7832a2099e711cd0', 9, 1, 'MyApp', '[]', 0, '2020-03-20 17:38:00', '2020-03-20 17:38:00', '2021-03-20 10:38:00'),
('bf14e2aaa0e70477229a4b44f9fe171b2c00e3daef4f90e19e89e51bd3a9c7a5cbc2110a32d59511', 55, 1, 'MyApp', '[]', 0, '2020-04-16 16:44:28', '2020-04-16 16:44:28', '2021-04-16 09:44:28'),
('bf537a79a33ddafbcb2865f25647b6f78eb156465ed8eaf12e7586087b6609ab72d4db7452e6b8b8', 10, 1, 'MyApp', '[]', 0, '2020-02-13 17:23:17', '2020-02-13 17:23:17', '2021-02-13 10:23:17'),
('bf696f744dd18cb7d39331b0312fea6bf556a76f8bbe4ed403f5b624297ced959de189deed4e5451', 6, 1, 'MyApp', '[]', 0, '2020-04-06 18:32:01', '2020-04-06 18:32:01', '2021-04-06 11:32:01'),
('bf8f1e470c28b1e2c7e73b51ebfb8f9faf329f21a19436804c4193c2fbf6d18be33d373b28f0af3e', 60, 1, 'MyApp', '[]', 0, '2021-06-22 22:33:33', '2021-06-22 22:33:33', '2022-06-22 15:33:33'),
('bf92ceb133e95f034a979613742ce1bc93ce0b3e6fc33f4c44bc31f532442b10f0b8d4c31734688b', 76, 1, 'MyApp', '[]', 0, '2021-07-06 21:09:37', '2021-07-06 21:09:37', '2022-07-06 14:09:37'),
('c05724bd561868515cce1d8a9e37382aee5ad96eb1a9ad67c282194b18904823c7dfea033224da9c', 9, 1, 'MyApp', '[]', 0, '2020-02-24 16:53:20', '2020-02-24 16:53:20', '2021-02-24 09:53:20'),
('c1d5f48200ad195437c1e84a5acf68a1825195b59853c24b5b67a7735fd905a3e8e9dec1532a0989', 6, 1, 'MyApp', '[]', 0, '2020-02-11 18:59:01', '2020-02-11 18:59:01', '2021-02-11 11:59:01'),
('c3387f8332070546606cae665032305f84b3a3663f88946de9f17bbadce7aac2740eb11c5df3fd6d', 78, 1, 'MyApp', '[]', 0, '2021-07-09 02:11:38', '2021-07-09 02:11:38', '2022-07-08 19:11:38'),
('c35f70beb1b3f6995fdc46940ce7f6a68f70e4ed678d770ebe5a2ed8e4aac695c430bdb86f0809de', 9, 1, 'MyApp', '[]', 0, '2020-03-18 16:44:52', '2020-03-18 16:44:52', '2021-03-18 09:44:52'),
('c40ba0543ed0043a5301f968d4a16ff2755975f716fe0e5d69ff76354f268bcd9def457f371fd260', 29, 1, 'MyApp', '[]', 0, '2020-03-31 16:55:06', '2020-03-31 16:55:06', '2021-03-31 09:55:06'),
('c4416561d7368e0170bbf8d7c584c1d6f332f248b56848f6f7ddf7bbf96eccac8e595b72ed92790f', 48, 1, 'MyApp', '[]', 0, '2020-03-31 19:15:41', '2020-03-31 19:15:41', '2021-03-31 12:15:41'),
('c52f9ee5b68f6e2ea4c120c17b0f7d29ac7bf4ad676c4e307cb47e3d0ab1b6a91f63631fb272e523', 25, 1, 'MyApp', '[]', 0, '2020-03-30 15:45:44', '2020-03-30 15:45:44', '2021-03-30 08:45:44'),
('c5b7ef9570fccdb5a7e8a78d34f29a43176f5bc95082202e79bd0b702c871ea4402018c1e164c5d8', 12, 1, 'MyApp', '[]', 0, '2020-02-14 12:49:36', '2020-02-14 12:49:36', '2021-02-14 05:49:36'),
('c6ed44b13f49fec04bbf427710ba9056b3b5a8852e3783d6a8bebb1e70131a8635613880473c776d', 16, 1, 'MyApp', '[]', 0, '2020-02-18 16:29:11', '2020-02-18 16:29:11', '2021-02-18 09:29:11'),
('c8437955a959dd4d0ce14273d688f5ff9731765c689cfdee6d82b50e47a49c36f86b0073ddd0dff0', 71, 1, 'MyApp', '[]', 0, '2021-07-06 17:58:15', '2021-07-06 17:58:15', '2022-07-06 10:58:15'),
('c87eaa66a139481020ca3212d00b247ab63ce74a436816e3966d51f564e6ebcdcdd099dabe628fb1', 9, 1, 'MyApp', '[]', 0, '2020-03-19 11:45:20', '2020-03-19 11:45:20', '2021-03-19 04:45:20'),
('c8f3b5a6859f7c39590a78eedd73e45b85d6903f3f0c90e4d241b13baa01519e43516442d6f1e5a5', 51, 1, 'MyApp', '[]', 0, '2020-04-06 19:40:36', '2020-04-06 19:40:36', '2021-04-06 12:40:36'),
('c92b289a2b5c4991ba2ba09d95430eedb9d1bfc47a90950c8f72ccd1768ccde5f02e34a0f1db0cda', 1, 1, 'MyApp', '[]', 0, '2020-04-03 11:44:18', '2020-04-03 11:44:18', '2021-04-03 04:44:18'),
('c9879f06bf42b97f5ede7308b65d43f9876f5c713577ac9bb72d2127ed8fc8d605e7932ee9e881c0', 51, 1, 'MyApp', '[]', 0, '2020-04-08 13:56:38', '2020-04-08 13:56:38', '2021-04-08 06:56:38'),
('c99390fc0a9d69157a8c3d600d53d75691c77144b8da613586b7519018631d935d31f4fea667d20c', 42, 1, 'MyApp', '[]', 0, '2020-03-30 16:57:23', '2020-03-30 16:57:23', '2021-03-30 09:57:23'),
('c9f00025e9d7e0d117da875c7a8a8fb42fd9904e66079f149344e6a26ef25bbcd7449f77062776d5', 6, 1, 'MyApp', '[]', 0, '2020-02-11 18:09:08', '2020-02-11 18:09:08', '2021-02-11 11:09:08'),
('ca2b05054b84bbfa77a5fd5a14d4a6b72fe7bffd27f8784bc30252306815e76dea0642184c74d190', 9, 1, 'MyApp', '[]', 0, '2020-03-23 11:31:40', '2020-03-23 11:31:40', '2021-03-23 04:31:40'),
('ca7011ed5464b9b58db8a0ff491f6550f18810329f104601c233df34d17e92d648c11f97c3ac5bf5', 9, 1, 'MyApp', '[]', 0, '2020-03-18 12:41:21', '2020-03-18 12:41:21', '2021-03-18 05:41:21'),
('caaa8d53a6489bfeb44093e48de188ce5ad9bda57b3bb6b77425682613b4726bc0127eb773c68194', 51, 1, 'MyApp', '[]', 0, '2021-07-06 12:05:11', '2021-07-06 12:05:11', '2022-07-06 05:05:11'),
('caeedd93e15fdb9f29bdf14a976295052ae15a3620d17999edacee68c27dbadbf32c77e5e7760946', 51, 1, 'MyApp', '[]', 0, '2020-04-07 22:01:31', '2020-04-07 22:01:31', '2021-04-07 15:01:31'),
('cb86625a5aa8e722fbf1e0d19d2da181e12c196d9039c112fec118ed736d5926ad0bca913a926b74', 82, 1, 'MyApp', '[]', 0, '2021-07-09 18:18:42', '2021-07-09 18:18:42', '2022-07-09 11:18:42'),
('cd093004dc66535083b520c62010225161ebd3ffd3aaa35d2f5ffb30c2484b63658d5f2eac3e93f3', 14, 1, 'MyApp', '[]', 0, '2020-02-29 17:25:36', '2020-02-29 17:25:36', '2021-03-01 10:25:36'),
('cd0b990359ed7b3a1444a0166b073bf6b61bdea80a228d4015fbb9a5d6f76eed61529bd765dfb13c', 44, 1, 'MyApp', '[]', 0, '2020-03-31 16:26:24', '2020-03-31 16:26:24', '2021-03-31 09:26:24'),
('cd345fb1b6c412e5db4170e984e2791caa79bcf80670e3a99bdb47ea935c807647d380d64fe7500c', 9, 1, 'MyApp', '[]', 0, '2020-02-24 19:56:58', '2020-02-24 19:56:58', '2021-02-24 12:56:58'),
('cd40093d5ff48ec069745ca1fee0eaacdc00c4f0ff1f44efa231ca82226589e7fe2819debe0d5cde', 48, 1, 'MyApp', '[]', 0, '2020-03-31 14:32:10', '2020-03-31 14:32:10', '2021-03-31 07:32:10'),
('cdb0e48e0724145c5bf1a2b4382ecd875f5b3f3e0c54b772c71de1660c05c46c8196fce97d1521a1', 9, 1, 'MyApp', '[]', 0, '2020-03-19 21:18:38', '2020-03-19 21:18:38', '2021-03-19 14:18:38'),
('cdd43d0eed42dd9a08949fead0e8401963a87914e5d3be7d61eb2181296702ac7263025a1f4c91aa', 9, 1, 'MyApp', '[]', 0, '2020-02-12 21:15:37', '2020-02-12 21:15:37', '2021-02-12 14:15:37'),
('cf4766027e4914c5e83a59d633ff6049f4b0eb0b613be94e045a9f7d6d29f8cdd46778b9334323da', 6, 1, 'MyApp', '[]', 0, '2020-04-06 22:50:26', '2020-04-06 22:50:26', '2021-04-06 15:50:26'),
('d0e10ac6018171659c6233125677ebb34d2c0376cc879e4cdfcb923708bb1d82f36ac4965f9eed8c', 7, 1, 'MyApp', '[]', 0, '2020-02-11 16:33:47', '2020-02-11 16:33:47', '2021-02-11 09:33:47'),
('d0e1a7091043a601cdd11ba30ef7fbe68de991c37ef6a96bfe660b5de454a30e3ee6cfdef647216e', 1, 1, 'MyApp', '[]', 0, '2020-03-06 17:15:14', '2020-03-06 17:15:14', '2021-03-06 10:15:14'),
('d10c9e1fef50cc687cb2a6ccee0a26bb79801c0fa8ad408b6b6bfc4b567fc2af133673eba8ec4e91', 32, 1, 'MyApp', '[]', 0, '2020-03-31 17:04:38', '2020-03-31 17:04:38', '2021-03-31 10:04:38'),
('d11c320d3f15824701b783bb94a65f3c371a877a0a36d8e272f50316bf1391c22d0febba08dd78ac', 50, 1, 'MyApp', '[]', 0, '2020-03-31 14:50:47', '2020-03-31 14:50:47', '2021-03-31 07:50:47'),
('d19df4b37cb67d56d258b86ad18da6407ab0117192ac7838c46849a217afc1f2a813bc6669f2287f', 9, 1, 'MyApp', '[]', 0, '2020-02-24 21:13:44', '2020-02-24 21:13:44', '2021-02-24 14:13:44'),
('d1af9430e8e9a6330ab7e17b4062e2bcbe9dae6aa7665806f386ce1dbd690f363aa5f6729fc2c89e', 37, 1, 'MyApp', '[]', 0, '2020-03-31 19:08:00', '2020-03-31 19:08:00', '2021-03-31 12:08:00'),
('d23c5f1dfbc6bd3b237c2dca5d78d5b2e9c746c8b5b53ea9e8016798b8f6828298349c1fabe709f2', 51, 1, 'MyApp', '[]', 0, '2020-04-07 11:45:13', '2020-04-07 11:45:13', '2021-04-07 04:45:13'),
('d29247a0b446c71178ee9f7e73bc4f6e84f70a8e034b5dae0b749b63300fdb9102feb70d527d2f21', 51, 1, 'MyApp', '[]', 0, '2020-04-06 14:05:51', '2020-04-06 14:05:51', '2021-04-06 07:05:51'),
('d4b1ef63e6a81614ac58cfe9f7ca35ba6c49c57994fd4305c983f8e8a3e949951d8c565b5a80c00c', 51, 1, 'MyApp', '[]', 0, '2020-04-06 14:05:50', '2020-04-06 14:05:50', '2021-04-06 07:05:50'),
('d4dcd9b911c98cb7d794c059bac5b92f53b6bd4460dbc2768f3aa65bda6ed27c142f15350d416f62', 37, 1, 'MyApp', '[]', 0, '2020-03-31 16:04:18', '2020-03-31 16:04:18', '2021-03-31 09:04:18'),
('d5e617d1c72b4dc5f7290dd251499067f54572fb9d44ec20be2bfd4a9afd185e690c59d30e1246ac', 33, 1, 'MyApp', '[]', 0, '2020-03-31 18:54:06', '2020-03-31 18:54:06', '2021-03-31 11:54:06'),
('d5f43d9c45a23809ace017785c1390ca53aa437477d8fc434d3ecd1fd1dfa87201f23aab85a3cbc7', 1, 1, 'MyApp', '[]', 0, '2020-02-12 22:51:00', '2020-02-12 22:51:00', '2021-02-12 15:51:00'),
('d6f2a7fa0303ae026d1ee2707d6d11b8158bcc8b9b784b1cf3343bafc12003fb072d9283898a30a2', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:01:40', '2021-07-06 18:01:40', '2022-07-06 11:01:40'),
('d78990c809c1b9d2480d0b8c3c5f4bb6f8250e36a43dbc388066d9ef8705b832384352bd14ed3070', 9, 1, 'MyApp', '[]', 0, '2020-02-14 14:18:16', '2020-02-14 14:18:16', '2021-02-14 07:18:16'),
('d9377afe6123d35747e20e7fe8f18e2e4603bd358aae4dbea52dd88a117c8cbbfbc25cc676bf5a7c', 51, 1, 'MyApp', '[]', 0, '2020-04-08 17:12:50', '2020-04-08 17:12:50', '2021-04-08 10:12:50'),
('da2510edd86c19a88158a099e4f020b64beb8f9aee36052c51d74b815cca9dee936403479af2bee5', 43, 1, 'MyApp', '[]', 0, '2020-03-30 16:59:02', '2020-03-30 16:59:02', '2021-03-30 09:59:02'),
('da69c5514555b1a0455f7b2b9006a96aacc3eb4c53d2c6db70444fa5e0be95a2451fea590151d93b', 30, 1, 'MyApp', '[]', 0, '2020-03-31 18:51:37', '2020-03-31 18:51:37', '2021-03-31 11:51:37'),
('dab0818f1a9152dbb7228e66278eebde59c58d972186bf89db8c127ff7bccb4d774d3d3bd097310f', 9, 1, 'MyApp', '[]', 0, '2020-03-24 18:42:37', '2020-03-24 18:42:37', '2021-03-24 11:42:37'),
('dab904342d9e9e663b2786755d7b238af9018ddb656284b0af20c21cdb183845d06d36860e615577', 6, 1, 'MyApp', '[]', 0, '2020-02-11 18:55:56', '2020-02-11 18:55:56', '2021-02-11 11:55:56'),
('db82976dea9b484bd88c23ff8a5322f9c456792bcfdc1afc9574ffad1db95dce25eafe27089a2bca', 51, 1, 'MyApp', '[]', 0, '2020-04-06 21:25:36', '2020-04-06 21:25:36', '2021-04-06 14:25:36'),
('dcf2587de402f01c0e9fa2c5ef6fc20fb5093ddf28143cac00377529ac5cfed6205d3ffd16ead863', 70, 1, 'MyApp', '[]', 0, '2021-07-06 14:27:02', '2021-07-06 14:27:02', '2022-07-06 07:27:02'),
('dcf4cb84171b9ea29a95ece2113cbf8160f0ebbec907e97099aa174127cc3fc73906ed491ac6d2f6', 1, 1, 'MyApp', '[]', 0, '2020-02-11 17:59:51', '2020-02-11 17:59:51', '2021-02-11 10:59:51'),
('dd391f56ee4d2f54c0cbef844fa2d06c824384a363d9cf34ea5228607f62329ad059ffa9bbf34375', 82, 1, 'MyApp', '[]', 0, '2021-07-09 18:18:23', '2021-07-09 18:18:23', '2022-07-09 11:18:23'),
('dd53b87f6f0b7ac1c6ae67f08b99f6e27dadfcaf0072da1e79b1bd5335e95d7a9f99a00684a0429d', 63, 1, 'MyApp', '[]', 0, '2021-06-23 14:46:25', '2021-06-23 14:46:25', '2022-06-23 07:46:25'),
('ddde61bcc273654c7f056c9df5a7edcd0cee04ae05b8e352a0538f5eef1ddd033d3d02ca4ec934f9', 9, 1, 'MyApp', '[]', 0, '2020-02-13 20:24:45', '2020-02-13 20:24:45', '2021-02-13 13:24:45'),
('defb1d31f1d44732ab67fed98e102b66bbd34f22c706716c8c15553dd7f25eca786b62d03cbfc234', 2, 1, 'MyApp', '[]', 0, '2020-02-10 21:26:00', '2020-02-10 21:26:00', '2021-02-10 14:26:00'),
('df43353fad6a0543fa2d387c61e76fa2b5811a65d9031356d388f20ad48a7b978bfdbc50bb4affb9', 9, 1, 'MyApp', '[]', 0, '2020-03-19 11:54:47', '2020-03-19 11:54:47', '2021-03-19 04:54:47'),
('e053d19d033184a98f441076b78503a714d32888886b2c6fb22a9ea928c85615e9097f06eed38964', 71, 1, 'MyApp', '[]', 0, '2021-07-06 18:02:43', '2021-07-06 18:02:43', '2022-07-06 11:02:43'),
('e0e21a48a449a29f2327708de6925c450398b28899c87d6999683996e37a012c33147b41565b3f7c', 51, 1, 'MyApp', '[]', 0, '2020-04-08 15:03:17', '2020-04-08 15:03:17', '2021-04-08 08:03:17'),
('e1216023866677e5283c4f3959d88e5205a5e52a702b3ae2c7e7895c01a69cce38287e568191ab4c', 9, 1, 'MyApp', '[]', 0, '2020-02-20 17:31:22', '2020-02-20 17:31:22', '2021-02-20 10:31:22'),
('e137fc59d97a71c5fdcdeebdbfd7f8f26f29b68648592b6f7e122d6ecbaf1554b615ff7974a9aeb8', 18, 1, 'MyApp', '[]', 0, '2020-02-19 17:04:07', '2020-02-19 17:04:07', '2021-02-19 10:04:07'),
('e205be593d9e632a9f8f743b492c7841f27e124bd7c2ea9df1401e577ee64c0f1fa5da95eefbecee', 28, 1, 'MyApp', '[]', 0, '2020-03-31 16:45:16', '2020-03-31 16:45:16', '2021-03-31 09:45:16'),
('e37368f862eb1eb0a9475aa0088b11969350220faefa26601c07d4ab780bfeda785a60497f1d6278', 9, 1, 'MyApp', '[]', 0, '2020-03-18 19:49:47', '2020-03-18 19:49:47', '2021-03-18 12:49:47'),
('e4eaeb9794165f6422c52c1db61111164908ea284093287f7f7be5cda75041fc97da98a7af513ad3', 51, 1, 'MyApp', '[]', 0, '2020-04-08 17:12:57', '2020-04-08 17:12:57', '2021-04-08 10:12:57'),
('e51167ae39921edc86e5b4157ef83c4b9b4c4cd816f05ee1964ec32831f4cf3ace5ca120baba8fa8', 9, 1, 'MyApp', '[]', 0, '2020-02-17 19:58:07', '2020-02-17 19:58:07', '2021-02-17 12:58:07'),
('e77be4fa9e7a0ab5067d7a5d866dca060131292ee1b3a8d96d0fdd5b8928a4adfc090e5d3d65ffaa', 4, 1, 'MyApp', '[]', 0, '2020-02-10 21:29:21', '2020-02-10 21:29:21', '2021-02-10 14:29:21'),
('e783c36678d99bc61d35875b8f1b3fca7fcc630af493af8be768c40fc153190b1b465593cff4fb58', 9, 1, 'MyApp', '[]', 0, '2020-03-19 13:23:25', '2020-03-19 13:23:25', '2021-03-19 06:23:25'),
('e815201e186ecea45fcde99494386a7b67aeef9cf3baac792fc89697003567e7510de52c46580e52', 1, 1, 'MyApp', '[]', 0, '2020-02-11 18:14:33', '2020-02-11 18:14:33', '2021-02-11 11:14:33'),
('e93700bccfa519ddbc5101dae36624eb4d906c2b0a6bdb782392103c18f6b886c96bfd624d4ed5a7', 24, 1, 'MyApp', '[]', 0, '2020-03-30 14:51:18', '2020-03-30 14:51:18', '2021-03-30 07:51:18'),
('e93b600c8af2453781e6af9c9ab22acfb8033d0341ed6cab35ac4953ece84007819822d063adff56', 4, 1, 'MyApp', '[]', 0, '2020-02-17 19:54:10', '2020-02-17 19:54:10', '2021-02-17 12:54:10'),
('e945fb9f97c6048a51058d40e7bb61351a6e5823fa85bed108dfc8126f7e25303291147cdfaf0a6a', 72, 1, 'MyApp', '[]', 0, '2021-07-06 18:19:07', '2021-07-06 18:19:07', '2022-07-06 11:19:07'),
('eaaf4a8e6b1a6e9a6e805854c7105b58c32fe229c3d8c7b50ca6360a9a4c9ab7341c4e7d7e4f76b6', 76, 1, 'MyApp', '[]', 0, '2021-07-06 21:09:37', '2021-07-06 21:09:37', '2022-07-06 14:09:37'),
('eb4ec9a9b28cdf3d9f64a30881fbd117fdeabd4bb1a3b2a379ea3287f53aabdc252e310456aca456', 10, 1, 'MyApp', '[]', 0, '2020-04-04 20:41:50', '2020-04-04 20:41:50', '2021-04-04 13:41:50'),
('ec5dce2c1b2a96f86a5f5d5492e42303a228d7fd3cdd894b4855dfa27c2f406cc3119b438c8bc500', 29, 1, 'MyApp', '[]', 0, '2020-03-30 15:57:43', '2020-03-30 15:57:43', '2021-03-30 08:57:43'),
('edeef9280a7113a7bcab4d7f9dc9e36a6a7588c96af490e2cc390c2f46258e57d714ba49d8256b57', 1, 1, 'MyApp', '[]', 0, '2020-02-10 21:12:00', '2020-02-10 21:12:00', '2021-02-10 14:12:00'),
('ee05f0dfefc31a2161c7a2cb6b2bd0b923db2887ad95490116a30db7360141119a2890f4b4c5e509', 51, 1, 'MyApp', '[]', 0, '2020-04-06 22:00:01', '2020-04-06 22:00:01', '2021-04-06 15:00:01'),
('ee1c66011063f5b030da0c8e2384c06c1bcddd3bff156e95765efa627c7dfa4ff6c68252b738126b', 9, 1, 'MyApp', '[]', 0, '2020-04-14 12:27:00', '2020-04-14 12:27:00', '2021-04-14 05:27:00'),
('ee65df5483d7f8f74fe9fcff2cf8ec278dc1a56ce03b6575ca8b3f82f84593a9a598ec3735a049b8', 9, 1, 'MyApp', '[]', 0, '2020-04-13 12:10:27', '2020-04-13 12:10:27', '2021-04-13 05:10:27'),
('ee715864fdde18d29dd4660c7d34ece11a19c6e144237ad2fc67ec9e4101bc2ea8f98d76cc52695d', 9, 1, 'MyApp', '[]', 0, '2020-04-04 20:44:17', '2020-04-04 20:44:17', '2021-04-04 13:44:17'),
('ee80fb3b9c126d34ff5cf1c25104e1424acaa634d3dec17a4d7bcdf707bd45fdb880f13d6526fa7a', 1, 1, 'MyApp', '[]', 0, '2020-04-06 11:58:56', '2020-04-06 11:58:56', '2021-04-06 04:58:56'),
('ef01eef630028dab6a757ff3bc2a20ec194f2842b46225bd862976bc07a580a0c51ae77b011844ed', 1, 1, 'MyApp', '[]', 0, '2020-02-18 20:36:11', '2020-02-18 20:36:11', '2021-02-18 13:36:11'),
('ef4f27696b1ac2e2b10b6d742b9de4f08ef34e168c06869b7b2ecd40f9d681beb30e16924138c5f0', 36, 1, 'MyApp', '[]', 0, '2020-03-30 16:35:11', '2020-03-30 16:35:11', '2021-03-30 09:35:11'),
('f0eb86e948f9e9f24cccc5c08fb688e010f78218e3cc4d73e332856ec8beeb458b1615bd69ae7525', 3, 1, 'MyApp', '[]', 0, '2020-02-10 21:28:01', '2020-02-10 21:28:01', '2021-02-10 14:28:01'),
('f2813df2c12a377b1233e495923cac9b1957cce766dddf498ddbec13b10104f02d72c06cb04b7972', 9, 1, 'MyApp', '[]', 0, '2020-03-20 16:00:47', '2020-03-20 16:00:47', '2021-03-20 09:00:47'),
('f31ae0ac4a33efe10f19b20abc0135ff8822cfceb22d2f1bae3ad914e634261da3206766a47ec8ab', 28, 1, 'MyApp', '[]', 0, '2020-03-30 15:52:06', '2020-03-30 15:52:06', '2021-03-30 08:52:06'),
('f4dda0e015072cd8cc3b8ee8c6862dbd668083687b675b1c7b1e96dc002495614f31b1beb3f9d72f', 9, 1, 'MyApp', '[]', 0, '2020-02-24 19:36:40', '2020-02-24 19:36:40', '2021-02-24 12:36:40'),
('f4fde5ca80100939e16c5faa812f5a69ab0d409c7d5e9f444be2010f10b1e1ae5d2e6be2ac32a103', 13, 1, 'MyApp', '[]', 0, '2020-02-14 14:48:38', '2020-02-14 14:48:38', '2021-02-14 07:48:38'),
('f5b1a79a6caf2be3dbb6afc87c374bc7ec444cd103031625a82f3045049ab5f010ffdc560a132315', 34, 1, 'MyApp', '[]', 0, '2020-03-30 16:30:43', '2020-03-30 16:30:43', '2021-03-30 09:30:43'),
('f607192f4f5f71094b5930acc9ae4edb30404b9d9d65788401f77e52591d225b327b173b970401c7', 6, 1, 'MyApp', '[]', 0, '2020-04-06 21:35:02', '2020-04-06 21:35:02', '2021-04-06 14:35:02'),
('f609135ea2bf9c9699190af945c4e6e860cc64ff2bee702fd2ed6ec1e984e5df5aeaf60a1e1207f1', 54, 1, 'MyApp', '[]', 0, '2020-04-16 16:37:29', '2020-04-16 16:37:29', '2021-04-16 09:37:29'),
('f7db7f886448d20536f61f967da7a40ac20349cfd08a5bd9c9be5378813487cae28637e629482e0f', 6, 1, 'MyApp', '[]', 0, '2020-02-12 14:39:34', '2020-02-12 14:39:34', '2021-02-12 07:39:34'),
('f93af4466fff22b469386b1b71cc0a17879dbfc1e9b5a032a97a1069b39163a3ac6dc53daeac2e8c', 35, 1, 'MyApp', '[]', 0, '2020-03-30 16:32:54', '2020-03-30 16:32:54', '2021-03-30 09:32:54'),
('fa4cee5df86aad1ca9d9236dd37002716c25e275dd45cd94550df1730ad4549d82b914f2e9afd80b', 9, 1, 'MyApp', '[]', 0, '2020-02-18 16:55:23', '2020-02-18 16:55:23', '2021-02-18 09:55:23'),
('fad5fd67c6df6f8361048c3ad4d1de6de837dbf036a6cfc71030d925e4cb47ba0fc26cb44d052bb7', 82, 1, 'MyApp', '[]', 0, '2021-07-09 18:21:42', '2021-07-09 18:21:42', '2022-07-09 11:21:42'),
('fc91fabecdc64ca5dbf256ec9fe9eb4e443b718db9471cdeb03c66f6bfdbf052634ba47815b65c02', 69, 1, 'MyApp', '[]', 0, '2021-07-06 13:27:47', '2021-07-06 13:27:47', '2022-07-06 06:27:47'),
('fdd3df04f248f0e850ab47525c7743a247b4b342c897445192e22959868e586ab76ac34552869c73', 52, 1, 'MyApp', '[]', 0, '2020-04-10 12:42:29', '2020-04-10 12:42:29', '2021-04-10 05:42:29'),
('fdffc14484fef2d3ac861b1c9ceff968fa35096f6059e8bdb296bdb8e3518a6b99137c9a63df63bc', 26, 1, 'MyApp', '[]', 0, '2020-03-30 15:46:48', '2020-03-30 15:46:48', '2021-03-30 08:46:48'),
('ff9be59b3c2b138fdf0023d4cc65fc97c487fe02f3c54fa19cac4f497317a54e0a07ce0e01ab81be', 30, 1, 'MyApp', '[]', 0, '2020-03-30 16:05:07', '2020-03-30 16:05:07', '2021-03-30 09:05:07');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'YpMOyEXF4myFLhs69DEZjzeIhvMR0qfwyI3GGVKQ', 'http://localhost', 1, 0, 0, '2020-01-21 05:04:52', '2020-01-21 05:04:52'),
(2, NULL, 'Laravel Password Grant Client', 'wQUaxjQJr0zRXgDTYBucPgWiUZsfPhWGQ4pBQzzA', 'http://localhost', 0, 1, 0, '2020-01-21 05:04:52', '2020-01-21 05:04:52');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-01-21 05:04:52', '2020-01-21 05:04:52');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `opportunity`
--

CREATE TABLE `opportunity` (
  `id` int(11) NOT NULL,
  `fields` varchar(500) NOT NULL,
  `parentId` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opportunity`
--

INSERT INTO `opportunity` (`id`, `fields`, `parentId`) VALUES
(1, 'AUS', 0),
(2, 'ALT', 0),
(3, 'AUS', 0),
(4, 'ALT', 0),
(5, 'BUS', 0),
(6, 'BDE', 0),
(7, 'RND', 0),
(8, 'RMS', 0),
(9, 'BUS', 0),
(10, 'RUS', 0),
(11, 'Australia', 1),
(12, 'Austria', 1),
(13, 'Artificial Intelligence', 1),
(14, 'Information Technology', 1),
(15, 'Business Development', 1),
(16, 'Business Technology', 2),
(17, 'Sales & Marketing', 2),
(18, 'Information Technology', 2),
(19, 'Business Technology', 3),
(20, 'Sales & Marketing', 3),
(21, 'Information Technology', 3),
(22, 'Business Technology', 4),
(23, 'Sales & Marketing', 4),
(24, 'Information Technology', 4),
(25, 'Business Technology', 5),
(26, 'Sales & Marketing', 5),
(27, 'Information Technology', 5),
(28, 'Business Technology', 6),
(29, 'Sales & Marketing', 6),
(30, 'Information Technology', 6),
(31, 'Business Technology', 7),
(32, 'Sales & Marketing', 7),
(33, 'Information Technology', 7),
(34, 'Business Technology', 8),
(35, 'Sales & Marketing', 8),
(36, 'Information Technology', 8),
(37, 'Business Technology', 9),
(38, 'Sales & Marketing', 9),
(39, 'Information Technology', 9),
(40, 'Business Technology', 10),
(41, 'Sales & Marketing', 10),
(42, 'Information Technology', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `package_type` varchar(255) NOT NULL,
  `business_id` int(11) DEFAULT '0',
  `currency` varchar(25) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `payment_status` int(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `package_id`, `package_type`, `business_id`, `currency`, `amount`, `payment_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(14, 9, 3, '3', 17, 'SAR', 2149, 1, '2020-04-14 06:29:23', '2020-04-14 13:29:23', NULL),
(13, 9, 2, '3', 10, 'SAR', 1649, 1, '2020-04-14 06:27:30', '2020-04-14 13:24:17', NULL),
(4, 9, 2, '3', 11, 'SAR', 1499, 1, '2020-04-13 07:51:07', '2020-04-13 07:00:00', NULL),
(5, 9, 2, '1', 0, 'USD', 33, 0, '2020-04-10 12:02:31', '2020-04-10 15:02:16', NULL),
(6, 9, 2, '1', 0, 'USD', 33, 0, '2020-04-10 12:02:31', '2020-04-10 15:02:55', NULL),
(7, 9, 2, '1', 0, 'USD', 33, 0, '2020-04-10 12:02:31', '2020-04-10 15:03:52', NULL),
(8, 9, 2, '1', 0, 'USD', 33, 0, '2020-04-10 12:02:31', '2020-04-10 15:04:42', NULL),
(9, 9, 2, '1', 0, 'SAR', 33, 1, '2020-04-15 14:11:22', '2020-04-10 16:00:55', NULL),
(10, 9, 2, '1', 0, 'SAR', 33, 0, '2020-04-10 12:02:31', '2020-04-10 16:02:42', NULL),
(11, 9, 1, '1', 0, 'SAR', 33, 1, '2020-04-13 12:23:55', '2020-04-12 16:06:54', NULL),
(12, 9, 3, '2', 0, 'SAR', 99, 1, '2020-04-15 13:23:52', '2020-04-10 21:44:42', NULL),
(15, 9, 2, '1', 0, 'SAR', 33, 1, '2020-04-14 06:32:48', '2020-04-14 13:32:48', NULL),
(16, 6, 3, '1', 0, 'SAR', 77, 0, '2020-04-14 13:35:35', '2020-04-14 13:35:35', NULL),
(17, 6, 1, '3', 3, 'SAR', 999, 0, '2020-04-14 18:39:07', '2020-04-14 18:39:07', NULL),
(18, 6, 1, '2', 0, 'SAR', 0, 1, '2020-04-15 13:26:50', '2020-04-15 20:26:50', NULL),
(19, 1, 3, '1', 0, 'SAR', 77, 1, '2020-04-16 05:27:31', '2020-04-16 12:27:31', NULL),
(20, 1, 2, '2', 0, 'SAR', 33, 1, '2020-04-16 06:26:33', '2020-04-16 13:26:33', NULL),
(21, 58, 2, '2', 0, 'SAR', 33, 1, '2020-04-16 10:08:10', '2020-04-16 17:08:10', NULL),
(22, 9, 3, '1', 0, 'SAR', 77, 0, '2020-04-16 19:24:11', '2020-04-16 19:24:11', NULL),
(23, 9, 2, '3', 10, 'SAR', 1499, 0, '2020-04-16 19:31:49', '2020-04-16 19:31:49', NULL),
(24, 9, 3, '3', 10, 'SAR', 1999, 0, '2020-04-16 19:37:57', '2020-04-16 19:37:57', NULL),
(25, 9, 3, '3', 10, 'SAR', 1999, 0, '2020-04-16 19:39:08', '2020-04-16 19:39:08', NULL),
(26, 9, 3, '1', 0, 'SAR', 77, 0, '2020-04-16 20:14:30', '2020-04-16 20:14:30', NULL),
(27, 9, 3, '1', 0, 'SAR', 77, 0, '2020-04-16 20:14:42', '2020-04-16 20:14:42', NULL),
(28, 58, 2, '1', 0, 'SAR', 33, 1, '2020-04-16 13:18:32', '2020-04-16 20:18:32', NULL),
(29, 4, 2, '1', 0, 'SAR', 33, 0, '2020-04-29 19:36:11', '2020-04-29 19:36:11', NULL),
(30, 4, 2, '3', 35, 'SAR', 1649, 0, '2020-04-29 19:38:31', '2020-04-29 19:38:31', NULL),
(31, 6, 2, '2', 0, 'SAR', 33, 0, '2020-04-30 14:56:56', '2020-04-30 14:56:56', NULL),
(32, 84, 1, '3', 36, 'SAR', 999, 0, '2021-07-11 19:16:00', '2021-07-11 19:16:00', NULL),
(33, 84, 2, '1', 0, 'SAR', 33, 0, '2021-07-11 19:20:10', '2021-07-11 19:20:10', NULL),
(34, 84, 1, '3', 37, 'SAR', 999, 0, '2021-07-12 13:43:03', '2021-07-12 13:43:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `investAs_id` int(11) DEFAULT NULL,
  `field_id` int(11) NOT NULL,
  `sub_field_id` int(11) DEFAULT NULL,
  `post_user_id` int(11) NOT NULL,
  `post_user_type` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `business_type_id` int(11) DEFAULT NULL,
  `range_of_investment_id` int(11) NOT NULL,
  `looking_type` int(11) NOT NULL,
  `description` text,
  `idea_worth_of` varchar(255) DEFAULT NULL,
  `is_valuated` int(1) DEFAULT NULL,
  `valuated_by` int(1) DEFAULT NULL,
  `is_valuated_from_valueNow` int(1) DEFAULT NULL,
  `opportunity_photo` varchar(255) DEFAULT NULL,
  `opportunity_documents` varchar(255) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `business_id`, `investAs_id`, `field_id`, `sub_field_id`, `post_user_id`, `post_user_type`, `country_id`, `business_type_id`, `range_of_investment_id`, `looking_type`, `description`, `idea_worth_of`, `is_valuated`, `valuated_by`, `is_valuated_from_valueNow`, `opportunity_photo`, `opportunity_documents`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(12, 2, NULL, 6, 2, 7, 1, 41, 6, 3, 1, 'Business Information', NULL, 0, NULL, NULL, NULL, NULL, 0, '2020-02-11 20:28:43', '2020-02-11 20:28:43', NULL),
(13, 2, NULL, 6, 2, 7, 1, 41, 6, 2, 1, 'Business Information', NULL, 1, NULL, NULL, 'public/images/opportunity_picture/1581428077.img-copy.png', NULL, 0, '2020-02-11 20:34:37', '2020-02-11 20:34:37', NULL),
(14, 2, NULL, 6, 2, 7, 1, 41, 6, 2, 1, 'Business Information', NULL, 1, NULL, NULL, 'public/images/opportunity_picture/1581428156.img-copy.png', 'public/images/opportunity_doc/1581428156.1576218132720.docx', 0, '2020-02-11 20:35:56', '2020-02-11 20:35:56', NULL),
(15, 2, NULL, 6, 2, 7, 1, 41, 6, 3, 1, 'Business Information', NULL, 1, NULL, NULL, 'public/images/opportunity_picture/1581428244.img-copy.png', 'public/images/opportunity_doc/1581428246.1576218132720.docx', 0, '2020-02-11 20:37:26', '2020-02-11 20:37:26', NULL),
(16, 2, NULL, 6, 2, 7, 1, 41, 6, 3, 1, 'Business Information', 'idea worth of', 1, 1, NULL, 'public/images/opportunity_picture/1581428344.img-copy.png', 'public/images/opportunity_doc/1581428344.file-sample_500kB (1).docx', 0, '2020-02-11 20:39:05', '2020-02-11 20:39:05', NULL),
(17, 2, NULL, 6, 2, 7, 1, 41, 6, 3, 2, 'Business Information.....', NULL, 0, NULL, 0, 'public/images/opportunity_picture/1581428899.img-copy.png', 'public/images/opportunity_doc/1581428900.sample.pdf', 0, '2020-02-11 20:48:20', '2020-02-11 20:48:20', NULL),
(23, 5, NULL, 27, 190, 1, 1, 8, 4, 4, 2, 'Thank you', '60', 1, 2, 0, 'public/images/opportunity_picture/1581522522.IMG-20191130-WA0011.jpg', 'public/images/opportunity_doc/1581522522.The-Basics.pptx', 0, '2020-02-12 22:48:44', '2020-04-16 12:27:51', NULL),
(24, 3, NULL, 27, NULL, 6, 1, 49, 3, 1, 1, 'Private business', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-02-13 14:28:33', '2020-02-13 14:28:33', NULL),
(59, 16, NULL, 1, 1, 15, 1, 49, 1, 1, 1, 'It\'s a private business realted to food', NULL, 1, 1, NULL, NULL, NULL, 0, '2020-02-16 15:18:40', '2020-02-16 15:18:40', NULL),
(60, 18, NULL, 23, NULL, 18, 1, 41, 3, 4, 2, 'Demo as a testing', NULL, 0, NULL, 1, NULL, NULL, 0, '2020-02-19 17:12:48', '2020-02-19 17:12:48', NULL),
(64, 15, NULL, 24, 158, 14, 1, 49, 2, 4, 2, 'we provide Gaming chairs and PS4 accounts', NULL, 0, NULL, NULL, NULL, NULL, 0, '2020-02-22 02:38:20', '2020-02-22 02:38:20', NULL),
(65, 21, NULL, 118, NULL, 6, 1, 49, 3, 1, 2, 'It\'s a private business', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-02-29 18:24:02', '2020-02-29 18:24:02', NULL),
(77, 3, NULL, 10, NULL, 14, 2, 49, NULL, 1, 2, 'معرض سيارات', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-03-24 18:53:52', '2020-03-24 18:53:52', NULL),
(78, 25, NULL, 3, 18, 24, 1, 49, 3, 1, 2, 'Alternative Dispute resolution', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:40:50', '2020-03-31 18:40:50', NULL),
(79, 24, NULL, 1, 7, 26, 1, 49, 5, 1, 1, 'Government Accounting', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:41:54', '2020-03-31 18:41:54', NULL),
(80, 27, NULL, 6, 35, 27, 1, 49, 3, 1, 2, 'Fashion industry', NULL, 0, NULL, 1, NULL, NULL, 0, '2020-03-31 18:45:56', '2020-03-31 18:45:56', NULL),
(81, 26, NULL, 17, 109, 28, 1, 49, 2, 1, 2, 'Stocks markets', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:50:11', '2020-03-31 18:50:11', NULL),
(82, 28, NULL, 9, 49, 29, 1, 7, 3, 1, 1, 'Functional crafts', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:51:19', '2020-03-31 18:51:19', NULL),
(83, 29, NULL, 6, 34, 30, 1, 59, 3, 1, 1, 'Fashion Design Business', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:52:01', '2020-03-31 18:52:01', NULL),
(84, 31, NULL, 1, 5, 31, 1, 59, 4, 1, 2, 'Financial Accounting Companies', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:53:02', '2020-03-31 18:53:02', NULL),
(85, 30, NULL, 2, 15, 32, 1, 7, 3, 1, 2, 'Airlines Marketing', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:53:51', '2020-03-31 18:53:51', NULL),
(86, 32, NULL, 10, 55, 33, 1, 128, 3, 1, 2, 'Automotive engineering', NULL, 0, NULL, 0, NULL, NULL, 0, '2020-03-31 18:54:51', '2020-03-31 18:54:51', NULL),
(87, 33, NULL, 25, 161, 34, 1, 128, 4, 2, 2, 'Computer Hardware (Output devices)', NULL, 0, NULL, 1, NULL, NULL, 0, '2020-03-31 18:55:45', '2020-03-31 18:55:45', NULL),
(88, 4, NULL, 1, 5, 35, 2, 128, NULL, 1, 2, 'Financial Accounting', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-03-31 19:03:57', '2020-03-31 19:03:57', NULL),
(89, 5, NULL, 12, 65, 36, 2, 7, NULL, 1, 2, 'Exchanging Banks', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-03-31 19:07:38', '2020-03-31 19:07:38', NULL),
(90, 8, NULL, 2, 13, 37, 2, 162, NULL, 1, 1, 'Airlines operations', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-03-31 19:09:32', '2020-03-31 19:09:32', NULL),
(91, 10, NULL, 1, 9, 38, 2, 59, NULL, 2, 1, 'Management accounting', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-03-31 19:12:00', '2020-03-31 19:12:00', NULL),
(93, 8, NULL, 10, 53, 39, 2, 44, NULL, 2, 1, 'Automotive Prototypes', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-03-31 19:14:27', '2020-03-31 19:14:27', NULL),
(94, 11, NULL, 2, 15, 9, 2, 5, NULL, 2, 2, 'Describe your opportunity', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-04-01 14:57:08', '2020-04-15 21:59:35', NULL),
(95, 11, NULL, 2, 15, 9, 2, 6, NULL, 3, 1, 'Describe your opportunity', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-04-01 15:07:54', '2020-04-15 21:59:35', NULL),
(96, 11, NULL, 2, 13, 9, 2, 6, NULL, 3, 1, 'Describe your opportunity', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2020-04-01 16:51:40', '2020-04-15 21:59:35', NULL),
(97, 10, NULL, 6, 32, 9, 1, 5, 5, 3, 1, 'this is my testing business', NULL, 0, NULL, 1, NULL, NULL, 0, '2020-04-01 17:15:11', '2020-04-01 17:15:11', NULL),
(98, 15, NULL, 27, 190, 6, 2, 49, NULL, 1, 1, 'Zain is a programming company', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-04-07 14:05:28', '2020-04-07 14:05:28', NULL),
(99, 11, NULL, 2, 13, 9, 2, 6, NULL, 2, 1, 'Describe your opportunity', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-04-13 17:42:49', '2020-04-15 21:59:35', NULL),
(100, 14, NULL, 5, 27, 9, 2, 8, NULL, 5, 1, 'Describe your opportunity', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2020-04-13 17:45:10', '2020-04-15 21:59:35', NULL),
(101, 11, NULL, 4, 19, 9, 1, 6, 3, 2, 1, 'The Mathematics Placement Exam (MPE) is a 90-minute, 60-item multiple choice exam that tests skills and understandings from precalculus mathematics. It is designed to measure readiness for college courses in calculus and precalculus. Online, you may view an individual report that includes placement level and a list of topics that should be reviewed before the class begins.', NULL, 0, NULL, 1, NULL, NULL, 0, '2020-04-13 17:46:12', '2020-04-13 17:46:12', NULL),
(102, 11, NULL, 4, 19, 9, 2, 6, 3, 1, 1, 'The Mathematics Placement Exam (MPE) is a 90-minute, 60-item multiple choice exam that tests skills and understandings from precalculus mathematics. It is designed to measure readiness for college courses in calculus and precalculus. Online, you may view an individual report that includes placement level and a list of topics that should be reviewed before the class begins.', NULL, 0, NULL, 1, NULL, NULL, 0, '2020-04-13 18:24:52', '2020-04-15 21:59:35', NULL),
(103, 35, NULL, 2, 14, 4, 1, 5, 3, 2, 1, 'dfzczxczxczx', '4567785', 1, 2, NULL, NULL, NULL, 0, '2020-04-29 19:40:36', '2020-04-29 19:40:36', NULL),
(104, 37, NULL, 1, 5, 84, 1, 49, 2, 2, 1, 'test', '200', 1, 2, NULL, NULL, NULL, 0, '2021-07-12 13:40:36', '2021-07-12 13:40:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_views`
--

CREATE TABLE `post_views` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_type` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_views`
--

INSERT INTO `post_views` (`id`, `post_id`, `user_id`, `user_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(6, 74, 6, 1, '2020-03-19 14:38:28', '2020-03-19 14:38:28', NULL),
(8, 24, 1, 2, '2020-03-20 14:32:22', '2020-03-20 14:32:22', NULL),
(56, 15, 9, 2, '2020-04-16 14:44:36', '2020-04-16 14:44:36', NULL),
(10, 65, 1, 2, '2020-03-20 14:32:48', '2020-03-20 14:32:48', NULL),
(13, 64, 14, 1, '2020-03-20 20:14:19', '2020-03-20 20:14:19', NULL),
(14, 64, 6, 1, '2020-03-21 17:55:13', '2020-03-21 17:55:13', NULL),
(15, 60, 6, 1, '2020-03-21 17:55:40', '2020-03-21 17:55:40', NULL),
(16, 23, 6, 1, '2020-03-21 17:56:17', '2020-03-21 17:56:17', NULL),
(17, 76, 6, 1, '2020-03-22 15:23:50', '2020-03-22 15:23:50', NULL),
(20, 75, 6, 1, '2020-03-23 15:26:30', '2020-03-23 15:26:30', NULL),
(21, 24, 6, 1, '2020-03-23 15:31:25', '2020-03-23 15:31:25', NULL),
(22, 75, 1, 2, '2020-03-23 23:37:12', '2020-03-23 23:37:12', NULL),
(23, 65, 14, 1, '2020-03-24 18:47:14', '2020-03-24 18:47:14', NULL),
(24, 77, 6, 1, '2020-03-29 18:53:22', '2020-03-29 18:53:22', NULL),
(25, 60, 9, 2, '2020-03-30 20:21:32', '2020-03-30 20:21:32', NULL),
(26, 85, 6, 1, '2020-03-31 18:58:53', '2020-03-31 18:58:53', NULL),
(33, 81, 9, 2, '2020-04-01 17:09:51', '2020-04-01 17:09:51', NULL),
(37, 91, 46, 1, '2020-04-01 17:52:08', '2020-04-01 17:52:08', NULL),
(41, 97, 6, 1, '2020-04-02 16:10:43', '2020-04-02 16:10:43', NULL),
(42, 96, 24, 1, '2020-04-02 20:03:54', '2020-04-02 20:03:54', NULL),
(67, 87, 58, 2, '2020-04-16 18:00:01', '2020-04-16 18:00:01', NULL),
(44, 94, 1, 2, '2020-04-16 12:36:51', '2020-04-16 12:36:51', NULL),
(45, 95, 1, 2, '2020-04-16 13:18:25', '2020-04-16 13:18:25', NULL),
(46, 60, 1, 2, '2020-04-16 13:19:53', '2020-04-16 13:19:53', NULL),
(47, 17, 9, 2, '2020-04-16 13:52:41', '2020-04-16 13:52:41', NULL),
(48, 23, 9, 2, '2020-04-16 13:52:50', '2020-04-16 13:52:50', NULL),
(49, 12, 9, 2, '2020-04-16 13:53:27', '2020-04-16 13:53:27', NULL),
(50, 16, 9, 2, '2020-04-16 13:53:59', '2020-04-16 13:53:59', NULL),
(51, 14, 9, 2, '2020-04-16 13:54:09', '2020-04-16 13:54:09', NULL),
(52, 46, 1, 2, '2020-04-16 14:18:56', '2020-04-16 14:18:56', NULL),
(53, 84, 1, 2, '2020-04-16 14:19:03', '2020-04-16 14:19:03', NULL),
(54, 80, 1, 2, '2020-04-16 14:19:14', '2020-04-16 14:19:14', NULL),
(55, 79, 1, 2, '2020-04-16 14:19:24', '2020-04-16 14:19:24', NULL),
(57, 78, 9, 2, '2020-04-16 14:45:47', '2020-04-16 14:45:47', NULL),
(63, 84, 9, 2, '2020-04-16 15:07:29', '2020-04-16 15:07:29', NULL),
(62, 79, 9, 2, '2020-04-16 15:04:17', '2020-04-16 15:04:17', NULL),
(61, 80, 9, 2, '2020-04-16 15:01:59', '2020-04-16 15:01:59', NULL),
(66, 87, 9, 2, '2020-04-16 17:33:14', '2020-04-16 17:33:14', NULL),
(65, 102, 58, 1, '2020-04-16 17:05:37', '2020-04-16 17:05:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `state_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subfields`
--

CREATE TABLE `subfields` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `field_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subfields`
--

INSERT INTO `subfields` (`id`, `name`, `field_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, 'Financial accounting', 1, '2020-02-19 08:43:10', '2020-02-19 08:43:10', NULL),
(6, 'Public accounting', 1, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(7, 'Government accounting', 1, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(8, 'Forensic accounting', 1, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(9, 'Management accounting', 1, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(10, 'Tax accounting', 1, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(11, 'Internal auditing', 1, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(12, 'Others', 1, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(13, 'Operations', 2, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(14, 'Maintenance', 2, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(15, 'Marketing', 2, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(16, 'Finance', 2, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(17, 'Others', 2, '2020-02-19 08:47:05', '2020-02-19 08:47:05', NULL),
(18, 'N.A.', 3, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(19, 'Acupuncture\r\n', 4, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(20, 'Ayurveda\r\n', 4, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(21, 'Homeopathy\r\n', 4, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(22, 'Medicine\r\n', 4, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(23, 'Chinese or Oriental ', 4, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(24, 'Naturopathy', 4, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(25, 'Others\r\n', 4, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(26, 'Traditional Animation\r\n', 5, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(27, '2D Vector-based animation\r\n', 5, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(28, '3D computer animation\r\n', 5, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(29, 'Motion graphics\r\n', 5, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(30, 'Stop motion\r\n', 5, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(31, 'Others\r\n', 5, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(32, 'Fashion accessories‎\r\n', 6, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(33, 'Beauty‎ \r\n', 6, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(34, 'Fashion design‎ \r\n', 6, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(35, 'Fashion industry‎ \r\n', 6, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(36, 'Others\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(37, 'Residential Architect\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(38, 'Commercial Architect\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(39, 'Interior Designer\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(40, 'Green Design Architect\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(41, ' Landscape Architect\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(42, 'Urban Designer\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(43, 'Industrial Architect\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(44, 'Others\r\n', 7, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(45, 'Textile Crafts\r\n', 9, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(46, 'Paper Crafts\r\n', 9, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(47, 'Decorative Crafts\r\n', 9, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(48, 'Fashion Crafts\r\n', 9, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(49, 'Functional Crafts\r\n', 9, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(50, 'Others\r\n', 9, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(51, 'Automotive  Accessories\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(52, 'Automotive Components & Materials\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(53, 'Automotive Prototypes\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(54, 'Automobile Electrical and Electronic Systems\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(55, 'Automotive Engineering Services\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(56, 'Logistics and Warehousing\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(57, 'Production Control Equipment and Testing Systems\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(58, 'Others\r\n', 10, '2020-02-19 14:40:09', '2020-02-19 14:40:09', NULL),
(59, 'Aircraft Electrical Installer or Technician', 11, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(60, 'Aircraft Manufacturing', 11, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(61, 'Aviation Maintenance \r\n', 11, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(62, 'Air Traffic Control\r\n', 11, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(63, 'Others\r\n', 11, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(64, 'Commercial Banks\r\n', 12, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(65, 'Exchange Banks\r\n', 12, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(66, 'Industrial Banks\r\n', 12, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(67, 'Agricultural or Co-operative Banks\r\n', 12, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(68, 'Savings Banks\r\n', 12, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(69, 'Others\r\n', 12, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(70, 'Medical Biotechnology\r\n', 13, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(71, 'Agricultural Biotechnology\r\n', 13, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(72, 'Food and Consumer Goods\r\n', 13, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(73, 'Environmental Biotechnology\r\n', 13, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(74, 'Others\r\n', 13, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(75, 'Analogue Terrestrial TV\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(76, 'Systems for sound transmission\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(77, 'Digital Satellite TV\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(78, 'Cable TV: analogue and digital systems\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(79, 'Digital terrestrial TV (DTTV)\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(80, 'High Definition Television (HDTV)\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(81, 'Pay-per-view\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(82, 'Video-on-demand\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(83, 'Web TV\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(84, 'IPTV\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(85, 'Others\r\n', 14, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(86, 'Aluminium\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(87, 'Brick (clay)\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(88, 'Concrete\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(89, 'Fibre cement sheeting\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(90, 'Glass\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(91, 'Mudbrick\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(92, 'Plasterboard\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(93, 'Plastics\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(94, 'Steel\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(95, 'Stone and Composite Stone\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(96, 'Timber\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(97, 'Others\r\n', 15, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(98, 'Computer Equipment\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(99, 'Communication Devices\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(100, 'Stationary \r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(101, 'Storage Equipment\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(102, 'Computer Software\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(103, 'Photocopiers and Printers\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(104, 'Telephone Systems\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(105, 'Furniture\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(106, 'Others\r\n', 16, '2020-02-20 07:35:03', '2020-02-20 07:35:03', NULL),
(107, 'Bond Market\r\n', 17, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(108, 'Mortgage Market\r\n', 17, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(109, 'Stock Markets\r\n', 17, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(110, 'Futures Market\r\n', 17, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(111, 'Others\r\n', 17, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(112, 'Biotechnology\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(113, 'Nanotechnology\r\n\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(114, 'Mineral Processing\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(115, 'Ceramics\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(116, 'Fluid Dynamics\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(117, 'Environmental Science\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(118, 'Materials Science \r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(119, 'Thermodynamics\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(120, 'Others\r\n', 18, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(121, 'Alumni associations\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(122, 'Automobile clubs (except travel)\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(123, 'Booster clubs\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(124, 'Parent-teacher associations\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(125, 'Scouting organizations\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(126, 'Social clubs\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(127, 'Veterans\' membership organizations\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(128, 'Others\r\n', 19, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(129, 'Coastal engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(130, 'Construction engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(131, 'Earthquake engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(132, 'Environmental engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(133, 'Forensic engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(134, 'Geotechnical engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(135, 'Materials science and engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(136, 'Structural engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(137, 'Surveying\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(138, 'Transportation engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(139, 'Municipal or urban engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(140, 'Water resources engineering\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(141, 'Civil engineering systems\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(142, 'Others\r\n', 20, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(143, 'Office\r\n', 21, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(144, 'Retail\r\n', 21, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(145, 'Industrial\r\n', 21, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(146, 'Multifamily\r\n', 21, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(147, 'Hotel\r\n', 21, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(148, '\"\r\nSpecial Purpose\r\n', 21, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(149, 'Others\r\n', 21, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(150, 'PC\r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(151, 'Laptops \r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(152, 'Antivirus software‎\r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(153, 'Computer security exploits‎\r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(154, 'Internet security\r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(155, 'Network Devices \r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(156, 'Virtual private networks\r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(157, 'Others\r\n', 23, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(158, 'N.A.', 24, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(159, 'Input Devices\r\n', 25, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(160, 'Processing Devices\r\n', 25, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(161, 'Output Devices\r\n', 25, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(162, 'Storage Devices\r\n', 25, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(163, 'Printers \r\n', 25, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(164, 'Others\r\n', 25, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(165, 'Switches \r\n', 26, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(166, 'Routers \r\n', 26, '2020-02-20 08:23:48', '2020-02-20 08:23:48', NULL),
(184, 'Access points\r\n', 26, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(185, 'Network monitoring \r\n', 26, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(186, 'Passive components \r\n', 26, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(187, 'Others \r\n', 26, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(188, 'Operating System (OS)\r\n', 27, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(189, 'Device Drivers\r\n', 27, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(190, 'Programming Languages\r\n', 27, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(191, 'Firmware\r\n', 27, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(192, 'ERP \r\n', 27, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(193, 'CRM \r\n', 27, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(194, 'Others \r\n', 27, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(195, 'Residential Building Construction\r\n', 28, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(196, 'Industrial Construction\r\n', 28, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(197, 'Commercial Building Construction\r\n', 28, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(198, 'Heavy Civil Construction\r\n', 28, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL),
(199, 'Others\r\n', 28, '2020-02-20 10:32:30', '2020-02-20 10:32:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qualification` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL COMMENT '1 - Male, 2 - Female, 3 - Other',
  `image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 - Enterprenuer, 2 - Investor',
  `profile_completed` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1 - Completed',
  `social_login` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1 - Google, 2 - Facebook',
  `login_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-Admin login,1 - manual, 2 - social',
  `social_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_phone_verified` int(11) NOT NULL DEFAULT '0',
  `OTP` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int(1) NOT NULL DEFAULT '0' COMMENT '0-active, 1-inactive',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `dob`, `qualification`, `email`, `password`, `country_code`, `country`, `state`, `city`, `address`, `phone_number`, `gender`, `image`, `type`, `profile_completed`, `social_login`, `login_type`, `social_id`, `email_verified_at`, `is_phone_verified`, `OTP`, `is_active`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Ajay', 'Chauhan', '11-11-1995', 'MBA', 'ajaysingh.chauhan@mobilecoderz.com', '$2y$10$.IhburhIfEqWkJ/MHNnice.u6P9eSw9XF7FNDdX9TdnwB3cEiwnT2', '+91', 41, 'Delhi', 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', '9958140987', 1, 'public/images/user_picture/1584371068.Profile.png', 2, 1, 0, 1, NULL, '2020-02-10 21:13:39', 1, NULL, 0, NULL, '2020-02-10 21:12:00', '2020-04-16 14:55:11'),
(6, 'Sura', 'Hamdan', '21-3-1995', 'Bachelor in Engineering', 'sura@arenasmartapps.com', '$2y$10$0Kxxcp/67DbV4qL.em65yOch2OftgcMsgLrE6Gh0F99vLyPArzRpu', '+962', 49, 'Amman', 'Amman', 'Sport City,36', '796472054', 2, 'public/images/user_picture/1581415886.unnamed.jpg', 1, 1, 0, 1, NULL, '2020-02-11 17:52:54', 1, NULL, 0, NULL, '2020-02-11 14:50:11', '2021-07-06 18:37:48'),
(51, 'Admin', NULL, NULL, NULL, 'admin@valuenow.net', '$2y$10$34DzVvosAg18CDaW8svOhOn8F30UDDx3bO0Q1mT6ecPmpIQWr9vFi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL),
(78, 'Himanshi', 'Dabral', NULL, NULL, 'himanshidabral7991@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 2, 2, '102713260960041180622', '1970-01-01 07:00:01', 0, NULL, 0, '74plaaK0NeVV2pMg4eZ7OnqVHNI6fus2jET0N7zYbeJKrjwYe9FCyii2BtVu', '2021-07-08 17:36:21', '2021-07-08 17:36:21'),
(79, 'him', 'dab', NULL, NULL, 'himanshidabral7991@gmail.com', '$2y$10$azSeJCSDW0dvFzDUUpHbpOic.GO4/ZUyHancf4a7trmWRBQpvJjLS', '+91', NULL, NULL, NULL, NULL, '9643350687', 2, NULL, 1, 0, 0, 1, NULL, '2021-07-09 18:17:26', 1, NULL, 0, NULL, '2021-07-08 17:41:29', '2021-07-09 18:17:26'),
(80, 'abc', 'abc', NULL, NULL, 'abctest@gmail.com', '$2y$10$Q5lRZhQkalQ6SsuTkkhfKezd0/LMg8wZ0AvmCXvQZgOD3eIMGF9A6', '+91', NULL, NULL, NULL, NULL, '9910286283', 1, NULL, 1, 0, 0, 1, NULL, NULL, 0, '8551', 0, NULL, '2021-07-09 02:22:31', '2021-07-09 02:22:31'),
(81, 'Ajay', 'Chauhan', NULL, NULL, 'ajaychauhanmobilecoderz@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 2, 2, '117345210252262881710', '1970-01-01 07:00:01', 0, NULL, 0, 'CFNEfoXQ2bILwcWYskeM1vkRzAr4Le7kKUXqxe81wDU8Zl0LBeaXytf8T89v', '2021-07-09 11:44:23', '2021-07-09 11:44:23'),
(82, 'Nikhil', 'Dewan', '7-7-2006', 'fcvredfcv', 'queigreneupowou-5071@yopmail.com', '$2y$10$sPQloMvRHe3JOs3MRTC.Xe7.lxCXI7Fi/eu8l8CZkbEmrICJOL9b2', '+91', 4, 'dfvcdcv', 'vdcfs', 'vfdscv', '9650920746', 1, NULL, 1, 1, 0, 1, NULL, '2021-07-09 18:13:49', 1, NULL, 0, NULL, '2021-07-09 18:11:28', '2021-07-09 18:15:48'),
(83, 'Ahmad', 'Khalaf', '1-6-1969', 'MS', 'ahmadtkhalaf.ak@gmail.com', NULL, '+962', 49, '', 'Amman', 'amman jawa', '775659999', 1, NULL, 2, 1, 2, 2, '109925043939491277942', '1970-01-01 07:00:01', 1, NULL, 0, 'H9seE6CC27Jw8bID19IllyZclGHTCptaoRyayoiD5odGwcJX3uivhj9Te6oX', '2021-07-11 16:19:03', '2021-07-11 16:26:33'),
(84, 'Sura', 'Arena', '21-3-1995', 'Bachelor in Engineering', 'suraarena@gmail.com', NULL, '+962', 49, 'Amman', 'Amman', 'Amman', '0798484019', 2, NULL, 2, 1, 2, 2, '109485812183201632450', '1970-01-01 07:00:01', 1, NULL, 0, 'jrI4Jha2cG7faQxGlzLUmVQ21tWwq7cwYpPByKMGVNdVwxy4XfmxU5phKX0X', '2021-07-11 16:19:07', '2021-07-12 13:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `user_chats`
--

CREATE TABLE `user_chats` (
  `id` int(11) NOT NULL,
  `senderId` int(11) NOT NULL,
  `receiverId` int(11) NOT NULL,
  `message` blob NOT NULL,
  `url` mediumtext NOT NULL,
  `type` int(1) NOT NULL DEFAULT '1',
  `timestamp` varchar(255) NOT NULL,
  `isRead` int(1) NOT NULL DEFAULT '0',
  `isBlock` int(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_opportunities`
--

CREATE TABLE `user_opportunities` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_user_id` int(11) NOT NULL,
  `post_user_type` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_opportunities`
--

INSERT INTO `user_opportunities` (`id`, `post_id`, `post_user_id`, `post_user_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 5, 10, 1, '2020-01-24 05:30:02', '2020-01-24 05:30:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `workplaces`
--

CREATE TABLE `workplaces` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `investment_name` varchar(255) DEFAULT NULL,
  `business_field` int(11) NOT NULL,
  `business_subfield` int(11) NOT NULL,
  `business_type` int(11) NOT NULL,
  `country` int(11) NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country_code` varchar(255) DEFAULT NULL,
  `phone_number` bigint(20) NOT NULL,
  `year_of_investment` year(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workplaces`
--

INSERT INTO `workplaces` (`id`, `user_id`, `investment_name`, `business_field`, `business_subfield`, `business_type`, `country`, `state`, `city`, `address`, `country_code`, `phone_number`, `year_of_investment`, `description`, `profile_picture`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 4, 'rakesh sharma', 3, 18, 2, 6, '5', 'Noida', 'Sec 62, Noida', '91', 986745215, 2000, 'this is test description', 'public/images/user_picture/1584370937Simulator Screen Shot - iPad Air.png', '2020-03-06 17:15:30', '2020-03-16 14:29:21', NULL),
(4, 1, 'Ajay Chauhan', 2, 13, 2, 41, 'null', 'Noida', 'H 221', '41', 9958140914, 2009, 'Hello Hi', 'public/images/user_picture/1584370937Simulator Screen Shot - iPad Air.png', '2020-03-16 22:02:18', '2020-03-16 22:04:57', NULL),
(11, 9, 'deva', 2, 13, 5, 6, 'uttar pradesh', 'noida', 'sector 12', '6', 9854785478, 2018, 'test only', NULL, '2020-03-30 17:32:31', '2020-03-30 17:56:58', NULL),
(5, 6, 'Sura', 1, 5, 4, 49, 'Amman', 'Amman', 'Gardenz', '49', 7965236452, 2021, 'Accounting business', NULL, '2020-03-23 15:35:39', '2020-03-23 15:36:34', NULL),
(6, 14, 'AK  iNVEST', 10, 52, 4, 128, 'WR', 'JEDDAH', 'Madina Road', '128', 544433032, 2001, 'we are looking to invest in automotive business', NULL, '2020-03-24 18:57:46', '2020-03-24 18:57:46', NULL),
(7, 9, 'raj', 4, 19, 4, 4, 'null', 'noida', 'sector 12', '5', 9854785478, 2018, 'test only', NULL, '2020-03-30 14:09:26', '2020-03-30 18:00:47', NULL),
(17, 36, 'Orange', 26, 185, 3, 7, 'Cairo', 'Cairo', 'cairo45', '7', 9632598562, 2016, 'Computer networking business', NULL, '2020-03-31 16:03:41', '2020-03-31 16:03:41', NULL),
(15, 6, 'Zain', 27, 190, 3, 49, 'Amman', 'Amman', 'Gardenz', '73', 789456129, 2016, 'Computer sofware Business', NULL, '2020-03-31 15:48:59', '2020-03-31 15:48:59', NULL),
(16, 35, 'Rebhi group', 1, 5, 3, 49, 'Amman', 'Amman', 'Gardenz', '73', 963852741, 2019, 'Private business', NULL, '2020-03-31 16:00:40', '2020-03-31 16:00:40', NULL),
(18, 38, 'Imran group', 1, 6, 4, 59, 'Bairout', 'Bairout', 'Bairout', '59', 596321476, 2016, 'Accounting', NULL, '2020-03-31 16:08:10', '2020-03-31 16:08:10', NULL),
(14, 9, 'rakesh sharma test1', 5, 27, 6, 8, 'uttar pradesh', 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', '5', 9654785478, 2018, 'Upload corporate document(s)', NULL, '2020-03-30 18:15:54', '2020-03-30 18:47:24', NULL),
(19, 37, 'Sbaih Company', 5, 26, 3, 128, 'Jeddah', 'Jeddah', 'Jeddah', '128', 965456521, 2013, 'Animation', NULL, '2020-03-31 16:10:26', '2020-03-31 16:10:26', NULL),
(20, 40, 'Safadi group', 18, 112, 3, 49, 'Azarqaa', 'Azarqaa', 'Azarqaa', '49', 963221565633, 2017, 'Biotechnology', NULL, '2020-03-31 16:17:37', '2020-03-31 16:17:37', NULL),
(21, 39, 'Al-fayez Sons', 15, 86, 3, 162, 'Dubai', 'Dubai', 'Dubai', '162', 963215566265, 2000, 'Private business for Aluminium', NULL, '2020-03-31 16:20:48', '2020-03-31 16:20:48', NULL),
(22, 43, 'RS Company', 9, 46, 3, 128, 'Jeddah', 'Jeddah', 'Jeddah', '128', 65695956266, 2001, 'Paper crafts company', NULL, '2020-03-31 16:25:23', '2020-03-31 16:25:23', NULL),
(23, 41, 'Rwaished Sons', 20, 130, 3, 162, 'Dubai', 'Dubai', 'Dubai', '162', 963258741, 1999, 'construction engineering', NULL, '2020-03-31 16:29:37', '2020-03-31 16:29:37', NULL),
(24, 44, 'Al-majed Arts', 9, 47, 3, 49, 'Amman', 'Amman', 'Gardenz', '49', 963255887, 2006, 'Dicoration company', NULL, '2020-03-31 16:32:05', '2020-03-31 16:32:05', NULL),
(3, 45, 'Khalifa Group', 12, 64, 4, 128, 'Riyadh', 'Riyadh', 'Riyadh', '128', 9632587412, 1998, 'Khalifa group for Commercial banking', NULL, '2020-03-31 16:34:49', '2020-03-31 16:34:49', NULL),
(10, 50, 'test', 3, 18, 5, 5, NULL, 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', '5', 7978545454, 2018, 'was received when fetching the script.', NULL, '2020-03-31 19:01:22', '2020-03-31 19:01:22', NULL),
(8, 50, '$5000', 4, 21, 5, 6, NULL, 'New Delhi', '1 2, Rajpath Area, Central Secretariat,', '8', 9654785478, 2018, 'response code (404) was received when fetching the script.', NULL, '2020-03-31 19:04:11', '2020-03-31 19:04:11', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookmarks`
--
ALTER TABLE `bookmarks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `business`
--
ALTER TABLE `business`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_evaluation_packages`
--
ALTER TABLE `business_evaluation_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_types`
--
ALTER TABLE `business_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entrepreneur_packages`
--
ALTER TABLE `entrepreneur_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investing_as`
--
ALTER TABLE `investing_as`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investor_packages`
--
ALTER TABLE `investor_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invest_ranges`
--
ALTER TABLE `invest_ranges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `opportunity`
--
ALTER TABLE `opportunity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191));

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_views`
--
ALTER TABLE `post_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`),
  ADD KEY `states_country_id_index` (`country_id`);

--
-- Indexes for table `subfields`
--
ALTER TABLE `subfields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `field_foreign_key` (`field_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_opportunities`
--
ALTER TABLE `user_opportunities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workplaces`
--
ALTER TABLE `workplaces`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookmarks`
--
ALTER TABLE `bookmarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `business`
--
ALTER TABLE `business`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `business_evaluation_packages`
--
ALTER TABLE `business_evaluation_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `business_types`
--
ALTER TABLE `business_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `entrepreneur_packages`
--
ALTER TABLE `entrepreneur_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `investing_as`
--
ALTER TABLE `investing_as`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `investor_packages`
--
ALTER TABLE `investor_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `invest_ranges`
--
ALTER TABLE `invest_ranges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `opportunity`
--
ALTER TABLE `opportunity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `post_views`
--
ALTER TABLE `post_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subfields`
--
ALTER TABLE `subfields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `user_opportunities`
--
ALTER TABLE `user_opportunities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `workplaces`
--
ALTER TABLE `workplaces`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `states`
--
ALTER TABLE `states`
  ADD CONSTRAINT `states_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subfields`
--
ALTER TABLE `subfields`
  ADD CONSTRAINT `field_foreign_key` FOREIGN KEY (`field_id`) REFERENCES `fields` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
